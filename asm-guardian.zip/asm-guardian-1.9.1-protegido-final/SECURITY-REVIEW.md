# Revisão de engenharia e segurança - versão 1.9.1

Data: 2026-10-07

## Escopo

Foram revisados o backend FastAPI, autenticação por usuário e senha, sessões, CSRF, chaves para automações, autorização por função e organização, allowlists por cliente, Nmap, Gobuster DNS, Subfinder passivo, inventário HTTP/TLS, filas e rate limits, persistência e migração SQLite, alertas de mudança, contexto e priorização de ativos, relatórios e exportações, retenção explícita, backup, dashboard, instalador Ubuntu, systemd e empacotamento.

## Controles confirmados

1. O Nmap continua aceitando apenas perfis fechados: personalizado, top 1.000 e todas as 65.535 portas TCP. Não há argumentos livres, NSE, UDP, detecção de sistema operacional ou exploração ativa.
2. Todo alvo Nmap precisa passar pela allowlist. Hostnames exigem regra de nome e todos os endereços resolvidos dentro dos CIDRs autorizados.
3. A descoberta aceita somente um domínio-base presente em `ASM_ALLOWED_HOSTS`. Gobuster e Subfinder recebem comandos fixos, construídos internamente e executados com `shell=False`; o Subfinder também recebe HOME privado e atualização automática desativada.
4. A wordlist padrão é pequena e incorporada. Uma lista personalizada precisa ser um arquivo regular, não vazio e de até 1 MiB.
5. A saída do Gobuster é filtrada: apenas hostnames sintaticamente válidos e filhos do domínio autorizado são persistidos, até 2.000 resultados por execução.
6. Descoberta DNS tem rate limit, concorrência, backlog e timeout próprios. Ela nunca inicia Nmap automaticamente; a validação completa de escopo ocorre novamente quando um hostname é escolhido para varredura.
7. O inventário HTTP/TLS aceita apenas alvos aprovados pela allowlist, conecta aos IPs previamente resolvidos, não segue redirecionamentos e limita timeout, resposta, endereços, taxa e concorrência.
8. A primeira varredura concluída de cada alvo cria uma linha de base. Execuções posteriores geram alertas persistentes para IPs e portas abertas nunca vistos antes, com reconhecimento controlado por função.
9. Senhas são armazenadas com `scrypt`, salt aleatório e comparação em tempo constante. A resposta de login nunca devolve senha nem token de sessão.
10. O dashboard usa APIs DOM seguras e não insere respostas da API por `innerHTML`.
11. A implantação nativa mantém loopback, usuário sem login, umask restritiva, diretório privado, hardening do systemd e ausência de capabilities.
12. Cada execução ASM mantém um UUID persistente, visível e copiável no dashboard para correlação operacional. Esse UUID não é apresentado como identificador do Codex Security.
13. Organizações possuem allowlists, usuários, sessões e chaves de integração próprias. O contexto da organização vem da identidade autenticada, não de parâmetros enviados aos endpoints operacionais.
14. Scans, ativos, descobertas, observações Web/TLS, monitores, alertas e auditoria são filtrados por organização; acesso cruzado por identificador retorna `404`.
15. Somente o administrador global ou a chave de recuperação podem criar organizações ou usuários em outra organização. Administradores locais gerenciam apenas usuários e integrações da própria organização.
16. Bancos anteriores são migrados sem descarte: registros existentes recebem a organização `default`, cuja allowlist continua sincronizada com o arquivo de ambiente.
17. A interface agrupa portas abertas por ativo e as classifica para leitura operacional (acesso remoto, Web, dados, mensageria e outras), sem tratar uma porta aberta isoladamente como vulnerabilidade confirmada.
18. O cockpit expõe contagens já fornecidas pelo backend — scans ativos, falhas, endpoints Web/TLS e alertas pendentes — sem criar um score de vulnerabilidade ou alterar decisões de autorização.
19. A fila de atenção e o espectro de serviços são derivados localmente do inventário autorizado. Filtros por categoria afetam somente a apresentação e permanecem ativos após a atualização automática.
20. O frontend autentica com usuário e senha, mantém a sessão em cookie `HttpOnly`/`SameSite=Strict` e não usa `localStorage`, `sessionStorage` ou DOM para guardar senha ou chave de API. O token CSRF, que não autentica sozinho, usa cookie separado `SameSite=Strict` e cópia na sessão da aba.
21. Requisições mutáveis autenticadas por cookie exigem `X-CSRF-Token`; chaves de automação não dependem de cookie e continuam compatíveis com integrações existentes.
22. O login possui limite simultâneo por IP e por combinação IP/usuário, usa mensagem genérica para credencial inválida e executa uma verificação `scrypt` simulada quando o usuário não existe.
23. Troca ou redefinição de senha e desativação de usuário revogam todas as sessões da conta. O administrador global protegido não pode ser desativado pela API.
24. A tabela de sessões armazena somente hashes SHA-256 do token de sessão e do token CSRF, validade fixa, último uso e revogação. Tokens aleatórios são gerados com `secrets`.
25. Chaves gerenciadas continuam disponíveis somente para recuperação e automações, armazenadas como hash e nunca usadas pelo dashboard.
26. A autenticação possui uma página própria em `/login`. O backend redireciona acessos sem sessão ao painel e impede acesso direto aos documentos HTML pela montagem de recursos estáticos.
27. A atualização automática ocorre a cada 60 segundos, é suspensa em abas ocultas e usa assinaturas dos dados para evitar reconstruções desnecessárias do DOM. O dashboard remove composição contínua por `backdrop-filter` e animações decorativas caras sem retirar os elementos visuais.
28. Sessões preservadas após atualização, reinício do navegador ou abertura de nova aba recuperam automaticamente um token CSRF ausente ou desatualizado. A recuperação exige cookie de sessão válido, rejeita identidades por chave de API e mantém a sessão principal `HttpOnly`.
29. Scans e descobertas em fila ou execução podem ser cancelados por operadores da organização correspondente. Resultados que chegam depois do cancelamento são descartados e não alteram o inventário.
30. O inventário aceita nome amigável, responsável, ambiente, criticidade, etiquetas e observações. Atualizações exigem perfil de operador, são limitadas à organização autenticada e geram evento de auditoria.
31. A pontuação contextual combina criticidade declarada e exposição observada para ordenar revisão. Ela é apresentada como prioridade operacional e nunca como confirmação automática de vulnerabilidade.
32. Mudanças adicionais geram alertas persistentes para porta não observada novamente, serviço alterado, novo subdomínio, alteração Web e certificado TLS dentro da janela configurada.
33. CSV neutraliza células iniciadas por caracteres de fórmula e o relatório HTML escapa todo conteúdo dinâmico. Ambos são filtrados pela organização da identidade autenticada.
34. A página de relatório exige sessão de navegador válida, herda `Cache-Control: no-store`, usa recursos estáticos compatíveis com CSP e não incorpora scripts ou estilos dinâmicos.
35. Cada conta pode listar e revogar somente as próprias sessões. Revogar a sessão atual remove também os cookies de sessão e CSRF.
36. A retenção é uma ação administrativa explícita, inicia em modo de simulação e registra auditoria. O comando de backup usa a API consistente do SQLite, cria arquivo restrito e não substitui um destino existente.
37. O modo de composição leve é aplicado ao login e ao painel: remove animações, `backdrop-filter`, máscaras e filtros de desfoque, limita o volume inicial do DOM e usa timeout nas consultas. A atualização automática permanece ativa, mas passa a ocorrer a cada 60 segundos e é suspensa em abas ocultas.

## Evidência fresca

- Versão 1.9.1: 95 testes aprovados.
- Cobertura do produto: 85% em 2.233 instruções medidas.
- JavaScript: sintaxe validada pelo Node.js.
- Python: pacote compilado sem erro.
- Wheel 1.9.1: construído sem isolamento de rede, extraído em diretório isolado e validado quanto a versão e recursos estáticos.
- Interface: a página exclusiva de login, o dashboard e o relatório imprimível foram carregados e inspecionados visualmente. Entrada por usuário e senha, inventário contextualizado, alertas, sessões e destaque de portas abertas foram confirmados de ponta a ponta.
- Console do navegador: nenhum erro ou aviso registrado durante entrada, carregamento e saída.
- Cookies e persistência: testes confirmaram `HttpOnly`, `SameSite=Strict`, hash do token de sessão e hash do CSRF no SQLite.
- Isolamento: testes adicionais confirmaram que inventário, contexto, relatório, exportação, cancelamento e retenção não atravessam organizações nem permissões de função.
- Exportações: testes confirmaram neutralização de fórmulas no CSV e escape de HTML no relatório.
- Os testes substituem Nmap, Gobuster, Subfinder e conexões Web/TLS por executores controlados; nenhuma varredura externa foi realizada.

## Limitações e riscos residuais

- Gobuster DNS produz consultas ativas. Use somente com autorização expressa e dimensione a taxa para o DNS do cliente.
- Alertas significam mudança observada, não vulnerabilidade confirmada.
- Rate limits são locais e pressupõem um único worker.
- O isolamento multi-tenant é lógico e testado, mas continua sobre um único SQLite e um único processo. Requisitos regulatórios de separação física devem usar uma implantação e banco por cliente.
- SQLite e rate limits locais pressupõem um único worker; PostgreSQL, fila externa e rate limiting compartilhado são necessários antes de escalar horizontalmente.
- A autenticação interna não inclui MFA, recuperação por e-mail ou integração de diretório. Para identidade corporativa centralizada, use SSO/proxy de autenticação à frente do serviço ou evolua para OIDC.
- O cancelamento impede persistência tardia, mas não encerra imediatamente um subprocesso externo que já esteja em execução; ele termina por conclusão ou timeout configurado.
- Retenção é acionada por API administrativa e backup é acionado por linha de comando. Agendamento, restauração automatizada e armazenamento externo continuam sob responsabilidade operacional da implantação.
- Ruff não pôde ser executado neste host porque o binário foi bloqueado por política de grupo. Compilação, testes, cobertura, smoke test e validação do JavaScript foram concluídos.
- O Bash não estava disponível no host Windows para executar `bash -n`; uma execução real de Nmap/Gobuster/Subfinder, o instalador, systemd e Docker ainda precisa ser validada na VM Ubuntu de destino.
- O `scanId` oficial do Codex Security não foi emitido: esta tarefa não disponibilizou `start_codex_security_prompt_only_scan` nem recebeu um `scanId` existente. O identificador não foi inventado nem incorporado ao produto.
