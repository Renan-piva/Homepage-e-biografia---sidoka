#!/usr/bin/env bash
set -euo pipefail

if [[ "${EUID}" -ne 0 ]]; then
  echo "Execute como root: sudo bash scripts/install-ubuntu.sh" >&2
  exit 1
fi

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INSTALL_DIR="/opt/asm-guardian"
DATA_DIR="/var/lib/asm-guardian"
ENV_FILE="/etc/asm-guardian.env"
GENERATED_ADMIN_PASSWORD=""

apt-get update
apt-get install -y --no-install-recommends ca-certificates gobuster nmap openssl python3 python3-pip python3-venv

if ! id asmguardian >/dev/null 2>&1; then
  useradd --system --home "${INSTALL_DIR}" --shell /usr/sbin/nologin asmguardian
fi

install -d -m 0755 "${INSTALL_DIR}/app"
install -d -m 0750 -o asmguardian -g asmguardian "${DATA_DIR}"
cp -a "${SOURCE_DIR}/asm_guardian" "${SOURCE_DIR}/pyproject.toml" "${SOURCE_DIR}/README.md" "${SOURCE_DIR}/requirements.txt" "${INSTALL_DIR}/app/"
python3 -m venv "${INSTALL_DIR}/venv"
"${INSTALL_DIR}/venv/bin/pip" install --no-cache-dir --requirement "${INSTALL_DIR}/app/requirements.txt"
"${INSTALL_DIR}/venv/bin/pip" install --no-cache-dir --no-deps "${INSTALL_DIR}/app"

if [[ ! -f "${ENV_FILE}" ]]; then
  umask 077
  API_KEY="$(openssl rand -hex 32)"
  GENERATED_ADMIN_PASSWORD="$(openssl rand -hex 16)"
  printf '%s\n' \
    "ASM_API_KEY=${API_KEY}" \
    "ASM_ADMIN_USERNAME=admin" \
    "ASM_ADMIN_PASSWORD=${GENERATED_ADMIN_PASSWORD}" \
    "ASM_SESSION_TTL_MINUTES=480" \
    "ASM_SESSION_COOKIE_SECURE=false" \
    "ASM_LOGIN_RATE_LIMIT=5" \
    "ASM_DATABASE_PATH=${DATA_DIR}/asm_guardian.db" \
    "ASM_ALLOWED_NETWORKS=127.0.0.0/8,::1/128" \
    "ASM_ALLOWED_HOSTS=" \
    "ASM_NMAP_TIMEOUT_SECONDS=3600" \
    "ASM_GOBUSTER_THREADS=5" \
    "ASM_GOBUSTER_TIMEOUT_SECONDS=300" \
    "ASM_SUBFINDER_BINARY=subfinder" \
    "ASM_SUBFINDER_RATE_LIMIT=10" \
    "ASM_SUBFINDER_TIMEOUT_SECONDS=300" \
    "ASM_WEB_PROBE_RATE_LIMIT=6" \
    "ASM_WEB_PROBE_TIMEOUT_SECONDS=5" \
    "ASM_WEB_PROBE_MAX_RESPONSE_BYTES=65536" \
    "ASM_WEB_PROBE_MAX_ADDRESSES=4" \
    "ASM_MAX_CONCURRENT_WEB_PROBES=2" \
    "ASM_FRAME_ANCESTORS='self'" \
    > "${ENV_FILE}"
fi

if ! grep -q '^ASM_ADMIN_USERNAME=' "${ENV_FILE}"; then
  printf '%s\n' "ASM_ADMIN_USERNAME=admin" >> "${ENV_FILE}"
fi
if ! grep -q '^ASM_ADMIN_PASSWORD=' "${ENV_FILE}"; then
  GENERATED_ADMIN_PASSWORD="$(openssl rand -hex 16)"
  printf '%s\n' "ASM_ADMIN_PASSWORD=${GENERATED_ADMIN_PASSWORD}" >> "${ENV_FILE}"
fi
if ! grep -q '^ASM_SESSION_TTL_MINUTES=' "${ENV_FILE}"; then
  printf '%s\n' "ASM_SESSION_TTL_MINUTES=480" >> "${ENV_FILE}"
fi
if ! grep -q '^ASM_SESSION_COOKIE_SECURE=' "${ENV_FILE}"; then
  printf '%s\n' "ASM_SESSION_COOKIE_SECURE=false" >> "${ENV_FILE}"
fi
if ! grep -q '^ASM_LOGIN_RATE_LIMIT=' "${ENV_FILE}"; then
  printf '%s\n' "ASM_LOGIN_RATE_LIMIT=5" >> "${ENV_FILE}"
fi

chown -R root:root "${INSTALL_DIR}"
chmod -R go-w "${INSTALL_DIR}"
chown -R asmguardian:asmguardian "${DATA_DIR}"
chmod 0750 "${DATA_DIR}"
find "${DATA_DIR}" -maxdepth 1 -type f -name 'asm_guardian.db*' -exec chmod 0600 {} +
chown root:root "${ENV_FILE}"
chmod 0600 "${ENV_FILE}"

if [[ ! -x "${INSTALL_DIR}/venv/bin/asm-guardian" ]]; then
  echo "Falha: o comando ${INSTALL_DIR}/venv/bin/asm-guardian nao foi criado." >&2
  exit 1
fi
"${INSTALL_DIR}/venv/bin/asm-guardian" --env-file "${ENV_FILE}" check

install -m 0644 "${SOURCE_DIR}/deploy/asm-guardian.service" /etc/systemd/system/asm-guardian.service
systemctl daemon-reload
systemctl enable asm-guardian.service
systemctl restart asm-guardian.service

echo "ASM Guardian instalado."
echo "Antes de varrer outros alvos, edite ${ENV_FILE} e configure ASM_ALLOWED_NETWORKS/ASM_ALLOWED_HOSTS."
echo "Acesse por padrao em http://127.0.0.1:8080 com usuario e senha."
echo "Consulte as credenciais iniciais com: sudo grep -E '^ASM_ADMIN_(USERNAME|PASSWORD)=' ${ENV_FILE}"
echo "A chave ASM_API_KEY permanece somente para recuperacao e integracoes automatizadas."
if ! command -v subfinder >/dev/null 2>&1; then
  echo "Subfinder nao instalado: a descoberta Gobuster e o inventario HTTP/TLS continuam disponiveis."
  echo "Consulte no README a instalacao opcional e fixada do Subfinder."
fi
