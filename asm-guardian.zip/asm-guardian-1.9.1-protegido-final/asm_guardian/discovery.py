from __future__ import annotations

import os
import re
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


BUNDLED_WORDLIST = Path(__file__).resolve().parent / "wordlists" / "dns-small.txt"
DOMAIN_RE = re.compile(
    r"(?=^.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+"
    r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$"
)
FOUND_RE = re.compile(r"(?:^|\s)Found:\s+([A-Za-z0-9.-]+)\s*$", re.IGNORECASE)
MAX_WORDLIST_BYTES = 1_048_576
MAX_DISCOVERED_HOSTS = 2_000


class GobusterExecutionError(RuntimeError):
    """A controlled Gobuster execution or output failure."""


class SubfinderExecutionError(RuntimeError):
    """A controlled Subfinder execution or output failure."""


@dataclass(frozen=True, slots=True)
class DiscoveryOutput:
    hostnames: tuple[str, ...]


def normalize_domain(domain: str) -> str:
    raw = domain.strip().rstrip(".").lower()
    if not raw or raw != domain.strip().lower() or any(char.isspace() for char in domain):
        raise ValueError("DNS discovery domain is invalid")
    try:
        normalized = raw.encode("idna").decode("ascii")
    except UnicodeError as exc:
        raise ValueError("DNS discovery domain is invalid") from exc
    if not DOMAIN_RE.fullmatch(normalized):
        raise ValueError("DNS discovery domain is invalid")
    return normalized


def parse_gobuster_dns_output(output: str, domain: str) -> tuple[str, ...]:
    normalized_domain = normalize_domain(domain)
    suffix = f".{normalized_domain}"
    found: set[str] = set()
    for line in output.splitlines():
        match = FOUND_RE.search(line.strip())
        if match is None:
            continue
        candidate = match.group(1).rstrip(".").lower()
        if DOMAIN_RE.fullmatch(candidate) and candidate.endswith(suffix):
            found.add(candidate)
            if len(found) >= MAX_DISCOVERED_HOSTS:
                break
    return tuple(sorted(found))


def parse_subfinder_output(output: str, domain: str) -> tuple[str, ...]:
    normalized_domain = normalize_domain(domain)
    suffix = f".{normalized_domain}"
    found: set[str] = set()
    for line in output.splitlines():
        candidate = line.strip().rstrip(".").lower()
        if DOMAIN_RE.fullmatch(candidate) and candidate.endswith(suffix):
            found.add(candidate)
            if len(found) >= MAX_DISCOVERED_HOSTS:
                break
    return tuple(sorted(found))


class GobusterRunner:
    def __init__(
        self,
        binary: str = "gobuster",
        wordlist: Path = BUNDLED_WORDLIST,
        threads: int = 5,
        timeout_seconds: int = 300,
    ) -> None:
        if not 1 <= threads <= 10:
            raise ValueError("Gobuster threads must be between 1 and 10")
        if not 30 <= timeout_seconds <= 1_800:
            raise ValueError("Gobuster timeout must be between 30 and 1800 seconds")
        self.binary = binary
        self.wordlist = Path(wordlist)
        self.threads = threads
        self.timeout_seconds = timeout_seconds

    def validate_wordlist(self) -> Path:
        path = self.wordlist.expanduser().resolve(strict=False)
        try:
            size = path.stat().st_size
        except OSError as exc:
            raise GobusterExecutionError("Gobuster wordlist is missing or inaccessible") from exc
        if not path.is_file() or size <= 0 or size > MAX_WORDLIST_BYTES:
            raise GobusterExecutionError("Gobuster wordlist must be a non-empty regular file up to 1 MiB")
        return path

    def build_command(self, domain: str) -> list[str]:
        normalized = normalize_domain(domain)
        wordlist = self.validate_wordlist()
        return [
            self.binary,
            "dns",
            "--domain",
            normalized,
            "--wordlist",
            str(wordlist),
            "--threads",
            str(self.threads),
            "--no-progress",
            "--no-color",
        ]

    def run(self, domain: str) -> DiscoveryOutput:
        executable = shutil.which(self.binary)
        if executable is None:
            raise GobusterExecutionError("Gobuster is not installed or ASM_GOBUSTER_BINARY is invalid")
        command = self.build_command(domain)
        command[0] = executable
        try:
            completed = subprocess.run(
                command,
                shell=False,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
                env={"PATH": os.path.dirname(executable)},
            )
        except subprocess.TimeoutExpired as exc:
            raise GobusterExecutionError("Gobuster exceeded the configured execution timeout") from exc
        except OSError as exc:
            raise GobusterExecutionError("Gobuster could not be started") from exc
        if completed.returncode != 0:
            detail = completed.stderr.strip().splitlines()[-1] if completed.stderr.strip() else "unknown error"
            raise GobusterExecutionError(f"Gobuster exited with status {completed.returncode}: {detail[:300]}")
        return DiscoveryOutput(parse_gobuster_dns_output(completed.stdout, domain))


class SubfinderRunner:
    def __init__(
        self,
        binary: str = "subfinder",
        home: Path = Path("data"),
        rate_limit: int = 10,
        timeout_seconds: int = 300,
    ) -> None:
        if not 1 <= rate_limit <= 50:
            raise ValueError("Subfinder rate limit must be between 1 and 50")
        if not 30 <= timeout_seconds <= 1_800:
            raise ValueError("Subfinder timeout must be between 30 and 1800 seconds")
        self.binary = binary
        self.home = Path(home)
        self.rate_limit = rate_limit
        self.timeout_seconds = timeout_seconds

    def build_command(self, domain: str) -> list[str]:
        normalized = normalize_domain(domain)
        return [
            self.binary,
            "-d",
            normalized,
            "-silent",
            "-duc",
            "-rl",
            str(self.rate_limit),
        ]

    def run(self, domain: str) -> DiscoveryOutput:
        executable = shutil.which(self.binary)
        if executable is None:
            raise SubfinderExecutionError("Subfinder is not installed or ASM_SUBFINDER_BINARY is invalid")
        command = self.build_command(domain)
        command[0] = executable
        try:
            completed = subprocess.run(
                command,
                shell=False,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
                env={"PATH": os.path.dirname(executable), "HOME": str(self.home)},
            )
        except subprocess.TimeoutExpired as exc:
            raise SubfinderExecutionError("Subfinder exceeded the configured execution timeout") from exc
        except OSError as exc:
            raise SubfinderExecutionError("Subfinder could not be started") from exc
        if completed.returncode != 0:
            detail = completed.stderr.strip().splitlines()[-1] if completed.stderr.strip() else "unknown error"
            raise SubfinderExecutionError(f"Subfinder exited with status {completed.returncode}: {detail[:300]}")
        return DiscoveryOutput(parse_subfinder_output(completed.stdout, domain))
