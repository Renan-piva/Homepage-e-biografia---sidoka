from __future__ import annotations

import ipaddress
import shutil
import subprocess
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path


class NmapExecutionError(RuntimeError):
    """A controlled Nmap execution or parsing failure."""


@dataclass(frozen=True, slots=True)
class ScanOutput:
    hosts: tuple[dict, ...]
    findings: tuple[dict, ...]


class NmapRunner:
    def __init__(self, binary: str = "nmap", max_rate: int = 50, timeout_seconds: int = 180) -> None:
        self.binary = binary
        self.max_rate = max_rate
        self.timeout_seconds = timeout_seconds

    def build_command(
        self,
        addresses: tuple[str, ...],
        ports: tuple[int, ...],
        service_detection: bool,
        port_profile: str = "custom",
    ) -> list[str]:
        if not addresses or len(addresses) > 8:
            raise ValueError("Between 1 and 8 target addresses are required")
        normalized_addresses = [str(ipaddress.ip_address(item)) for item in addresses]
        normalized_ports = sorted(set(ports))
        if port_profile not in {"custom", "top-1000", "all-tcp"}:
            raise ValueError("Unknown port profile")
        if port_profile == "custom" and (not normalized_ports or len(normalized_ports) > 4096):
            raise ValueError("Between 1 and 4096 unique custom ports are required")
        if port_profile != "custom" and normalized_ports:
            raise ValueError("Explicit ports are allowed only with the custom profile")
        if any(port < 1 or port > 65535 for port in normalized_ports):
            raise ValueError("Ports must be between 1 and 65535")

        host_timeout_seconds = max(30, self.timeout_seconds - 60)
        host_timeout = (
            f"{host_timeout_seconds // 60}m" if host_timeout_seconds % 60 == 0 else f"{host_timeout_seconds}s"
        )

        command = [
            self.binary,
            "-sT",
            "-n",
            "--open",
            "-T2",
            "--max-retries",
            "2",
            "--host-timeout",
            host_timeout,
            "--max-rate",
            str(self.max_rate),
        ]
        if port_profile == "custom":
            command.extend(["-p", ",".join(str(port) for port in normalized_ports)])
        elif port_profile == "top-1000":
            command.extend(["--top-ports", "1000"])
        else:
            command.extend(["-p", "1-65535"])
        if service_detection:
            command.extend(["-sV", "--version-light"])
        command.extend(["-oX", "-"])
        command.extend(normalized_addresses)
        return command

    def run(
        self,
        addresses: tuple[str, ...],
        ports: tuple[int, ...],
        service_detection: bool = False,
        port_profile: str = "custom",
    ) -> ScanOutput:
        executable = shutil.which(self.binary)
        if executable is None:
            raise NmapExecutionError("Nmap is not installed or ASM_NMAP_BINARY is invalid")
        command = self.build_command(addresses, ports, service_detection, port_profile)
        command[0] = executable
        try:
            completed = subprocess.run(
                command,
                shell=False,
                capture_output=True,
                text=True,
                timeout=self.timeout_seconds,
                check=False,
                env={"PATH": str(Path(executable).parent)},
            )
        except subprocess.TimeoutExpired as exc:
            raise NmapExecutionError("Nmap exceeded the configured execution timeout") from exc
        except OSError as exc:
            raise NmapExecutionError("Nmap could not be started") from exc
        if completed.returncode != 0:
            detail = completed.stderr.strip().splitlines()[-1] if completed.stderr.strip() else "unknown error"
            raise NmapExecutionError(f"Nmap exited with status {completed.returncode}: {detail[:300]}")
        return parse_nmap_xml(completed.stdout)


def parse_nmap_xml(xml_text: str) -> ScanOutput:
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        raise NmapExecutionError("Nmap returned malformed XML") from exc
    if root.tag != "nmaprun":
        raise NmapExecutionError("Nmap XML has an unexpected root element")

    hosts: list[dict] = []
    findings: list[dict] = []
    for host in root.findall("host"):
        status = host.find("status")
        state = status.get("state", "unknown") if status is not None else "unknown"
        addresses = [node.get("addr", "") for node in host.findall("address") if node.get("addr")]
        primary_ip = next((item for item in addresses if _is_ip(item)), "")
        hostname_node = host.find("hostnames/hostname")
        hostname = hostname_node.get("name", "") if hostname_node is not None else ""
        hosts.append({"ip": primary_ip, "hostname": hostname, "state": state})
        for port in host.findall("ports/port"):
            port_state = port.find("state")
            if port_state is None or port_state.get("state") != "open":
                continue
            service = port.find("service")
            findings.append(
                {
                    "ip": primary_ip,
                    "hostname": hostname,
                    "port": int(port.get("portid", "0")),
                    "protocol": port.get("protocol", "tcp"),
                    "state": "open",
                    "service": service.get("name", "") if service is not None else "",
                    "product": service.get("product", "") if service is not None else "",
                    "version": service.get("version", "") if service is not None else "",
                }
            )
    return ScanOutput(hosts=tuple(hosts), findings=tuple(findings))


def _is_ip(value: str) -> bool:
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return False
    return True
