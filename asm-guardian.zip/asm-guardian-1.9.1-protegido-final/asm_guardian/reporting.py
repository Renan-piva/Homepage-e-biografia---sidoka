from __future__ import annotations

import csv
import html
import io
from typing import Any


def _spreadsheet_safe(value: Any) -> str:
    rendered = "" if value is None else str(value)
    if rendered.startswith(("=", "+", "-", "@")):
        return f"'{rendered}"
    return rendered


def assets_csv(inventory: list[dict[str, Any]]) -> str:
    output = io.StringIO(newline="")
    writer = csv.writer(output)
    writer.writerow(
        (
            "ip",
            "hostname",
            "nome",
            "responsavel",
            "ambiente",
            "criticidade",
            "risco",
            "pontuacao",
            "portas_abertas",
            "servicos",
            "tags",
            "ultima_observacao",
        )
    )
    for item in inventory:
        writer.writerow(
            tuple(
                _spreadsheet_safe(value)
                for value in (
                    item["ip"],
                    item["hostname"],
                    item["display_name"],
                    item["owner"],
                    item["environment"],
                    item["criticality"],
                    item["risk_level"],
                    item["risk_score"],
                    ",".join(str(port) for port in item["open_ports"]),
                    " | ".join(item["services"]),
                    ",".join(item["tags"]),
                    item["last_observed_at"],
                )
            )
        )
    return output.getvalue()


def printable_report(summary: dict[str, Any]) -> str:
    def escaped(value: Any) -> str:
        return html.escape(str(value), quote=True)

    overview = summary["overview"]
    asset_rows = "".join(
        "<tr>"
        f"<td>{escaped(item['display_name'] or item['hostname'] or item['ip'])}</td>"
        f"<td>{escaped(item['ip'])}</td>"
        f"<td>{escaped(', '.join(str(port) for port in item['open_ports']))}</td>"
        f"<td>{escaped(item['risk_level'])} ({escaped(item['risk_score'])})</td>"
        f"<td>{escaped(item['owner'] or 'Não definido')}</td>"
        "</tr>"
        for item in summary["inventory"]
    ) or '<tr><td colspan="5">Nenhum ativo observado.</td></tr>'
    alert_rows = "".join(
        "<tr>"
        f"<td>{escaped(item['title'])}</td>"
        f"<td>{escaped(item['target'])}</td>"
        f"<td>{escaped(item['severity'])}</td>"
        f"<td>{escaped(item['created_at'])}</td>"
        "</tr>"
        for item in summary["alerts"]
    ) or '<tr><td colspan="4">Nenhum alerta pendente.</td></tr>'
    return f"""<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Relatório ASM Guardian</title>
  <link rel="stylesheet" href="/static/report.css?v=1.9.1">
</head>
<body>
  <header><div><span>ASM GUARDIAN</span><h1>Resumo da superfície de ataque</h1></div><button id="print-report" type="button">Imprimir / salvar PDF</button></header>
  <p class="generated">Gerado em {escaped(summary['generated_at'])} · organização {escaped(summary['tenant']['name'])}</p>
  <section class="metrics">
    <article><small>Ativos</small><strong>{overview['assets']}</strong></article>
    <article><small>Portas abertas</small><strong>{overview['open_ports']}</strong></article>
    <article><small>Scans</small><strong>{overview['scans']}</strong></article>
    <article><small>Alertas pendentes</small><strong>{overview['unacknowledged_alerts']}</strong></article>
  </section>
  <section><h2>Inventário priorizado</h2><table><thead><tr><th>Ativo</th><th>Endereço</th><th>Portas</th><th>Risco</th><th>Responsável</th></tr></thead><tbody>{asset_rows}</tbody></table></section>
  <section><h2>Mudanças pendentes</h2><table><thead><tr><th>Evento</th><th>Alvo</th><th>Severidade</th><th>Data</th></tr></thead><tbody>{alert_rows}</tbody></table></section>
  <footer>Leitura defensiva. Porta aberta não representa, isoladamente, vulnerabilidade confirmada.</footer>
  <script src="/static/report.js?v=1.9.1" defer></script>
</body>
</html>"""
