from __future__ import annotations

import hmac
import ipaddress
import re
import socket
import threading
import time
from collections import deque
from collections.abc import Callable, Iterable
from dataclasses import dataclass


HOST_RE = re.compile(r"(?=^.{1,253}\.?$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.?$")


class ScopeError(ValueError):
    """Raised when a target is invalid or outside the configured scope."""


@dataclass(frozen=True, slots=True)
class ResolvedTarget:
    requested: str
    addresses: tuple[str, ...]


class ScopePolicy:
    def __init__(
        self,
        networks: Iterable[str],
        hosts: Iterable[str] = (),
        max_addresses: int = 8,
    ) -> None:
        try:
            self.networks = tuple(ipaddress.ip_network(item, strict=True) for item in networks)
        except ValueError as exc:
            raise ValueError(f"Invalid allowlist network: {exc}") from exc
        if not self.networks:
            raise ValueError("The network allowlist cannot be empty")
        self.hosts = tuple(self._normalize_pattern(item) for item in hosts)
        self.max_addresses = max_addresses

    @staticmethod
    def _normalize_hostname(host: str) -> str:
        value = host.strip().rstrip(".").lower()
        try:
            value = value.encode("idna").decode("ascii")
        except UnicodeError as exc:
            raise ScopeError("Target hostname is invalid") from exc
        if not HOST_RE.fullmatch(value):
            raise ScopeError("Target must be a plain IP address or hostname")
        return value

    @classmethod
    def _normalize_pattern(cls, pattern: str) -> str:
        value = pattern.strip().lower()
        if value.startswith("*."):
            return "*." + cls._normalize_hostname(value[2:])
        return cls._normalize_hostname(value)

    def _ip_allowed(self, address: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
        return any(address.version == network.version and address in network for network in self.networks)

    def _host_allowed(self, host: str) -> bool:
        for pattern in self.hosts:
            if pattern.startswith("*."):
                suffix = pattern[1:]
                if host.endswith(suffix) and host != pattern[2:]:
                    return True
            elif hmac.compare_digest(host, pattern):
                return True
        return False

    def authorize_discovery_domain(self, domain: str) -> str:
        """Authorize DNS enumeration only for an explicitly allowlisted domain."""
        if domain != domain.strip() or any(char.isspace() for char in domain):
            raise ScopeError("DNS discovery domain contains whitespace or is empty")
        normalized = self._normalize_hostname(domain)
        if any(
            hmac.compare_digest(normalized, pattern[2:] if pattern.startswith("*.") else pattern)
            for pattern in self.hosts
        ):
            return normalized
        raise ScopeError("DNS discovery domain is not present in ASM_ALLOWED_HOSTS")

    def resolve_target(
        self,
        target: str,
        resolver: Callable[..., list[tuple]] = socket.getaddrinfo,
    ) -> ResolvedTarget:
        raw = target.strip()
        if not raw or raw != target or any(char.isspace() for char in raw):
            raise ScopeError("Target contains whitespace or is empty")
        try:
            address = ipaddress.ip_address(raw)
        except ValueError:
            host = self._normalize_hostname(raw)
            if not self._host_allowed(host):
                raise ScopeError("Hostname is not present in ASM_ALLOWED_HOSTS")
            try:
                records = resolver(host, None, type=socket.SOCK_STREAM)
            except socket.gaierror as exc:
                raise ScopeError("Hostname could not be resolved") from exc
            addresses = sorted({str(ipaddress.ip_address(record[4][0])) for record in records})
            if not addresses:
                raise ScopeError("Hostname resolved to no addresses")
            if len(addresses) > self.max_addresses:
                raise ScopeError(f"Hostname resolves to more than {self.max_addresses} addresses")
            if any(not self._ip_allowed(ipaddress.ip_address(item)) for item in addresses):
                raise ScopeError("Every resolved address must be inside ASM_ALLOWED_NETWORKS")
            return ResolvedTarget(requested=host, addresses=tuple(addresses))
        if not self._ip_allowed(address):
            raise ScopeError("IP address is outside ASM_ALLOWED_NETWORKS")
        return ResolvedTarget(requested=str(address), addresses=(str(address),))


class SlidingWindowLimiter:
    def __init__(self, window_seconds: int = 60, max_keys: int = 10_000) -> None:
        if window_seconds <= 0 or max_keys <= 0:
            raise ValueError("window_seconds and max_keys must be positive")
        self.window_seconds = window_seconds
        self.max_keys = max_keys
        self._events: dict[str, deque[float]] = {}
        self._last_cleanup: float | None = None
        self._lock = threading.Lock()

    def allow(self, key: str, limit: int, now: float | None = None) -> bool:
        if limit <= 0:
            raise ValueError("limit must be positive")
        current = time.monotonic() if now is None else now
        cutoff = current - self.window_seconds
        with self._lock:
            if self._last_cleanup is None or current - self._last_cleanup >= self.window_seconds:
                for stored_key, stored_events in tuple(self._events.items()):
                    while stored_events and stored_events[0] <= cutoff:
                        stored_events.popleft()
                    if not stored_events:
                        del self._events[stored_key]
                self._last_cleanup = current

            events = self._events.get(key)
            if events is None:
                if len(self._events) >= self.max_keys:
                    return False
                events = deque()
                self._events[key] = events
            while events and events[0] <= cutoff:
                events.popleft()
            if len(events) >= limit:
                return False
            events.append(current)
            return True
