from __future__ import annotations

import json
import sqlite3
import uuid
from contextlib import closing
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any


DEFAULT_TENANT_ID = "default"


def utc_now() -> datetime:
    return datetime.now(UTC)


def iso(value: datetime | None = None) -> str:
    return (value or utc_now()).isoformat(timespec="seconds")


class Database:
    def __init__(self, path: Path) -> None:
        self.path = path

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=10, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys = ON")
        connection.execute("PRAGMA busy_timeout = 10000")
        return connection

    def initialize(
        self,
        default_allowed_networks: tuple[str, ...] = ("127.0.0.0/8",),
        default_allowed_hosts: tuple[str, ...] = (),
    ) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self.connect()) as connection:
            connection.execute("PRAGMA journal_mode = WAL")
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS tenants (
                    id TEXT PRIMARY KEY,
                    slug TEXT NOT NULL UNIQUE,
                    name TEXT NOT NULL,
                    allowed_networks TEXT NOT NULL,
                    allowed_hosts TEXT NOT NULL DEFAULT '[]',
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS monitors (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    name TEXT NOT NULL,
                    target TEXT NOT NULL,
                    ports TEXT NOT NULL,
                    port_profile TEXT NOT NULL DEFAULT 'custom',
                    service_detection INTEGER NOT NULL DEFAULT 0,
                    interval_minutes INTEGER NOT NULL CHECK(interval_minutes BETWEEN 15 AND 10080),
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    last_run_at TEXT,
                    next_run_at TEXT NOT NULL,
                    last_error TEXT
                );

                CREATE TABLE IF NOT EXISTS scans (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    monitor_id TEXT REFERENCES monitors(id) ON DELETE SET NULL,
                    target TEXT NOT NULL,
                    resolved_targets TEXT NOT NULL,
                    ports TEXT NOT NULL,
                    port_profile TEXT NOT NULL DEFAULT 'custom',
                    service_detection INTEGER NOT NULL DEFAULT 0,
                    status TEXT NOT NULL CHECK(status IN ('queued','running','completed','failed')),
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    completed_at TEXT,
                    error TEXT,
                    cancelled_at TEXT
                );

                CREATE TABLE IF NOT EXISTS scan_hosts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id TEXT NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
                    target TEXT NOT NULL,
                    ip TEXT NOT NULL,
                    hostname TEXT NOT NULL DEFAULT '',
                    state TEXT NOT NULL,
                    observed_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS findings (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_id TEXT NOT NULL REFERENCES scans(id) ON DELETE CASCADE,
                    target TEXT NOT NULL,
                    ip TEXT NOT NULL,
                    hostname TEXT NOT NULL DEFAULT '',
                    port INTEGER NOT NULL CHECK(port BETWEEN 1 AND 65535),
                    protocol TEXT NOT NULL,
                    state TEXT NOT NULL,
                    service TEXT NOT NULL DEFAULT '',
                    product TEXT NOT NULL DEFAULT '',
                    version TEXT NOT NULL DEFAULT '',
                    observed_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS api_keys (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    name TEXT NOT NULL,
                    prefix TEXT NOT NULL UNIQUE,
                    key_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('admin','operator','viewer')),
                    created_at TEXT NOT NULL,
                    created_by TEXT NOT NULL,
                    expires_at TEXT,
                    last_used_at TEXT,
                    revoked_at TEXT
                );

                CREATE TABLE IF NOT EXISTS users (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                    display_name TEXT NOT NULL,
                    password_hash TEXT NOT NULL,
                    role TEXT NOT NULL CHECK(role IN ('admin','operator','viewer')),
                    system_admin INTEGER NOT NULL DEFAULT 0,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    created_at TEXT NOT NULL,
                    created_by TEXT NOT NULL,
                    password_changed_at TEXT NOT NULL,
                    last_login_at TEXT
                );

                CREATE TABLE IF NOT EXISTS user_sessions (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
                    token_hash TEXT NOT NULL UNIQUE,
                    csrf_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    last_seen_at TEXT NOT NULL,
                    revoked_at TEXT
                );

                CREATE TABLE IF NOT EXISTS security_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    actor_id TEXT NOT NULL,
                    actor_name TEXT NOT NULL,
                    action TEXT NOT NULL,
                    target_id TEXT,
                    created_at TEXT NOT NULL,
                    details TEXT NOT NULL DEFAULT '{}'
                );

                CREATE TABLE IF NOT EXISTS discoveries (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    domain TEXT NOT NULL,
                    engine TEXT NOT NULL DEFAULT 'gobuster',
                    status TEXT NOT NULL CHECK(status IN ('queued','running','completed','failed')),
                    created_at TEXT NOT NULL,
                    started_at TEXT,
                    completed_at TEXT,
                    found_count INTEGER NOT NULL DEFAULT 0,
                    error TEXT,
                    cancelled_at TEXT
                );

                CREATE TABLE IF NOT EXISTS discovered_hosts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    discovery_id TEXT NOT NULL REFERENCES discoveries(id) ON DELETE CASCADE,
                    domain TEXT NOT NULL,
                    hostname TEXT NOT NULL,
                    observed_at TEXT NOT NULL,
                    UNIQUE(discovery_id, hostname)
                );

                CREATE TABLE IF NOT EXISTS web_observations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    target TEXT NOT NULL,
                    ip TEXT NOT NULL,
                    scheme TEXT NOT NULL CHECK(scheme IN ('http','https')),
                    port INTEGER NOT NULL CHECK(port BETWEEN 1 AND 65535),
                    status_code INTEGER CHECK(status_code BETWEEN 100 AND 599),
                    title TEXT NOT NULL DEFAULT '',
                    server TEXT NOT NULL DEFAULT '',
                    content_type TEXT NOT NULL DEFAULT '',
                    location TEXT NOT NULL DEFAULT '',
                    tls_subject TEXT NOT NULL DEFAULT '',
                    tls_issuer TEXT NOT NULL DEFAULT '',
                    tls_not_after TEXT,
                    tls_days_remaining INTEGER,
                    error TEXT NOT NULL DEFAULT '',
                    observed_at TEXT NOT NULL
                );

                CREATE TABLE IF NOT EXISTS alerts (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    kind TEXT NOT NULL CHECK(kind IN (
                        'new_asset','new_open_port','closed_port','service_changed',
                        'new_subdomain','tls_expiring','web_changed'
                    )),
                    severity TEXT NOT NULL CHECK(severity IN ('info','low','medium','high')),
                    title TEXT NOT NULL,
                    target TEXT NOT NULL,
                    ip TEXT NOT NULL,
                    port INTEGER CHECK(port BETWEEN 1 AND 65535),
                    protocol TEXT,
                    source_type TEXT NOT NULL DEFAULT 'scan',
                    source_id TEXT,
                    scan_id TEXT REFERENCES scans(id) ON DELETE CASCADE,
                    created_at TEXT NOT NULL,
                    acknowledged_at TEXT
                );

                CREATE TABLE IF NOT EXISTS asset_metadata (
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    ip TEXT NOT NULL,
                    display_name TEXT NOT NULL DEFAULT '',
                    owner TEXT NOT NULL DEFAULT '',
                    environment TEXT NOT NULL DEFAULT 'unknown',
                    criticality TEXT NOT NULL DEFAULT 'medium'
                        CHECK(criticality IN ('low','medium','high','critical')),
                    tags TEXT NOT NULL DEFAULT '[]',
                    notes TEXT NOT NULL DEFAULT '',
                    updated_at TEXT NOT NULL,
                    updated_by TEXT NOT NULL,
                    PRIMARY KEY (tenant_id, ip)
                );

                CREATE INDEX IF NOT EXISTS idx_scans_created_at ON scans(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_findings_asset ON findings(ip, port, observed_at DESC);
                CREATE INDEX IF NOT EXISTS idx_monitors_due ON monitors(enabled, next_run_at);
                CREATE INDEX IF NOT EXISTS idx_api_keys_prefix ON api_keys(prefix);
                CREATE INDEX IF NOT EXISTS idx_users_tenant_created ON users(tenant_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(token_hash);
                CREATE INDEX IF NOT EXISTS idx_user_sessions_expiry ON user_sessions(expires_at);
                CREATE INDEX IF NOT EXISTS idx_security_events_created ON security_events(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_discoveries_created ON discoveries(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_discovered_hosts_name ON discovered_hosts(hostname, observed_at DESC);
                CREATE INDEX IF NOT EXISTS idx_web_observations_asset
                    ON web_observations(target, ip, scheme, port, observed_at DESC);
                CREATE INDEX IF NOT EXISTS idx_alerts_created ON alerts(created_at DESC);
                """
            )
            connection.execute(
                """INSERT INTO tenants
                   (id,slug,name,allowed_networks,allowed_hosts,enabled,created_at)
                   VALUES (?,?,?,?,?,1,?)
                   ON CONFLICT(id) DO UPDATE SET
                       allowed_networks=excluded.allowed_networks,
                       allowed_hosts=excluded.allowed_hosts""",
                (
                    DEFAULT_TENANT_ID,
                    "default",
                    "Organização padrão",
                    json.dumps(default_allowed_networks),
                    json.dumps(default_allowed_hosts),
                    iso(),
                ),
            )
            self._add_column_if_missing(connection, "scans", "port_profile", "TEXT NOT NULL DEFAULT 'custom'")
            self._add_column_if_missing(connection, "scans", "cancelled_at", "TEXT")
            self._add_column_if_missing(connection, "monitors", "port_profile", "TEXT NOT NULL DEFAULT 'custom'")
            self._add_column_if_missing(connection, "discoveries", "engine", "TEXT NOT NULL DEFAULT 'gobuster'")
            self._add_column_if_missing(connection, "discoveries", "cancelled_at", "TEXT")
            self._migrate_alerts_table(connection)
            for table in (
                "monitors",
                "scans",
                "api_keys",
                "security_events",
                "discoveries",
                "web_observations",
                "alerts",
            ):
                self._add_column_if_missing(
                    connection,
                    table,
                    "tenant_id",
                    f"TEXT NOT NULL DEFAULT '{DEFAULT_TENANT_ID}'",
                )
            connection.executescript(
                """
                CREATE INDEX IF NOT EXISTS idx_scans_tenant_created
                    ON scans(tenant_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_monitors_tenant_created
                    ON monitors(tenant_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_api_keys_tenant_created
                    ON api_keys(tenant_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_discoveries_tenant_created
                    ON discoveries(tenant_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_web_tenant_observed
                    ON web_observations(tenant_id, observed_at DESC);
                CREATE INDEX IF NOT EXISTS idx_alerts_tenant_created
                    ON alerts(tenant_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_alerts_created
                    ON alerts(created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_security_events_tenant_created
                    ON security_events(tenant_id, created_at DESC);
                CREATE INDEX IF NOT EXISTS idx_asset_metadata_tenant
                    ON asset_metadata(tenant_id, updated_at DESC);
                """
            )

    def create_user(
        self,
        *,
        user_id: str,
        tenant_id: str,
        username: str,
        display_name: str,
        password_hash: str,
        role: str,
        system_admin: bool,
        actor_id: str,
        actor_name: str,
    ) -> dict[str, Any]:
        created_at = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                connection.execute(
                    """INSERT INTO users
                       (id,tenant_id,username,display_name,password_hash,role,system_admin,enabled,
                        created_at,created_by,password_changed_at)
                       VALUES (?,?,?,?,?,?,?,1,?,?,?)""",
                    (
                        user_id,
                        tenant_id,
                        username,
                        display_name,
                        password_hash,
                        role,
                        int(system_admin),
                        created_at,
                        actor_name,
                        created_at,
                    ),
                )
                self._insert_security_event(
                    connection,
                    tenant_id,
                    actor_id,
                    actor_name,
                    "user.created",
                    user_id,
                    {"username": username, "role": role, "system_admin": system_admin},
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        result = self.get_user(user_id, tenant_id)
        if result is None:
            raise RuntimeError("Created user could not be read")
        return self._public_user(result)

    def get_user_by_username(self, username: str) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute("SELECT * FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
            return dict(row) if row else None

    def get_user(self, user_id: str, tenant_id: str | None = DEFAULT_TENANT_ID) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            if tenant_id is None:
                row = connection.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
            else:
                row = connection.execute(
                    "SELECT * FROM users WHERE id=? AND tenant_id=?", (user_id, tenant_id)
                ).fetchone()
            return dict(row) if row else None

    def list_users(self, tenant_id: str | None = DEFAULT_TENANT_ID) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            if tenant_id is None:
                rows = connection.execute("SELECT * FROM users ORDER BY created_at,id").fetchall()
            else:
                rows = connection.execute(
                    "SELECT * FROM users WHERE tenant_id=? ORDER BY created_at,id", (tenant_id,)
                ).fetchall()
            return [self._public_user(dict(row)) for row in rows]

    @staticmethod
    def _public_user(value: dict[str, Any]) -> dict[str, Any]:
        result = {key: item for key, item in value.items() if key != "password_hash"}
        result["enabled"] = bool(result["enabled"])
        result["system_admin"] = bool(result["system_admin"])
        return result

    def create_user_session(
        self,
        *,
        session_id: str,
        user_id: str,
        token_hash: str,
        csrf_hash: str,
        expires_at: str,
    ) -> None:
        now = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                connection.execute(
                    "DELETE FROM user_sessions WHERE expires_at<=? OR revoked_at IS NOT NULL",
                    (now,),
                )
                connection.execute(
                    """INSERT INTO user_sessions
                       (id,user_id,token_hash,csrf_hash,created_at,expires_at,last_seen_at)
                       VALUES (?,?,?,?,?,?,?)""",
                    (session_id, user_id, token_hash, csrf_hash, now, expires_at, now),
                )
                user = connection.execute(
                    "SELECT tenant_id,username,display_name FROM users WHERE id=?", (user_id,)
                ).fetchone()
                if user is None:
                    raise RuntimeError("User was removed while creating the session")
                connection.execute("UPDATE users SET last_login_at=? WHERE id=?", (now, user_id))
                self._insert_security_event(
                    connection,
                    user["tenant_id"],
                    user_id,
                    user["display_name"],
                    "auth.login",
                    session_id,
                    {"username": user["username"]},
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise

    def get_user_session(self, token_hash: str) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute(
                """SELECT s.id AS session_id,s.token_hash,s.csrf_hash,s.created_at AS session_created_at,
                          s.expires_at,s.last_seen_at,s.revoked_at,
                          u.id,u.tenant_id,u.username,u.display_name,u.password_hash,u.role,
                          u.system_admin,u.enabled,u.last_login_at,t.name AS tenant_name,t.enabled AS tenant_enabled
                   FROM user_sessions s
                   JOIN users u ON u.id=s.user_id
                   JOIN tenants t ON t.id=u.tenant_id
                   WHERE s.token_hash=?""",
                (token_hash,),
            ).fetchone()
            return dict(row) if row else None

    def touch_user_session(self, session_id: str) -> None:
        threshold = iso(utc_now() - timedelta(minutes=1))
        with closing(self.connect()) as connection:
            connection.execute(
                """UPDATE user_sessions SET last_seen_at=?
                   WHERE id=? AND last_seen_at<? AND revoked_at IS NULL""",
                (iso(), session_id, threshold),
            )

    def update_user_session_csrf(self, session_id: str, csrf_hash: str) -> bool:
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                """UPDATE user_sessions SET csrf_hash=?,last_seen_at=?
                   WHERE id=? AND revoked_at IS NULL AND expires_at>?""",
                (csrf_hash, iso(), session_id, iso()),
            )
            return cursor.rowcount > 0

    def revoke_user_session(self, token_hash: str) -> bool:
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT s.id,u.id AS user_id,u.tenant_id,u.display_name,u.username,s.revoked_at
                   FROM user_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=?""",
                (token_hash,),
            ).fetchone()
            if row is None or row["revoked_at"]:
                connection.rollback()
                return False
            connection.execute("UPDATE user_sessions SET revoked_at=? WHERE id=?", (iso(), row["id"]))
            self._insert_security_event(
                connection,
                row["tenant_id"],
                row["user_id"],
                row["display_name"],
                "auth.logout",
                row["id"],
                {"username": row["username"]},
            )
            connection.commit()
            return True

    def list_user_sessions(self, user_id: str) -> list[dict[str, Any]]:
        now = utc_now()
        with closing(self.connect()) as connection:
            rows = connection.execute(
                """SELECT id,created_at,expires_at,last_seen_at,revoked_at
                   FROM user_sessions WHERE user_id=? ORDER BY created_at DESC,id DESC""",
                (user_id,),
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            if item["revoked_at"]:
                item["status"] = "revoked"
            elif datetime.fromisoformat(item["expires_at"]) <= now:
                item["status"] = "expired"
            else:
                item["status"] = "active"
            result.append(item)
        return result

    def revoke_user_session_by_id(
        self,
        *,
        session_id: str,
        user_id: str,
        tenant_id: str,
        actor_name: str,
    ) -> bool:
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT revoked_at FROM user_sessions WHERE id=? AND user_id=?",
                (session_id, user_id),
            ).fetchone()
            if row is None or row["revoked_at"]:
                connection.rollback()
                return False
            connection.execute("UPDATE user_sessions SET revoked_at=? WHERE id=?", (iso(), session_id))
            self._insert_security_event(
                connection,
                tenant_id,
                user_id,
                actor_name,
                "auth.session_revoked",
                session_id,
                {},
            )
            connection.commit()
            return True

    def update_user_password(
        self,
        *,
        user_id: str,
        tenant_id: str,
        password_hash: str,
        actor_id: str,
        actor_name: str,
    ) -> bool:
        now = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            user = connection.execute(
                "SELECT username FROM users WHERE id=? AND tenant_id=? AND enabled=1",
                (user_id, tenant_id),
            ).fetchone()
            if user is None:
                connection.rollback()
                return False
            connection.execute(
                "UPDATE users SET password_hash=?,password_changed_at=? WHERE id=?",
                (password_hash, now, user_id),
            )
            connection.execute(
                "UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL",
                (now, user_id),
            )
            self._insert_security_event(
                connection,
                tenant_id,
                actor_id,
                actor_name,
                "user.password_changed",
                user_id,
                {"username": user["username"]},
            )
            connection.commit()
            return True

    def disable_user(
        self,
        *,
        user_id: str,
        tenant_id: str,
        actor_id: str,
        actor_name: str,
    ) -> bool:
        now = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            user = connection.execute(
                "SELECT username,enabled FROM users WHERE id=? AND tenant_id=?",
                (user_id, tenant_id),
            ).fetchone()
            if user is None or not user["enabled"]:
                connection.rollback()
                return False
            connection.execute("UPDATE users SET enabled=0 WHERE id=?", (user_id,))
            connection.execute(
                "UPDATE user_sessions SET revoked_at=? WHERE user_id=? AND revoked_at IS NULL",
                (now, user_id),
            )
            self._insert_security_event(
                connection,
                tenant_id,
                actor_id,
                actor_name,
                "user.disabled",
                user_id,
                {"username": user["username"]},
            )
            connection.commit()
            return True

    @staticmethod
    def _migrate_alerts_table(connection: sqlite3.Connection) -> None:
        row = connection.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='alerts'"
        ).fetchone()
        if row is None or "closed_port" in (row["sql"] or ""):
            return

        connection.execute("PRAGMA foreign_keys = OFF")
        try:
            connection.executescript(
                """
                BEGIN IMMEDIATE;
                ALTER TABLE alerts RENAME TO alerts_legacy_v183;
                CREATE TABLE alerts (
                    id TEXT PRIMARY KEY,
                    tenant_id TEXT NOT NULL DEFAULT 'default' REFERENCES tenants(id),
                    kind TEXT NOT NULL CHECK(kind IN (
                        'new_asset','new_open_port','closed_port','service_changed',
                        'new_subdomain','tls_expiring','web_changed'
                    )),
                    severity TEXT NOT NULL CHECK(severity IN ('info','low','medium','high')),
                    title TEXT NOT NULL,
                    target TEXT NOT NULL,
                    ip TEXT NOT NULL,
                    port INTEGER CHECK(port BETWEEN 1 AND 65535),
                    protocol TEXT,
                    source_type TEXT NOT NULL DEFAULT 'scan',
                    source_id TEXT,
                    scan_id TEXT REFERENCES scans(id) ON DELETE CASCADE,
                    created_at TEXT NOT NULL,
                    acknowledged_at TEXT
                );
                INSERT INTO alerts
                    (id,tenant_id,kind,severity,title,target,ip,port,protocol,
                     source_type,source_id,scan_id,created_at,acknowledged_at)
                SELECT id,tenant_id,kind,severity,title,target,ip,port,protocol,
                       'scan',scan_id,scan_id,created_at,acknowledged_at
                FROM alerts_legacy_v183;
                DROP TABLE alerts_legacy_v183;
                COMMIT;
                """
            )
        except Exception:
            if connection.in_transaction:
                connection.rollback()
            raise
        finally:
            connection.execute("PRAGMA foreign_keys = ON")

    @staticmethod
    def _add_column_if_missing(
        connection: sqlite3.Connection,
        table: str,
        column: str,
        definition: str,
    ) -> None:
        columns = {row["name"] for row in connection.execute(f"PRAGMA table_info({table})")}
        if column not in columns:
            connection.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

    def create_tenant(
        self,
        *,
        slug: str,
        name: str,
        allowed_networks: tuple[str, ...],
        allowed_hosts: tuple[str, ...],
        actor_id: str,
        actor_name: str,
    ) -> dict[str, Any]:
        tenant_id = str(uuid.uuid4())
        created_at = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO tenants
                   (id,slug,name,allowed_networks,allowed_hosts,enabled,created_at)
                   VALUES (?,?,?,?,?,1,?)""",
                (
                    tenant_id,
                    slug,
                    name,
                    json.dumps(allowed_networks),
                    json.dumps(allowed_hosts),
                    created_at,
                ),
            )
            self._insert_security_event(
                connection,
                DEFAULT_TENANT_ID,
                actor_id,
                actor_name,
                "tenant.created",
                tenant_id,
                {"slug": slug, "name": name},
            )
            connection.commit()
        tenant = self.get_tenant(tenant_id)
        if tenant is None:
            raise RuntimeError("Created tenant could not be read")
        return tenant

    def get_tenant(self, tenant_id: str) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute("SELECT * FROM tenants WHERE id=?", (tenant_id,)).fetchone()
            return self._tenant_row(row) if row else None

    def list_tenants(self) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = connection.execute("SELECT * FROM tenants ORDER BY created_at,id").fetchall()
            return [self._tenant_row(row) for row in rows]

    @staticmethod
    def _tenant_row(row: sqlite3.Row) -> dict[str, Any]:
        value = dict(row)
        value["allowed_networks"] = json.loads(value["allowed_networks"])
        value["allowed_hosts"] = json.loads(value["allowed_hosts"])
        value["enabled"] = bool(value["enabled"])
        return value

    def recover_interrupted_scans(self) -> int:
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                """UPDATE scans SET status='failed', completed_at=?,
                   error='Application restarted before the scan completed'
                   WHERE status IN ('queued','running')""",
                (iso(),),
            )
            return cursor.rowcount

    def recover_interrupted_discoveries(self) -> int:
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                """UPDATE discoveries SET status='failed', completed_at=?,
                   error='Application restarted before the discovery completed'
                   WHERE status IN ('queued','running')""",
                (iso(),),
            )
            return cursor.rowcount

    def create_scan(
        self,
        target: str,
        resolved_targets: tuple[str, ...],
        ports: tuple[int, ...],
        service_detection: bool,
        monitor_id: str | None = None,
        port_profile: str = "custom",
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, Any]:
        scan_id = str(uuid.uuid4())
        created_at = iso()
        with closing(self.connect()) as connection:
            connection.execute(
                """INSERT INTO scans
                   (id, tenant_id, monitor_id, target, resolved_targets, ports, port_profile,
                    service_detection, status, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'queued', ?)""",
                (
                    scan_id,
                    tenant_id,
                    monitor_id,
                    target,
                    json.dumps(resolved_targets),
                    json.dumps(ports),
                    port_profile,
                    int(service_detection),
                    created_at,
                ),
            )
        return self.get_scan(scan_id, tenant_id)

    def mark_scan_running(self, scan_id: str) -> None:
        with closing(self.connect()) as connection:
            connection.execute(
                "UPDATE scans SET status='running', started_at=? WHERE id=? AND status='queued'",
                (iso(), scan_id),
            )

    def complete_scan(self, scan_id: str, hosts: tuple[dict, ...], findings: tuple[dict, ...]) -> None:
        observed_at = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT target,tenant_id,cancelled_at FROM scans WHERE id=?", (scan_id,)
            ).fetchone()
            if row is None:
                connection.rollback()
                raise KeyError(scan_id)
            if row["cancelled_at"]:
                connection.rollback()
                return
            previous = connection.execute(
                """SELECT id FROM scans
                   WHERE tenant_id=? AND target=? AND id<>? AND status='completed'
                   ORDER BY completed_at DESC,created_at DESC,id DESC LIMIT 1""",
                (row["tenant_id"], row["target"], scan_id),
            ).fetchone()
            previous_id = previous["id"] if previous else None
            previous_hosts = {
                item["ip"]
                for item in connection.execute(
                    "SELECT ip FROM scan_hosts WHERE scan_id=?", (previous_id,)
                )
            } if previous_id else set()
            previous_findings = {
                (item["ip"], item["port"], item["protocol"]): dict(item)
                for item in connection.execute(
                    """SELECT ip,port,protocol,service,product,version
                       FROM findings WHERE scan_id=?""",
                    (previous_id,),
                )
            } if previous_id else {}
            current_findings = {
                (item["ip"], item["port"], item["protocol"]): item for item in findings
            }
            for host in hosts:
                connection.execute(
                    """INSERT INTO scan_hosts (scan_id, target, ip, hostname, state, observed_at)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (scan_id, row["target"], host["ip"], host["hostname"], host["state"], observed_at),
                )
                if previous_id and host["ip"] not in previous_hosts:
                    self._insert_alert(
                        connection, row["tenant_id"], "new_asset", "medium", "Novo ativo observado",
                        row["target"], host["ip"], None, None, scan_id, observed_at,
                    )
            for finding in findings:
                connection.execute(
                    """INSERT INTO findings
                       (scan_id, target, ip, hostname, port, protocol, state, service, product, version, observed_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        scan_id,
                        row["target"],
                        finding["ip"],
                        finding["hostname"],
                        finding["port"],
                        finding["protocol"],
                        finding["state"],
                        finding["service"],
                        finding["product"],
                        finding["version"],
                        observed_at,
                    ),
                )
                identity = (finding["ip"], finding["port"], finding["protocol"])
                if previous_id and identity not in previous_findings:
                    self._insert_alert(
                        connection, row["tenant_id"], "new_open_port", "medium", "Nova porta aberta",
                        row["target"], finding["ip"], finding["port"], finding["protocol"], scan_id, observed_at,
                    )
                previous_finding = previous_findings.get(identity)
                if previous_finding and any(
                    (previous_finding[field] or "") != (finding.get(field) or "")
                    for field in ("service", "product", "version")
                ):
                    self._insert_alert(
                        connection, row["tenant_id"], "service_changed", "medium", "Serviço alterado",
                        row["target"], finding["ip"], finding["port"], finding["protocol"], scan_id, observed_at,
                    )
            for identity in previous_findings.keys() - current_findings.keys():
                ip, port, protocol = identity
                self._insert_alert(
                    connection, row["tenant_id"], "closed_port", "info", "Porta não observada novamente",
                    row["target"], ip, port, protocol, scan_id, observed_at,
                )
            connection.execute(
                "UPDATE scans SET status='completed', completed_at=?, error=NULL WHERE id=?",
                (observed_at, scan_id),
            )
            connection.commit()

    @staticmethod
    def _insert_alert(
        connection: sqlite3.Connection,
        tenant_id: str,
        kind: str,
        severity: str,
        title: str,
        target: str,
        ip: str,
        port: int | None,
        protocol: str | None,
        scan_id: str | None,
        created_at: str,
        source_type: str = "scan",
        source_id: str | None = None,
    ) -> None:
        connection.execute(
            """INSERT INTO alerts
               (id,tenant_id,kind,severity,title,target,ip,port,protocol,
                source_type,source_id,scan_id,created_at)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                str(uuid.uuid4()), tenant_id, kind, severity, title, target, ip, port, protocol,
                source_type, source_id or scan_id, scan_id, created_at,
            ),
        )

    def cancel_scan(self, scan_id: str, tenant_id: str = DEFAULT_TENANT_ID) -> dict[str, Any] | None:
        cancelled_at = iso()
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                """UPDATE scans SET status='failed',completed_at=?,cancelled_at=?,error='Cancelled by user'
                   WHERE id=? AND tenant_id=? AND status IN ('queued','running') AND cancelled_at IS NULL""",
                (cancelled_at, cancelled_at, scan_id, tenant_id),
            )
            if cursor.rowcount == 0:
                return None
        return self.get_scan(scan_id, tenant_id)

    def fail_scan(self, scan_id: str, message: str) -> None:
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                """UPDATE scans SET status='failed', completed_at=?, error=?
                   WHERE id=? AND cancelled_at IS NULL""",
                (iso(), message[:500], scan_id),
            )
            if cursor.rowcount == 0:
                return
            monitor = connection.execute("SELECT monitor_id FROM scans WHERE id=?", (scan_id,)).fetchone()
            if monitor and monitor["monitor_id"]:
                connection.execute(
                    "UPDATE monitors SET last_error=? WHERE id=?",
                    (message[:500], monitor["monitor_id"]),
                )

    def get_scan(self, scan_id: str, tenant_id: str = DEFAULT_TENANT_ID) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute(
                "SELECT * FROM scans WHERE id=? AND tenant_id=?", (scan_id, tenant_id)
            ).fetchone()
            if row is None:
                return None
            result = self._scan_row(row)
            result["hosts"] = [dict(item) for item in connection.execute(
                "SELECT ip,hostname,state,observed_at FROM scan_hosts WHERE scan_id=? ORDER BY ip", (scan_id,)
            )]
            result["findings"] = [dict(item) for item in connection.execute(
                """SELECT ip,hostname,port,protocol,state,service,product,version,observed_at
                   FROM findings WHERE scan_id=? ORDER BY ip,port""", (scan_id,)
            )]
            return result

    def list_scans(self, limit: int = 50, tenant_id: str = DEFAULT_TENANT_ID) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = connection.execute(
                "SELECT * FROM scans WHERE tenant_id=? ORDER BY created_at DESC LIMIT ?",
                (tenant_id, limit),
            ).fetchall()
            return [self._scan_row(row) for row in rows]

    @staticmethod
    def _scan_row(row: sqlite3.Row) -> dict[str, Any]:
        value = dict(row)
        value["resolved_targets"] = json.loads(value["resolved_targets"])
        value["ports"] = json.loads(value["ports"])
        value["port_count"] = Database._port_count(value["port_profile"], value["ports"])
        value["service_detection"] = bool(value["service_detection"])
        if value.get("cancelled_at"):
            value["status"] = "cancelled"
        return value

    @staticmethod
    def _port_count(port_profile: str, ports: list[int]) -> int:
        return {"top-1000": 1000, "all-tcp": 65535}.get(port_profile, len(ports))

    def list_assets(self, limit: int = 500, tenant_id: str = DEFAULT_TENANT_ID) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = connection.execute(
                """
                SELECT target, ip, hostname, port, protocol, state,
                       service, product, version, observed_at
                FROM (
                    SELECT f.*,
                           ROW_NUMBER() OVER (
                               PARTITION BY ip, port, protocol
                               ORDER BY f.observed_at DESC, f.id DESC
                           ) AS recency
                    FROM findings f JOIN scans s ON s.id=f.scan_id
                    WHERE s.tenant_id=?
                ) ranked
                WHERE recency=1
                ORDER BY observed_at DESC, ip, port LIMIT ?
                """,
                (tenant_id, limit),
            ).fetchall()
            assets = [dict(row) for row in rows]
            metadata = {
                row["ip"]: self._asset_metadata_row(row)
                for row in connection.execute(
                    "SELECT * FROM asset_metadata WHERE tenant_id=?", (tenant_id,)
                )
            }
        risk = self._risk_by_ip(assets, metadata)
        for asset in assets:
            context = metadata.get(asset["ip"], self._default_asset_metadata(asset["ip"]))
            asset.update(context)
            asset.update(risk[asset["ip"]])
        return assets

    def list_inventory(self, limit: int = 500, tenant_id: str = DEFAULT_TENANT_ID) -> list[dict[str, Any]]:
        assets = self.list_assets(2_000, tenant_id)
        grouped: dict[str, dict[str, Any]] = {}
        for asset in assets:
            entry = grouped.setdefault(
                asset["ip"],
                {
                    "ip": asset["ip"],
                    "hostname": asset["hostname"],
                    "target": asset["target"],
                    "open_ports": [],
                    "services": [],
                    "last_observed_at": asset["observed_at"],
                    **{key: asset[key] for key in (
                        "display_name", "owner", "environment", "criticality", "tags", "notes",
                        "updated_at", "updated_by", "risk_score", "risk_level",
                    )},
                },
            )
            entry["open_ports"].append(asset["port"])
            service = " ".join(
                str(asset.get(key) or "") for key in ("service", "product", "version")
            ).strip()
            if service:
                entry["services"].append(service)
            if asset["observed_at"] > entry["last_observed_at"]:
                entry["last_observed_at"] = asset["observed_at"]
                entry["hostname"] = asset["hostname"]
                entry["target"] = asset["target"]
        result = list(grouped.values())
        for item in result:
            item["open_ports"] = sorted(set(item["open_ports"]))
            item["services"] = sorted(set(item["services"]))
        result.sort(key=lambda item: (-item["risk_score"], item["ip"]))
        return result[:limit]

    def upsert_asset_metadata(
        self,
        *,
        ip: str,
        display_name: str,
        owner: str,
        environment: str,
        criticality: str,
        tags: tuple[str, ...],
        notes: str,
        tenant_id: str,
        actor_id: str,
        actor_name: str,
    ) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            exists = connection.execute(
                """SELECT 1 FROM findings f JOIN scans s ON s.id=f.scan_id
                   WHERE s.tenant_id=? AND f.ip=? LIMIT 1""",
                (tenant_id, ip),
            ).fetchone()
            if exists is None:
                return None
            updated_at = iso()
            connection.execute("BEGIN IMMEDIATE")
            connection.execute(
                """INSERT INTO asset_metadata
                   (tenant_id,ip,display_name,owner,environment,criticality,tags,notes,updated_at,updated_by)
                   VALUES (?,?,?,?,?,?,?,?,?,?)
                   ON CONFLICT(tenant_id,ip) DO UPDATE SET
                       display_name=excluded.display_name,owner=excluded.owner,
                       environment=excluded.environment,criticality=excluded.criticality,
                       tags=excluded.tags,notes=excluded.notes,updated_at=excluded.updated_at,
                       updated_by=excluded.updated_by""",
                (
                    tenant_id, ip, display_name, owner, environment, criticality,
                    json.dumps(sorted(set(tags))), notes, updated_at, actor_name,
                ),
            )
            self._insert_security_event(
                connection,
                tenant_id,
                actor_id,
                actor_name,
                "asset.context_updated",
                ip,
                {"criticality": criticality, "environment": environment, "tags": sorted(set(tags))},
            )
            connection.commit()
        return next((item for item in self.list_inventory(2_000, tenant_id) if item["ip"] == ip), None)

    @staticmethod
    def _asset_metadata_row(row: sqlite3.Row) -> dict[str, Any]:
        value = dict(row)
        value["tags"] = json.loads(value["tags"])
        value.pop("tenant_id", None)
        value.pop("ip", None)
        return value

    @staticmethod
    def _default_asset_metadata(_ip: str) -> dict[str, Any]:
        return {
            "display_name": "",
            "owner": "",
            "environment": "unknown",
            "criticality": "medium",
            "tags": [],
            "notes": "",
            "updated_at": None,
            "updated_by": "",
        }

    @staticmethod
    def _risk_by_ip(
        assets: list[dict[str, Any]],
        metadata: dict[str, dict[str, Any]],
    ) -> dict[str, dict[str, Any]]:
        ports: dict[str, set[int]] = {}
        for asset in assets:
            ports.setdefault(asset["ip"], set()).add(asset["port"])
        criticality_weight = {"low": 5, "medium": 15, "high": 30, "critical": 45}
        port_weight = {23: 35, 445: 25, 3389: 30, 6379: 30, 1433: 20, 3306: 15, 5432: 15, 22: 10}
        result = {}
        for ip, observed_ports in ports.items():
            context = metadata.get(ip, Database._default_asset_metadata(ip))
            score = criticality_weight[context["criticality"]]
            score += max((port_weight.get(port, 0) for port in observed_ports), default=0)
            score += min(max(len(observed_ports) - 1, 0) * 3, 15)
            score = min(score, 100)
            level = "critical" if score >= 70 else "high" if score >= 45 else "medium" if score >= 25 else "low"
            result[ip] = {"risk_score": score, "risk_level": level}
        return result

    def overview(self, tenant_id: str = DEFAULT_TENANT_ID) -> dict[str, int]:
        with closing(self.connect()) as connection:
            scans = connection.execute("SELECT COUNT(*) FROM scans WHERE tenant_id=?", (tenant_id,)).fetchone()[0]
            active = connection.execute(
                "SELECT COUNT(*) FROM scans WHERE tenant_id=? AND status IN ('queued','running')", (tenant_id,)
            ).fetchone()[0]
            failed = connection.execute(
                "SELECT COUNT(*) FROM scans WHERE tenant_id=? AND status='failed'", (tenant_id,)
            ).fetchone()[0]
            assets = connection.execute(
                """SELECT COUNT(DISTINCT f.ip) FROM findings f
                   JOIN scans s ON s.id=f.scan_id WHERE s.tenant_id=?""", (tenant_id,)
            ).fetchone()[0]
            ports = connection.execute(
                """SELECT COUNT(DISTINCT f.ip || ':' || f.port) FROM findings f
                   JOIN scans s ON s.id=f.scan_id WHERE s.tenant_id=?""", (tenant_id,)
            ).fetchone()[0]
            monitors = connection.execute(
                "SELECT COUNT(*) FROM monitors WHERE tenant_id=? AND enabled=1", (tenant_id,)
            ).fetchone()[0]
            discoveries = connection.execute(
                "SELECT COUNT(*) FROM discoveries WHERE tenant_id=?", (tenant_id,)
            ).fetchone()[0]
            discovered_hosts = connection.execute(
                """SELECT COUNT(DISTINCT h.hostname) FROM discovered_hosts h
                   JOIN discoveries d ON d.id=h.discovery_id WHERE d.tenant_id=?""", (tenant_id,)
            ).fetchone()[0]
            alerts = connection.execute(
                "SELECT COUNT(*) FROM alerts WHERE tenant_id=? AND acknowledged_at IS NULL", (tenant_id,)
            ).fetchone()[0]
            web_endpoints = connection.execute(
                """SELECT COUNT(DISTINCT target || ':' || ip || ':' || scheme || ':' || port)
                   FROM web_observations WHERE tenant_id=?""", (tenant_id,)
            ).fetchone()[0]
        return {
            "scans": scans,
            "active_scans": active,
            "failed_scans": failed,
            "assets": assets,
            "open_ports": ports,
            "monitors": monitors,
            "discoveries": discoveries,
            "discovered_hosts": discovered_hosts,
            "unacknowledged_alerts": alerts,
            "web_endpoints": web_endpoints,
        }

    def create_discovery(
        self,
        domain: str,
        engine: str = "gobuster",
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, Any]:
        discovery_id = str(uuid.uuid4())
        with closing(self.connect()) as connection:
            connection.execute(
                """INSERT INTO discoveries (id,tenant_id,domain,engine,status,created_at)
                   VALUES (?,?,?,?,'queued',?)""",
                (discovery_id, tenant_id, domain, engine, iso()),
            )
        result = self.get_discovery(discovery_id, tenant_id)
        if result is None:
            raise RuntimeError("Created discovery could not be read")
        return result

    def mark_discovery_running(self, discovery_id: str) -> None:
        with closing(self.connect()) as connection:
            connection.execute(
                "UPDATE discoveries SET status='running', started_at=? WHERE id=? AND status='queued'",
                (iso(), discovery_id),
            )

    def complete_discovery(self, discovery_id: str, hostnames: tuple[str, ...]) -> None:
        observed_at = iso()
        unique_hostnames = tuple(sorted(set(hostnames)))
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT domain,tenant_id,engine,cancelled_at FROM discoveries WHERE id=?",
                (discovery_id,),
            ).fetchone()
            if row is None:
                connection.rollback()
                raise KeyError(discovery_id)
            if row["cancelled_at"]:
                connection.rollback()
                return
            previous = connection.execute(
                """SELECT id FROM discoveries
                   WHERE tenant_id=? AND domain=? AND engine=? AND id<>? AND status='completed'
                   ORDER BY completed_at DESC,created_at DESC,id DESC LIMIT 1""",
                (row["tenant_id"], row["domain"], row["engine"], discovery_id),
            ).fetchone()
            previous_names = {
                item["hostname"]
                for item in connection.execute(
                    "SELECT hostname FROM discovered_hosts WHERE discovery_id=?", (previous["id"],)
                )
            } if previous else set()
            for hostname in unique_hostnames:
                connection.execute(
                    """INSERT INTO discovered_hosts (discovery_id,domain,hostname,observed_at)
                       VALUES (?,?,?,?)""",
                    (discovery_id, row["domain"], hostname, observed_at),
                )
                if previous and hostname not in previous_names:
                    self._insert_alert(
                        connection,
                        row["tenant_id"],
                        "new_subdomain",
                        "low",
                        "Novo subdomínio observado",
                        row["domain"],
                        hostname,
                        None,
                        None,
                        None,
                        observed_at,
                        "discovery",
                        discovery_id,
                    )
            connection.execute(
                """UPDATE discoveries SET status='completed',completed_at=?,found_count=?,error=NULL
                   WHERE id=?""",
                (observed_at, len(unique_hostnames), discovery_id),
            )
            connection.commit()

    def fail_discovery(self, discovery_id: str, message: str) -> None:
        with closing(self.connect()) as connection:
            connection.execute(
                """UPDATE discoveries SET status='failed',completed_at=?,error=?
                   WHERE id=? AND cancelled_at IS NULL""",
                (iso(), message[:500], discovery_id),
            )

    def cancel_discovery(
        self,
        discovery_id: str,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, Any] | None:
        cancelled_at = iso()
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                """UPDATE discoveries
                   SET status='failed',completed_at=?,cancelled_at=?,error='Cancelled by user'
                   WHERE id=? AND tenant_id=? AND status IN ('queued','running') AND cancelled_at IS NULL""",
                (cancelled_at, cancelled_at, discovery_id, tenant_id),
            )
            if cursor.rowcount == 0:
                return None
        return self.get_discovery(discovery_id, tenant_id)

    def get_discovery(
        self,
        discovery_id: str,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute(
                "SELECT * FROM discoveries WHERE id=? AND tenant_id=?", (discovery_id, tenant_id)
            ).fetchone()
            if row is None:
                return None
            result = dict(row)
            if result.get("cancelled_at"):
                result["status"] = "cancelled"
            result["hostnames"] = [
                item["hostname"]
                for item in connection.execute(
                    "SELECT hostname FROM discovered_hosts WHERE discovery_id=? ORDER BY hostname",
                    (discovery_id,),
                )
            ]
            return result

    def list_discoveries(
        self,
        limit: int = 50,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = [
                dict(row) for row in connection.execute(
                    """SELECT * FROM discoveries WHERE tenant_id=?
                       ORDER BY created_at DESC,id DESC LIMIT ?""",
                    (tenant_id, limit),
                )
            ]
            for row in rows:
                if row.get("cancelled_at"):
                    row["status"] = "cancelled"
            return rows

    def list_discovered_hosts(
        self,
        limit: int = 500,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = connection.execute(
                """SELECT domain,hostname,observed_at FROM (
                       SELECT h.*,ROW_NUMBER() OVER (
                           PARTITION BY h.hostname ORDER BY h.observed_at DESC,h.id DESC
                       ) AS recency
                       FROM discovered_hosts h
                       JOIN discoveries d ON d.id=h.discovery_id
                       WHERE d.tenant_id=?
                   ) ranked WHERE recency=1 ORDER BY hostname LIMIT ?""",
                (tenant_id, limit),
            ).fetchall()
            return [dict(row) for row in rows]

    def record_web_observations(
        self,
        target: str,
        observations: tuple[dict[str, Any], ...],
        tenant_id: str = DEFAULT_TENANT_ID,
        tls_warning_days: int = 30,
    ) -> None:
        observed_at = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            for item in observations:
                previous = connection.execute(
                    """SELECT status_code,title,server,tls_subject,tls_days_remaining,error
                       FROM web_observations
                       WHERE tenant_id=? AND target=? AND ip=? AND scheme=? AND port=?
                       ORDER BY observed_at DESC,id DESC LIMIT 1""",
                    (tenant_id, target, item["ip"], item["scheme"], item["port"]),
                ).fetchone()
                connection.execute(
                    """INSERT INTO web_observations
                       (tenant_id,target,ip,scheme,port,status_code,title,server,content_type,location,
                        tls_subject,tls_issuer,tls_not_after,tls_days_remaining,error,observed_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (
                        tenant_id,
                        target,
                        item["ip"],
                        item["scheme"],
                        item["port"],
                        item.get("status_code"),
                        item.get("title", "")[:200],
                        item.get("server", "")[:200],
                        item.get("content_type", "")[:200],
                        item.get("location", "")[:500],
                        item.get("tls_subject", "")[:253],
                        item.get("tls_issuer", "")[:253],
                        item.get("tls_not_after"),
                        item.get("tls_days_remaining"),
                        item.get("error", "")[:500],
                        observed_at,
                    ),
                )
                days = item.get("tls_days_remaining")
                previous_days = previous["tls_days_remaining"] if previous else None
                if (
                    item["scheme"] == "https"
                    and days is not None
                    and days <= tls_warning_days
                    and (previous_days is None or previous_days > tls_warning_days)
                ):
                    self._insert_alert(
                        connection,
                        tenant_id,
                        "tls_expiring",
                        "high" if days < 7 else "medium",
                        f"Certificado TLS vence em {days} dia(s)",
                        target,
                        item["ip"],
                        item["port"],
                        "tcp",
                        None,
                        observed_at,
                        "web",
                        f"{target}:{item['ip']}:{item['port']}",
                    )
                if previous and any(
                    (previous[field] or "") != (item.get(field) or "")
                    for field in ("status_code", "server", "tls_subject", "error")
                ):
                    self._insert_alert(
                        connection,
                        tenant_id,
                        "web_changed",
                        "low",
                        "Serviço web alterado",
                        target,
                        item["ip"],
                        item["port"],
                        "tcp",
                        None,
                        observed_at,
                        "web",
                        f"{target}:{item['ip']}:{item['port']}",
                    )
            connection.commit()

    def list_web_observations(
        self,
        limit: int = 500,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = connection.execute(
                """SELECT id,target,ip,scheme,port,status_code,title,server,content_type,location,
                          tls_subject,tls_issuer,tls_not_after,tls_days_remaining,error,observed_at
                   FROM (
                       SELECT w.*,ROW_NUMBER() OVER (
                           PARTITION BY target,ip,scheme,port ORDER BY observed_at DESC,id DESC
                       ) AS recency
                       FROM web_observations w
                       WHERE tenant_id=?
                   ) ranked WHERE recency=1 ORDER BY observed_at DESC,id DESC LIMIT ?""",
                (tenant_id, limit),
            ).fetchall()
            return [dict(row) for row in rows]

    def list_alerts(
        self,
        limit: int = 100,
        unacknowledged_only: bool = False,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> list[dict[str, Any]]:
        where = "AND acknowledged_at IS NULL" if unacknowledged_only else ""
        with closing(self.connect()) as connection:
            rows = connection.execute(
                f"SELECT * FROM alerts WHERE tenant_id=? {where} "  # noqa: S608
                "ORDER BY created_at DESC,id DESC LIMIT ?",
                (tenant_id, limit),
            ).fetchall()
            return [dict(row) for row in rows]

    def get_alert(self, alert_id: str, tenant_id: str = DEFAULT_TENANT_ID) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute(
                "SELECT * FROM alerts WHERE id=? AND tenant_id=?", (alert_id, tenant_id)
            ).fetchone()
            return dict(row) if row else None

    def acknowledge_alert(self, alert_id: str, tenant_id: str = DEFAULT_TENANT_ID) -> bool:
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                """UPDATE alerts SET acknowledged_at=COALESCE(acknowledged_at,?)
                   WHERE id=? AND tenant_id=?""",
                (iso(), alert_id, tenant_id),
            )
            return cursor.rowcount > 0

    def create_monitor(
        self,
        name: str,
        target: str,
        ports: tuple[int, ...],
        service_detection: bool,
        interval_minutes: int,
        port_profile: str = "custom",
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, Any]:
        monitor_id = str(uuid.uuid4())
        now = iso()
        with closing(self.connect()) as connection:
            connection.execute(
                """INSERT INTO monitors
                   (id,tenant_id,name,target,ports,port_profile,service_detection,interval_minutes,
                    enabled,created_at,next_run_at)
                   VALUES (?,?,?,?,?,?,?,?,1,?,?)""",
                (
                    monitor_id,
                    tenant_id,
                    name,
                    target,
                    json.dumps(ports),
                    port_profile,
                    int(service_detection),
                    interval_minutes,
                    now,
                    now,
                ),
            )
        return self.get_monitor(monitor_id, tenant_id)

    def get_monitor(self, monitor_id: str, tenant_id: str = DEFAULT_TENANT_ID) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute(
                "SELECT * FROM monitors WHERE id=? AND tenant_id=?", (monitor_id, tenant_id)
            ).fetchone()
            return self._monitor_row(row) if row else None

    def list_monitors(self, tenant_id: str = DEFAULT_TENANT_ID) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = connection.execute(
                "SELECT * FROM monitors WHERE tenant_id=? ORDER BY created_at DESC", (tenant_id,)
            ).fetchall()
            return [self._monitor_row(row) for row in rows]

    @staticmethod
    def _monitor_row(row: sqlite3.Row) -> dict[str, Any]:
        value = dict(row)
        value["ports"] = json.loads(value["ports"])
        value["port_count"] = Database._port_count(value["port_profile"], value["ports"])
        value["service_detection"] = bool(value["service_detection"])
        value["enabled"] = bool(value["enabled"])
        return value

    def due_monitors(self, now: str) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            rows = connection.execute(
                "SELECT * FROM monitors WHERE enabled=1 AND next_run_at<=? ORDER BY next_run_at LIMIT 20", (now,)
            ).fetchall()
            return [self._monitor_row(row) for row in rows]

    def mark_monitor_scheduled(self, monitor_id: str, interval_minutes: int) -> None:
        current = utc_now()
        next_run = current + timedelta(minutes=interval_minutes)
        with closing(self.connect()) as connection:
            connection.execute(
                "UPDATE monitors SET last_run_at=?, next_run_at=?, last_error=NULL WHERE id=?",
                (iso(current), iso(next_run), monitor_id),
            )

    def set_monitor_error(self, monitor_id: str, message: str) -> None:
        with closing(self.connect()) as connection:
            connection.execute("UPDATE monitors SET last_error=? WHERE id=?", (message[:500], monitor_id))

    def delete_monitor(self, monitor_id: str, tenant_id: str = DEFAULT_TENANT_ID) -> bool:
        with closing(self.connect()) as connection:
            cursor = connection.execute(
                "DELETE FROM monitors WHERE id=? AND tenant_id=?", (monitor_id, tenant_id)
            )
            return cursor.rowcount > 0

    def create_api_key(
        self,
        *,
        key_id: str,
        name: str,
        prefix: str,
        key_hash: str,
        role: str,
        expires_at: str | None,
        actor_id: str,
        actor_name: str,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, Any]:
        created_at = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                connection.execute(
                    """INSERT INTO api_keys
                       (id,tenant_id,name,prefix,key_hash,role,created_at,created_by,expires_at)
                       VALUES (?,?,?,?,?,?,?,?,?)""",
                    (key_id, tenant_id, name, prefix, key_hash, role, created_at, actor_name, expires_at),
                )
                self._insert_security_event(
                    connection,
                    tenant_id,
                    actor_id,
                    actor_name,
                    "api_key.created",
                    key_id,
                    {"name": name, "role": role, "prefix": prefix},
                )
                connection.commit()
            except Exception:
                connection.rollback()
                raise
        result = self.get_api_key(key_id, tenant_id)
        if result is None:
            raise RuntimeError("Created API key could not be read")
        return self._public_api_key(result)

    def get_api_key_by_prefix(self, prefix: str) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            row = connection.execute("SELECT * FROM api_keys WHERE prefix=?", (prefix,)).fetchone()
            return dict(row) if row else None

    def get_api_key(self, key_id: str, tenant_id: str | None = DEFAULT_TENANT_ID) -> dict[str, Any] | None:
        with closing(self.connect()) as connection:
            if tenant_id is None:
                row = connection.execute("SELECT * FROM api_keys WHERE id=?", (key_id,)).fetchone()
            else:
                row = connection.execute(
                    "SELECT * FROM api_keys WHERE id=? AND tenant_id=?", (key_id, tenant_id)
                ).fetchone()
            return dict(row) if row else None

    def list_api_keys(self, tenant_id: str | None = DEFAULT_TENANT_ID) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            if tenant_id is None:
                rows = connection.execute("SELECT * FROM api_keys ORDER BY created_at DESC").fetchall()
            else:
                rows = connection.execute(
                    "SELECT * FROM api_keys WHERE tenant_id=? ORDER BY created_at DESC", (tenant_id,)
                ).fetchall()
            return [self._public_api_key(dict(row)) for row in rows]

    @staticmethod
    def _public_api_key(value: dict[str, Any]) -> dict[str, Any]:
        result = {key: item for key, item in value.items() if key != "key_hash"}
        if result["revoked_at"]:
            result["status"] = "revoked"
        elif result["expires_at"] and datetime.fromisoformat(result["expires_at"]) <= utc_now():
            result["status"] = "expired"
        else:
            result["status"] = "active"
        result["kind"] = "managed"
        return result

    def touch_api_key(self, key_id: str) -> None:
        threshold = iso(utc_now() - timedelta(minutes=1))
        with closing(self.connect()) as connection:
            connection.execute(
                """UPDATE api_keys SET last_used_at=?
                   WHERE id=? AND (last_used_at IS NULL OR last_used_at<?)""",
                (iso(), key_id, threshold),
            )

    def revoke_api_key(
        self,
        key_id: str,
        actor_id: str,
        actor_name: str,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> bool:
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                """SELECT name,prefix,revoked_at FROM api_keys
                   WHERE id=? AND tenant_id=?""",
                (key_id, tenant_id),
            ).fetchone()
            if row is None or row["revoked_at"]:
                connection.rollback()
                return False
            connection.execute("UPDATE api_keys SET revoked_at=? WHERE id=?", (iso(), key_id))
            self._insert_security_event(
                connection,
                tenant_id,
                actor_id,
                actor_name,
                "api_key.revoked",
                key_id,
                {"name": row["name"], "prefix": row["prefix"]},
            )
            connection.commit()
            return True

    def rotate_api_key(
        self,
        *,
        old_key_id: str,
        new_key_id: str,
        prefix: str,
        key_hash: str,
        expires_at: str | None,
        actor_id: str,
        actor_name: str,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, Any] | None:
        now = iso()
        with closing(self.connect()) as connection:
            connection.execute("BEGIN IMMEDIATE")
            old = connection.execute(
                "SELECT * FROM api_keys WHERE id=? AND tenant_id=?", (old_key_id, tenant_id)
            ).fetchone()
            if old is None or old["revoked_at"]:
                connection.rollback()
                return None
            connection.execute("UPDATE api_keys SET revoked_at=? WHERE id=?", (now, old_key_id))
            connection.execute(
                """INSERT INTO api_keys
                   (id,tenant_id,name,prefix,key_hash,role,created_at,created_by,expires_at)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (
                    new_key_id,
                    tenant_id,
                    old["name"],
                    prefix,
                    key_hash,
                    old["role"],
                    now,
                    actor_name,
                    expires_at,
                ),
            )
            self._insert_security_event(
                connection,
                tenant_id,
                actor_id,
                actor_name,
                "api_key.rotated",
                new_key_id,
                {"previous_id": old_key_id, "name": old["name"], "prefix": prefix},
            )
            connection.commit()
        result = self.get_api_key(new_key_id, tenant_id)
        return self._public_api_key(result) if result else None

    def list_security_events(
        self,
        limit: int = 100,
        tenant_id: str | None = DEFAULT_TENANT_ID,
    ) -> list[dict[str, Any]]:
        with closing(self.connect()) as connection:
            if tenant_id is None:
                rows = connection.execute(
                    """SELECT id,tenant_id,actor_id,actor_name,action,target_id,created_at,details
                       FROM security_events ORDER BY id DESC LIMIT ?""",
                    (limit,),
                ).fetchall()
            else:
                rows = connection.execute(
                    """SELECT id,tenant_id,actor_id,actor_name,action,target_id,created_at,details
                       FROM security_events WHERE tenant_id=? ORDER BY id DESC LIMIT ?""",
                    (tenant_id, limit),
                ).fetchall()
            result = []
            for row in rows:
                item = dict(row)
                item["details"] = json.loads(item["details"])
                result.append(item)
            return result

    def prune_history(
        self,
        *,
        older_than_days: int,
        dry_run: bool,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict[str, int | bool | str]:
        threshold = iso(utc_now() - timedelta(days=older_than_days))
        queries = {
            "scans": (
                "tenant_id=? AND status IN ('completed','failed') AND COALESCE(completed_at,created_at)<?",
                (tenant_id, threshold),
            ),
            "discoveries": (
                "tenant_id=? AND status IN ('completed','failed') AND COALESCE(completed_at,created_at)<?",
                (tenant_id, threshold),
            ),
            "web_observations": ("tenant_id=? AND observed_at<?", (tenant_id, threshold)),
            "alerts": (
                "tenant_id=? AND acknowledged_at IS NOT NULL AND created_at<?",
                (tenant_id, threshold),
            ),
            "security_events": ("tenant_id=? AND created_at<?", (tenant_id, threshold)),
        }
        with closing(self.connect()) as connection:
            counts = {
                table: connection.execute(
                    f"SELECT COUNT(*) FROM {table} WHERE {where}",  # noqa: S608 - fixed table map
                    parameters,
                ).fetchone()[0]
                for table, (where, parameters) in queries.items()
            }
            if not dry_run:
                connection.execute("BEGIN IMMEDIATE")
                try:
                    for table, (where, parameters) in queries.items():
                        connection.execute(
                            f"DELETE FROM {table} WHERE {where}",  # noqa: S608 - fixed table map
                            parameters,
                        )
                    connection.commit()
                except Exception:
                    connection.rollback()
                    raise
        return {"dry_run": dry_run, "threshold": threshold, **counts}

    def record_security_event(
        self,
        *,
        tenant_id: str,
        actor_id: str,
        actor_name: str,
        action: str,
        target_id: str | None,
        details: dict[str, Any],
    ) -> None:
        with closing(self.connect()) as connection:
            self._insert_security_event(
                connection,
                tenant_id,
                actor_id,
                actor_name,
                action,
                target_id,
                details,
            )

    @staticmethod
    def _insert_security_event(
        connection: sqlite3.Connection,
        tenant_id: str,
        actor_id: str,
        actor_name: str,
        action: str,
        target_id: str | None,
        details: dict[str, Any],
    ) -> None:
        connection.execute(
            """INSERT INTO security_events
               (tenant_id,actor_id,actor_name,action,target_id,created_at,details)
               VALUES (?,?,?,?,?,?,?)""",
            (tenant_id, actor_id, actor_name, action, target_id, iso(), json.dumps(details, sort_keys=True)),
        )
