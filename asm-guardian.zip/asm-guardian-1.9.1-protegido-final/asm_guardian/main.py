from __future__ import annotations

import asyncio
import ipaddress
import logging
import sqlite3
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response as FastAPIResponse, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse, Response
from fastapi.staticfiles import StaticFiles

from .auth import ApiKeyManager, Principal, UserManager
from .config import Settings
from .database import Database, iso
from .discovery import BUNDLED_WORDLIST, GobusterRunner, SubfinderRunner
from .scanner import NmapRunner
from .reporting import assets_csv, printable_report
from .schemas import (
    ApiKeyCreateRequest,
    ApiKeyRotateRequest,
    AssetMetadataRequest,
    DiscoveryRequest,
    LoginRequest,
    MonitorRequest,
    PasswordChangeRequest,
    PasswordResetRequest,
    RetentionRequest,
    ScanRequest,
    TenantCreateRequest,
    UserCreateRequest,
    WebProbeRequest,
)
from .security import ScopeError, ScopePolicy, SlidingWindowLimiter
from .service import DiscoveryCapacityError, DiscoveryService, ScanCapacityError, ScanService
from .webprobe import WebProbeRunner


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")
PACKAGE_DIR = Path(__file__).resolve().parent
SESSION_COOKIE_NAME = "asm_guardian_session"
CSRF_COOKIE_NAME = "asm_guardian_csrf"
SAFE_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})
PUBLIC_ASSET_SUFFIXES = frozenset({".css", ".js", ".svg"})


class PublicAssetFiles(StaticFiles):
    async def get_response(self, path: str, scope: dict) -> Response:
        if Path(path).suffix.lower() not in PUBLIC_ASSET_SUFFIXES:
            return Response(status_code=status.HTTP_404_NOT_FOUND)
        return await super().get_response(path, scope)


def create_app(
    settings: Settings | None = None,
    runner: NmapRunner | None = None,
    discovery_runner: GobusterRunner | None = None,
    subfinder_runner: SubfinderRunner | None = None,
    web_probe_runner: WebProbeRunner | None = None,
) -> FastAPI:
    config = settings or Settings.from_env()
    database = Database(config.database_path)
    key_manager = ApiKeyManager(database, config.api_key)
    user_manager = UserManager(database, config.session_ttl_minutes)
    def policy_for_tenant(tenant_id: str) -> ScopePolicy:
        tenant = database.get_tenant(tenant_id)
        if tenant is None or not tenant["enabled"]:
            raise ScopeError("Organization is not available")
        return ScopePolicy(tuple(tenant["allowed_networks"]), tuple(tenant["allowed_hosts"]))
    nmap_runner = runner or NmapRunner(config.nmap_binary, config.nmap_max_rate, config.nmap_timeout_seconds)
    gobuster_runner = discovery_runner or GobusterRunner(
        config.gobuster_binary,
        config.gobuster_wordlist or BUNDLED_WORDLIST,
        config.gobuster_threads,
        config.gobuster_timeout_seconds,
    )
    passive_runner = subfinder_runner or SubfinderRunner(
        config.subfinder_binary,
        config.database_path.parent,
        config.subfinder_rate_limit,
        config.subfinder_timeout_seconds,
    )
    surface_runner = web_probe_runner or WebProbeRunner(
        config.web_probe_timeout_seconds,
        config.web_probe_max_response_bytes,
    )
    service = ScanService(
        database,
        policy_for_tenant,
        nmap_runner,
        config.max_concurrent_scans,
        config.max_pending_scans,
        config.scheduler_poll_seconds,
    )
    discovery_service = DiscoveryService(
        database,
        policy_for_tenant,
        {"gobuster": gobuster_runner, "subfinder": passive_runner},
        config.max_concurrent_discoveries,
        config.max_pending_discoveries,
    )
    general_limiter = SlidingWindowLimiter()
    scan_limiter = SlidingWindowLimiter()
    discovery_limiter = SlidingWindowLimiter()
    web_probe_limiter = SlidingWindowLimiter()
    login_limiter = SlidingWindowLimiter()
    web_probe_semaphore = asyncio.Semaphore(config.max_concurrent_web_probes)

    @asynccontextmanager
    async def lifespan(app: FastAPI) -> AsyncIterator[None]:
        database.initialize(config.allowed_networks, config.allowed_hosts)
        user_manager.ensure_bootstrap_user(config.admin_username, config.admin_password)
        database.recover_interrupted_scans()
        database.recover_interrupted_discoveries()
        app.state.settings = config
        app.state.database = database
        app.state.scan_service = service
        app.state.discovery_service = discovery_service
        app.state.scan_limiter = scan_limiter
        app.state.api_key_manager = key_manager
        app.state.user_manager = user_manager
        service.start()
        yield
        await asyncio.gather(service.stop(), discovery_service.stop())

    app = FastAPI(title="ASM Guardian", version="1.9.1", docs_url=None, redoc_url=None, lifespan=lifespan)

    if config.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(config.cors_origins),
            allow_credentials=False,
            allow_methods=["GET", "POST", "PUT", "DELETE"],
            allow_headers=["Content-Type", "X-API-Key", "X-CSRF-Token"],
        )

    @app.middleware("http")
    async def security_and_rate_headers(request: Request, call_next):
        client = request.client.host if request.client else "unknown"
        if request.url.path.startswith("/api/") and not general_limiter.allow(client, config.request_rate_limit):
            response = JSONResponse({"detail": "Rate limit exceeded"}, status_code=status.HTTP_429_TOO_MANY_REQUESTS)
            response.headers["Retry-After"] = "60"
        else:
            response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        if request.url.path.startswith("/api/") or request.url.path in {"/", "/login", "/report"}:
            response.headers["Cache-Control"] = "no-store"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; "
            f"connect-src 'self'; frame-ancestors {' '.join(config.frame_ancestors)}; "
            "base-uri 'none'; form-action 'self'"
        )
        return response

    async def current_principal(
        request: Request,
        x_api_key: str | None = Header(default=None),
    ) -> Principal:
        if x_api_key is not None:
            principal = key_manager.authenticate(x_api_key)
        else:
            principal = user_manager.authenticate_session(request.cookies.get(SESSION_COOKIE_NAME))
        if principal is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
        return principal

    def require_roles(*roles: str):
        async def dependency(
            request: Request,
            x_csrf_token: str | None = Header(default=None),
            principal: Principal = Depends(current_principal),
        ) -> Principal:
            if principal.role not in roles:
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Insufficient role")
            if (
                request.method not in SAFE_METHODS
                and principal.kind == "user"
                and not user_manager.validate_csrf(
                    request.cookies.get(SESSION_COOKIE_NAME),
                    x_csrf_token,
                )
            ):
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid CSRF token")
            return principal

        return dependency

    viewer = require_roles("viewer", "operator", "admin")
    operator = require_roles("operator", "admin")
    administrator = require_roles("admin")

    async def system_administrator(principal: Principal = Depends(administrator)) -> Principal:
        if not principal.system_admin:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="System administrator required")
        return principal

    def client_key(request: Request) -> str:
        return request.client.host if request.client else "unknown"

    def session_payload(principal: Principal) -> dict:
        return {
            "id": principal.id,
            "username": principal.username,
            "name": principal.name,
            "role": principal.role,
            "kind": principal.kind,
            "tenant": {"id": principal.tenant_id, "name": principal.tenant_name},
            "system_admin": principal.system_admin,
        }

    @app.exception_handler(ScopeError)
    async def scope_error_handler(_request: Request, exc: ScopeError) -> JSONResponse:
        return JSONResponse({"detail": str(exc)}, status_code=status.HTTP_403_FORBIDDEN)

    @app.exception_handler(ScanCapacityError)
    async def scan_capacity_handler(_request: Request, exc: ScanCapacityError) -> JSONResponse:
        return JSONResponse(
            {"detail": str(exc)},
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            headers={"Retry-After": "5"},
        )

    @app.exception_handler(DiscoveryCapacityError)
    async def discovery_capacity_handler(_request: Request, exc: DiscoveryCapacityError) -> JSONResponse:
        return JSONResponse(
            {"detail": str(exc)},
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            headers={"Retry-After": "5"},
        )

    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.post("/api/v1/auth/login")
    async def login(payload: LoginRequest, request: Request, response: FastAPIResponse) -> dict:
        login_ip = client_key(request)
        ip_allowed = login_limiter.allow(f"login-ip:{login_ip}", config.login_rate_limit)
        user_allowed = login_limiter.allow(
            f"login-user:{login_ip}:{payload.username.lower()}", config.login_rate_limit
        )
        if not ip_allowed or not user_allowed:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many login attempts",
                headers={"Retry-After": "60"},
            )
        authenticated = user_manager.login(payload.username, payload.password)
        if authenticated is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password",
            )
        response.set_cookie(
            key=SESSION_COOKIE_NAME,
            value=authenticated.session_token,
            max_age=config.session_ttl_minutes * 60,
            expires=config.session_ttl_minutes * 60,
            path="/",
            secure=config.session_cookie_secure,
            httponly=True,
            samesite="strict",
        )
        response.set_cookie(
            key=CSRF_COOKIE_NAME,
            value=authenticated.csrf_token,
            max_age=config.session_ttl_minutes * 60,
            expires=config.session_ttl_minutes * 60,
            path="/",
            secure=config.session_cookie_secure,
            httponly=False,
            samesite="strict",
        )
        return {
            **session_payload(authenticated.principal),
            "csrf_token": authenticated.csrf_token,
            "expires_at": authenticated.expires_at,
        }

    @app.post("/api/v1/auth/csrf")
    async def refresh_csrf(
        request: Request,
        response: FastAPIResponse,
        principal: Principal = Depends(current_principal),
    ) -> dict[str, str]:
        if principal.kind != "user":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="CSRF recovery is only available for password sessions",
            )
        csrf_token = user_manager.refresh_csrf(request.cookies.get(SESSION_COOKIE_NAME))
        if csrf_token is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required")
        response.set_cookie(
            key=CSRF_COOKIE_NAME,
            value=csrf_token,
            max_age=config.session_ttl_minutes * 60,
            expires=config.session_ttl_minutes * 60,
            path="/",
            secure=config.session_cookie_secure,
            httponly=False,
            samesite="strict",
        )
        return {"csrf_token": csrf_token}

    @app.post(
        "/api/v1/auth/logout",
        status_code=status.HTTP_204_NO_CONTENT,
        response_class=Response,
        response_model=None,
    )
    async def logout(
        request: Request,
        _principal: Principal = Depends(viewer),
    ) -> Response:
        user_manager.logout(request.cookies.get(SESSION_COOKIE_NAME))
        response = Response(status_code=status.HTTP_204_NO_CONTENT)
        response.delete_cookie(
            SESSION_COOKIE_NAME,
            path="/",
            secure=config.session_cookie_secure,
            httponly=True,
            samesite="strict",
        )
        response.delete_cookie(
            CSRF_COOKIE_NAME,
            path="/",
            secure=config.session_cookie_secure,
            httponly=False,
            samesite="strict",
        )
        return response

    @app.get("/api/v1/session")
    async def session(principal: Principal = Depends(viewer)) -> dict:
        return session_payload(principal)

    @app.get("/api/v1/sessions")
    async def list_sessions(
        request: Request,
        principal: Principal = Depends(viewer),
    ) -> list[dict]:
        if principal.kind != "user":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Session management is only available for password accounts",
            )
        return user_manager.list_sessions(principal, request.cookies.get(SESSION_COOKIE_NAME))

    @app.delete(
        "/api/v1/sessions/{session_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        response_class=Response,
        response_model=None,
    )
    async def revoke_session(
        session_id: str,
        request: Request,
        principal: Principal = Depends(viewer),
    ) -> Response:
        if principal.kind != "user":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Session management is only available for password accounts",
            )
        sessions = user_manager.list_sessions(principal, request.cookies.get(SESSION_COOKIE_NAME))
        current = any(item["id"] == session_id and item["current"] for item in sessions)
        if not user_manager.revoke_session(principal, session_id):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Active session not found")
        response = Response(status_code=status.HTTP_204_NO_CONTENT)
        if current:
            response.delete_cookie(
                SESSION_COOKIE_NAME,
                path="/",
                secure=config.session_cookie_secure,
                httponly=True,
                samesite="strict",
            )
            response.delete_cookie(
                CSRF_COOKIE_NAME,
                path="/",
                secure=config.session_cookie_secure,
                httponly=False,
                samesite="strict",
            )
        return response

    @app.get("/api/v1/overview")
    async def overview(principal: Principal = Depends(viewer)) -> dict:
        return database.overview(principal.tenant_id)

    @app.post("/api/v1/scans", status_code=status.HTTP_202_ACCEPTED)
    async def create_scan(
        payload: ScanRequest,
        request: Request,
        principal: Principal = Depends(operator),
    ) -> dict:
        if not scan_limiter.allow(f"scan:{principal.id}:{client_key(request)}", config.scan_rate_limit):
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Scan creation rate limit exceeded",
            )
        return await service.submit(
            payload.target,
            tuple(payload.ports or ()),
            payload.service_detection,
            payload.port_profile,
            tenant_id=principal.tenant_id,
        )

    @app.get("/api/v1/scans")
    async def list_scans(limit: int = 50, principal: Principal = Depends(viewer)) -> list[dict]:
        if not 1 <= limit <= 200:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 200")
        return database.list_scans(limit, principal.tenant_id)

    @app.get("/api/v1/scans/{scan_id}")
    async def get_scan(scan_id: str, principal: Principal = Depends(viewer)) -> dict:
        scan = database.get_scan(scan_id, principal.tenant_id)
        if scan is None:
            raise HTTPException(status_code=404, detail="Scan not found")
        return scan

    @app.delete("/api/v1/scans/{scan_id}")
    async def cancel_scan(scan_id: str, principal: Principal = Depends(operator)) -> dict:
        cancelled = service.cancel(scan_id, principal.tenant_id)
        if cancelled is None:
            existing = database.get_scan(scan_id, principal.tenant_id)
            if existing is None:
                raise HTTPException(status_code=404, detail="Scan not found")
            raise HTTPException(status_code=409, detail="Only queued or running scans can be cancelled")
        database.record_security_event(
            tenant_id=principal.tenant_id,
            actor_id=principal.id,
            actor_name=principal.name,
            action="scan.cancelled",
            target_id=scan_id,
            details={"target": cancelled["target"]},
        )
        return cancelled

    @app.get("/api/v1/assets")
    async def list_assets(limit: int = 500, principal: Principal = Depends(viewer)) -> list[dict]:
        if not 1 <= limit <= 2000:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 2000")
        return database.list_assets(limit, principal.tenant_id)

    @app.get("/api/v1/inventory")
    async def list_inventory(limit: int = 500, principal: Principal = Depends(viewer)) -> list[dict]:
        if not 1 <= limit <= 2_000:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 2000")
        return database.list_inventory(limit, principal.tenant_id)

    @app.put("/api/v1/assets/{asset_ip}")
    async def update_asset(
        asset_ip: str,
        payload: AssetMetadataRequest,
        principal: Principal = Depends(operator),
    ) -> dict:
        try:
            normalized_ip = ipaddress.ip_address(asset_ip).compressed
        except ValueError as exc:
            raise HTTPException(status_code=422, detail="asset_ip must be a valid IP address") from exc
        updated = database.upsert_asset_metadata(
            ip=normalized_ip,
            display_name=payload.display_name,
            owner=payload.owner,
            environment=payload.environment,
            criticality=payload.criticality,
            tags=tuple(payload.tags),
            notes=payload.notes,
            tenant_id=principal.tenant_id,
            actor_id=principal.id,
            actor_name=principal.name,
        )
        if updated is None:
            raise HTTPException(status_code=404, detail="Observed asset not found")
        return updated

    @app.post("/api/v1/discoveries", status_code=status.HTTP_202_ACCEPTED)
    async def create_discovery(
        payload: DiscoveryRequest,
        request: Request,
        principal: Principal = Depends(operator),
    ) -> dict:
        authorized = policy_for_tenant(principal.tenant_id).authorize_discovery_domain(payload.domain)
        if not discovery_limiter.allow(
            f"discovery:{principal.id}:{client_key(request)}", config.discovery_rate_limit
        ):
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="DNS discovery creation rate limit exceeded",
            )
        return await discovery_service.submit(authorized, payload.engine, principal.tenant_id)

    @app.get("/api/v1/discoveries")
    async def list_discoveries(limit: int = 50, principal: Principal = Depends(viewer)) -> list[dict]:
        if not 1 <= limit <= 200:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 200")
        return database.list_discoveries(limit, principal.tenant_id)

    @app.get("/api/v1/discoveries/{discovery_id}")
    async def get_discovery(discovery_id: str, principal: Principal = Depends(viewer)) -> dict:
        discovery = database.get_discovery(discovery_id, principal.tenant_id)
        if discovery is None:
            raise HTTPException(status_code=404, detail="Discovery not found")
        return discovery

    @app.delete("/api/v1/discoveries/{discovery_id}")
    async def cancel_discovery(discovery_id: str, principal: Principal = Depends(operator)) -> dict:
        cancelled = discovery_service.cancel(discovery_id, principal.tenant_id)
        if cancelled is None:
            existing = database.get_discovery(discovery_id, principal.tenant_id)
            if existing is None:
                raise HTTPException(status_code=404, detail="Discovery not found")
            raise HTTPException(status_code=409, detail="Only queued or running discoveries can be cancelled")
        database.record_security_event(
            tenant_id=principal.tenant_id,
            actor_id=principal.id,
            actor_name=principal.name,
            action="discovery.cancelled",
            target_id=discovery_id,
            details={"domain": cancelled["domain"]},
        )
        return cancelled

    @app.get("/api/v1/discovered-hosts")
    async def list_discovered_hosts(limit: int = 500, principal: Principal = Depends(viewer)) -> list[dict]:
        if not 1 <= limit <= 2000:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 2000")
        return database.list_discovered_hosts(limit, principal.tenant_id)

    @app.post("/api/v1/web-probes")
    async def create_web_probe(
        payload: WebProbeRequest,
        request: Request,
        principal: Principal = Depends(operator),
    ) -> dict:
        if not web_probe_limiter.allow(
            f"web-probe:{principal.id}:{client_key(request)}", config.web_probe_rate_limit
        ):
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Web probe rate limit exceeded",
            )
        resolved = await asyncio.to_thread(policy_for_tenant(principal.tenant_id).resolve_target, payload.target)
        if len(resolved.addresses) > config.web_probe_max_addresses:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Web probe accepts at most {config.web_probe_max_addresses} resolved addresses",
            )
        try:
            await asyncio.wait_for(web_probe_semaphore.acquire(), timeout=1)
        except TimeoutError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Web probe capacity is temporarily exhausted",
                headers={"Retry-After": "5"},
            ) from exc
        try:
            output = await asyncio.to_thread(surface_runner.run, resolved.requested, resolved.addresses)
        finally:
            web_probe_semaphore.release()
        database.record_web_observations(
            resolved.requested,
            output.observations,
            principal.tenant_id,
            config.tls_expiry_warning_days,
        )
        return {
            "target": resolved.requested,
            "addresses": list(resolved.addresses),
            "observations": list(output.observations),
        }

    @app.get("/api/v1/web-observations")
    async def list_web_observations(
        limit: int = 500,
        principal: Principal = Depends(viewer),
    ) -> list[dict]:
        if not 1 <= limit <= 2_000:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 2000")
        return database.list_web_observations(limit, principal.tenant_id)

    @app.get("/api/v1/alerts")
    async def list_alerts(
        limit: int = 100,
        unacknowledged_only: bool = False,
        principal: Principal = Depends(viewer),
    ) -> list[dict]:
        if not 1 <= limit <= 500:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 500")
        return database.list_alerts(limit, unacknowledged_only, principal.tenant_id)

    @app.post("/api/v1/alerts/{alert_id}/acknowledge")
    async def acknowledge_alert(alert_id: str, principal: Principal = Depends(operator)) -> dict:
        if not database.acknowledge_alert(alert_id, principal.tenant_id):
            raise HTTPException(status_code=404, detail="Alert not found")
        alert = database.get_alert(alert_id, principal.tenant_id)
        if alert is None:
            raise HTTPException(status_code=404, detail="Alert not found")
        return alert

    @app.post("/api/v1/monitors", status_code=status.HTTP_201_CREATED)
    async def create_monitor(
        payload: MonitorRequest,
        request: Request,
        principal: Principal = Depends(operator),
    ) -> dict:
        if not scan_limiter.allow(f"monitor:{principal.id}:{client_key(request)}", config.scan_rate_limit):
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Monitor creation rate limit exceeded",
            )
        # Resolve without launching a scan so invalid or out-of-scope schedules are never persisted.
        checked = await asyncio.to_thread(policy_for_tenant(principal.tenant_id).resolve_target, payload.target)
        return database.create_monitor(
            payload.name,
            checked.requested,
            tuple(payload.ports or ()),
            payload.service_detection,
            payload.interval_minutes,
            payload.port_profile,
            principal.tenant_id,
        )

    @app.get("/api/v1/monitors")
    async def list_monitors(principal: Principal = Depends(viewer)) -> list[dict]:
        return database.list_monitors(principal.tenant_id)

    @app.delete(
        "/api/v1/monitors/{monitor_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        response_class=Response,
        response_model=None,
    )
    async def delete_monitor(
        monitor_id: str,
        principal: Principal = Depends(operator),
    ) -> Response:
        if not database.delete_monitor(monitor_id, principal.tenant_id):
            raise HTTPException(status_code=404, detail="Monitor not found")
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @app.get("/api/v1/users")
    async def list_users(principal: Principal = Depends(administrator)) -> list[dict]:
        return user_manager.list_users(principal)

    @app.post("/api/v1/users", status_code=status.HTTP_201_CREATED)
    async def create_user(
        payload: UserCreateRequest,
        principal: Principal = Depends(administrator),
    ) -> dict:
        try:
            return user_manager.create_user(
                username=payload.username,
                display_name=payload.display_name,
                password=payload.password,
                role=payload.role,
                tenant_id=payload.tenant_id,
                actor=principal,
            )
        except sqlite3.IntegrityError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Username already exists") from exc
        except PermissionError as exc:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.post(
        "/api/v1/users/me/password",
        status_code=status.HTTP_204_NO_CONTENT,
        response_class=Response,
        response_model=None,
    )
    async def change_own_password(
        payload: PasswordChangeRequest,
        principal: Principal = Depends(viewer),
    ) -> Response:
        if not user_manager.change_own_password(
            principal,
            payload.current_password,
            payload.new_password,
        ):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Current password is invalid or password login is not active",
            )
        response = Response(status_code=status.HTTP_204_NO_CONTENT)
        response.delete_cookie(
            SESSION_COOKIE_NAME,
            path="/",
            secure=config.session_cookie_secure,
            httponly=True,
            samesite="strict",
        )
        response.delete_cookie(
            CSRF_COOKIE_NAME,
            path="/",
            secure=config.session_cookie_secure,
            httponly=False,
            samesite="strict",
        )
        return response

    @app.post(
        "/api/v1/users/{user_id}/password",
        status_code=status.HTTP_204_NO_CONTENT,
        response_class=Response,
        response_model=None,
    )
    async def reset_user_password(
        user_id: str,
        payload: PasswordResetRequest,
        principal: Principal = Depends(administrator),
    ) -> Response:
        if not user_manager.reset_password(user_id, payload.password, principal):
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found")
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @app.delete(
        "/api/v1/users/{user_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        response_class=Response,
        response_model=None,
    )
    async def disable_user(
        user_id: str,
        principal: Principal = Depends(administrator),
    ) -> Response:
        try:
            disabled = user_manager.disable_user(user_id, principal)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
        if not disabled:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="User not found or protected")
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @app.get("/api/v1/api-keys")
    async def list_api_keys(principal: Principal = Depends(administrator)) -> list[dict]:
        return key_manager.list_keys(principal)

    @app.post("/api/v1/api-keys", status_code=status.HTTP_201_CREATED)
    async def create_api_key(
        payload: ApiKeyCreateRequest,
        principal: Principal = Depends(administrator),
    ) -> dict:
        try:
            return key_manager.create(
                payload.name,
                payload.role,
                payload.expires_in_days,
                principal,
                payload.tenant_id,
            )
        except PermissionError as exc:
            raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc

    @app.post("/api/v1/api-keys/{key_id}/rotate", status_code=status.HTTP_201_CREATED)
    async def rotate_api_key(
        key_id: str,
        payload: ApiKeyRotateRequest,
        principal: Principal = Depends(administrator),
    ) -> dict:
        try:
            rotated = key_manager.rotate(key_id, payload.expires_in_days, principal)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
        if rotated is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found or already revoked")
        return rotated

    @app.delete(
        "/api/v1/api-keys/{key_id}",
        status_code=status.HTTP_204_NO_CONTENT,
        response_class=Response,
        response_model=None,
    )
    async def revoke_api_key(
        key_id: str,
        principal: Principal = Depends(administrator),
    ) -> Response:
        try:
            revoked = key_manager.revoke(key_id, principal)
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
        if not revoked:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="API key not found or already revoked")
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    @app.get("/api/v1/security-events")
    async def list_security_events(
        limit: int = 100,
        _principal: Principal = Depends(administrator),
    ) -> list[dict]:
        if not 1 <= limit <= 500:
            raise HTTPException(status_code=422, detail="limit must be between 1 and 500")
        return database.list_security_events(limit, None if _principal.system_admin else _principal.tenant_id)

    def report_summary(principal: Principal) -> dict:
        return {
            "generated_at": iso(),
            "tenant": {"id": principal.tenant_id, "name": principal.tenant_name},
            "overview": database.overview(principal.tenant_id),
            "inventory": database.list_inventory(2_000, principal.tenant_id),
            "alerts": database.list_alerts(500, True, principal.tenant_id),
            "scans": database.list_scans(200, principal.tenant_id),
        }

    @app.get("/api/v1/reports/summary")
    async def summary_report(principal: Principal = Depends(viewer)) -> dict:
        return report_summary(principal)

    @app.get("/api/v1/exports/assets.csv", response_class=Response)
    async def export_assets(principal: Principal = Depends(viewer)) -> Response:
        content = assets_csv(database.list_inventory(2_000, principal.tenant_id))
        return Response(
            content=content,
            media_type="text/csv; charset=utf-8",
            headers={"Content-Disposition": 'attachment; filename="asm-guardian-assets.csv"'},
        )

    @app.post("/api/v1/maintenance/retention")
    async def apply_retention(
        payload: RetentionRequest,
        principal: Principal = Depends(administrator),
    ) -> dict:
        result = database.prune_history(
            older_than_days=payload.older_than_days,
            dry_run=payload.dry_run,
            tenant_id=principal.tenant_id,
        )
        database.record_security_event(
            tenant_id=principal.tenant_id,
            actor_id=principal.id,
            actor_name=principal.name,
            action="maintenance.retention_preview" if payload.dry_run else "maintenance.retention_applied",
            target_id=None,
            details={"older_than_days": payload.older_than_days, **result},
        )
        return result

    @app.get("/api/v1/tenants")
    async def list_tenants(_principal: Principal = Depends(system_administrator)) -> list[dict]:
        return database.list_tenants()

    @app.post("/api/v1/tenants", status_code=status.HTTP_201_CREATED)
    async def create_tenant(
        payload: TenantCreateRequest,
        principal: Principal = Depends(system_administrator),
    ) -> dict:
        try:
            policy = ScopePolicy(tuple(payload.allowed_networks), tuple(payload.allowed_hosts))
            return database.create_tenant(
                slug=payload.slug,
                name=payload.name,
                allowed_networks=tuple(str(network) for network in policy.networks),
                allowed_hosts=policy.hosts,
                actor_id=principal.id,
                actor_name=principal.name,
            )
        except sqlite3.IntegrityError as exc:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Tenant slug already exists") from exc
        except ValueError as exc:
            raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc

    app.mount("/static", PublicAssetFiles(directory=PACKAGE_DIR / "static"), name="static")

    @app.get("/report", include_in_schema=False)
    async def printable_summary(request: Request) -> Response:
        principal = user_manager.authenticate_session(request.cookies.get(SESSION_COOKIE_NAME))
        if principal is None:
            return RedirectResponse("/login", status_code=status.HTTP_303_SEE_OTHER)
        return Response(printable_report(report_summary(principal)), media_type="text/html; charset=utf-8")

    @app.get("/", include_in_schema=False)
    async def dashboard(request: Request) -> Response:
        principal = user_manager.authenticate_session(request.cookies.get(SESSION_COOKIE_NAME))
        if principal is None:
            return RedirectResponse("/login", status_code=status.HTTP_303_SEE_OTHER)
        return FileResponse(PACKAGE_DIR / "static" / "index.html")

    @app.get("/login", include_in_schema=False)
    async def login_page(request: Request) -> Response:
        principal = user_manager.authenticate_session(request.cookies.get(SESSION_COOKIE_NAME))
        if principal is not None:
            return RedirectResponse("/", status_code=status.HTTP_303_SEE_OTHER)
        response = FileResponse(PACKAGE_DIR / "static" / "login.html")
        response.delete_cookie(
            CSRF_COOKIE_NAME,
            path="/",
            secure=config.session_cookie_secure,
            httponly=False,
            samesite="strict",
        )
        return response

    return app
