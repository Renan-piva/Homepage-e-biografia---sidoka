from __future__ import annotations

import hashlib
import hmac
import secrets
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from .database import DEFAULT_TENANT_ID, Database


@dataclass(frozen=True, slots=True)
class Principal:
    id: str
    name: str
    role: str
    kind: str
    tenant_id: str
    tenant_name: str
    system_admin: bool = False
    username: str | None = None


@dataclass(frozen=True, slots=True)
class UserSession:
    principal: Principal
    session_token: str
    csrf_token: str
    expires_at: str


SCRYPT_N = 2**14
SCRYPT_R = 8
SCRYPT_P = 1
SCRYPT_DKLEN = 32


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(
        password.encode("utf-8"),
        salt=salt,
        n=SCRYPT_N,
        r=SCRYPT_R,
        p=SCRYPT_P,
        dklen=SCRYPT_DKLEN,
    )
    return f"scrypt${SCRYPT_N}${SCRYPT_R}${SCRYPT_P}${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        algorithm, raw_n, raw_r, raw_p, raw_salt, raw_digest = encoded.split("$", 5)
        if algorithm != "scrypt":
            return False
        n, r, p = int(raw_n), int(raw_r), int(raw_p)
        salt, expected = bytes.fromhex(raw_salt), bytes.fromhex(raw_digest)
        if n != SCRYPT_N or r != SCRYPT_R or p != SCRYPT_P or len(salt) != 16 or len(expected) != SCRYPT_DKLEN:
            return False
        supplied = hashlib.scrypt(
            password.encode("utf-8"),
            salt=salt,
            n=n,
            r=r,
            p=p,
            dklen=len(expected),
        )
    except (TypeError, ValueError):
        return False
    return hmac.compare_digest(supplied, expected)


DUMMY_PASSWORD_HASH = hash_password("dummy-password-used-only-for-constant-work")


class UserManager:
    def __init__(self, database: Database, session_ttl_minutes: int) -> None:
        self.database = database
        self.session_ttl_minutes = session_ttl_minutes

    def ensure_bootstrap_user(self, username: str, password: str) -> None:
        if not username or not password:
            return
        existing = self.database.get_user_by_username(username)
        if existing is not None:
            if not existing["system_admin"]:
                raise RuntimeError("Configured bootstrap username belongs to a non-system user")
            return
        self.database.create_user(
            user_id=str(uuid.uuid4()),
            tenant_id=DEFAULT_TENANT_ID,
            username=username,
            display_name="Administrador do ambiente",
            password_hash=hash_password(password),
            role="admin",
            system_admin=True,
            actor_id="environment",
            actor_name="Configuração inicial",
        )

    def login(self, username: str, password: str) -> UserSession | None:
        normalized = username.lower()
        record = self.database.get_user_by_username(normalized)
        stored_hash = record["password_hash"] if record else DUMMY_PASSWORD_HASH
        password_valid = verify_password(password, stored_hash)
        if record is None or not password_valid or not record["enabled"]:
            return None
        tenant = self.database.get_tenant(record["tenant_id"])
        if tenant is None or not tenant["enabled"]:
            return None

        session_token = secrets.token_urlsafe(32)
        csrf_token = secrets.token_urlsafe(32)
        expires_at = (datetime.now(UTC) + timedelta(minutes=self.session_ttl_minutes)).isoformat(timespec="seconds")
        self.database.create_user_session(
            session_id=str(uuid.uuid4()),
            user_id=record["id"],
            token_hash=self._digest(session_token),
            csrf_hash=self._digest(csrf_token),
            expires_at=expires_at,
        )
        return UserSession(
            principal=self._principal(record, tenant["name"]),
            session_token=session_token,
            csrf_token=csrf_token,
            expires_at=expires_at,
        )

    def authenticate_session(self, session_token: str | None) -> Principal | None:
        if not session_token or len(session_token) > 512:
            return None
        record = self.database.get_user_session(self._digest(session_token))
        if not self._active_session(record):
            return None
        self.database.touch_user_session(record["session_id"])
        return self._principal(record, record["tenant_name"])

    def validate_csrf(self, session_token: str | None, supplied: str | None) -> bool:
        if not session_token or not supplied or len(supplied) > 512:
            return False
        record = self.database.get_user_session(self._digest(session_token))
        return bool(
            self._active_session(record)
            and hmac.compare_digest(self._digest(supplied), record["csrf_hash"])
        )

    def refresh_csrf(self, session_token: str | None) -> str | None:
        if not session_token or len(session_token) > 512:
            return None
        record = self.database.get_user_session(self._digest(session_token))
        if not self._active_session(record):
            return None
        csrf_token = secrets.token_urlsafe(32)
        if not self.database.update_user_session_csrf(record["session_id"], self._digest(csrf_token)):
            return None
        return csrf_token

    def logout(self, session_token: str | None) -> bool:
        if not session_token or len(session_token) > 512:
            return False
        return self.database.revoke_user_session(self._digest(session_token))

    def list_sessions(self, actor: Principal, session_token: str | None) -> list[dict]:
        if actor.kind != "user" or not session_token:
            return []
        current = self.database.get_user_session(self._digest(session_token))
        current_id = current["session_id"] if current and current["id"] == actor.id else None
        return [
            {**session, "current": session["id"] == current_id}
            for session in self.database.list_user_sessions(actor.id)
        ]

    def revoke_session(self, actor: Principal, session_id: str) -> bool:
        if actor.kind != "user":
            return False
        return self.database.revoke_user_session_by_id(
            session_id=session_id,
            user_id=actor.id,
            tenant_id=actor.tenant_id,
            actor_name=actor.name,
        )

    def create_user(
        self,
        *,
        username: str,
        display_name: str,
        password: str,
        role: str,
        tenant_id: str | None,
        actor: Principal,
    ) -> dict:
        requested_tenant = tenant_id or actor.tenant_id
        if not actor.system_admin and requested_tenant != actor.tenant_id:
            raise PermissionError("Tenant administrators can only create users for their own organization")
        tenant = self.database.get_tenant(requested_tenant)
        if tenant is None or not tenant["enabled"]:
            raise ValueError("Tenant not found or disabled")
        return self.database.create_user(
            user_id=str(uuid.uuid4()),
            tenant_id=requested_tenant,
            username=username.lower(),
            display_name=display_name,
            password_hash=hash_password(password),
            role=role,
            system_admin=False,
            actor_id=actor.id,
            actor_name=actor.name,
        )

    def list_users(self, actor: Principal) -> list[dict]:
        return self.database.list_users(None if actor.system_admin else actor.tenant_id)

    def change_own_password(self, actor: Principal, current_password: str, new_password: str) -> bool:
        if actor.kind != "user":
            return False
        record = self.database.get_user(actor.id, actor.tenant_id)
        if record is None or not verify_password(current_password, record["password_hash"]):
            return False
        return self.database.update_user_password(
            user_id=actor.id,
            tenant_id=actor.tenant_id,
            password_hash=hash_password(new_password),
            actor_id=actor.id,
            actor_name=actor.name,
        )

    def reset_password(self, user_id: str, password: str, actor: Principal) -> bool:
        record = self.database.get_user(user_id, None if actor.system_admin else actor.tenant_id)
        if record is None:
            return False
        return self.database.update_user_password(
            user_id=user_id,
            tenant_id=record["tenant_id"],
            password_hash=hash_password(password),
            actor_id=actor.id,
            actor_name=actor.name,
        )

    def disable_user(self, user_id: str, actor: Principal) -> bool:
        if user_id == actor.id:
            raise ValueError("Administrators cannot disable their own account")
        record = self.database.get_user(user_id, None if actor.system_admin else actor.tenant_id)
        if record is None or record["system_admin"]:
            return False
        return self.database.disable_user(
            user_id=user_id,
            tenant_id=record["tenant_id"],
            actor_id=actor.id,
            actor_name=actor.name,
        )

    @staticmethod
    def _active_session(record: dict | None) -> bool:
        return bool(
            record
            and not record["revoked_at"]
            and record["enabled"]
            and record["tenant_enabled"]
            and datetime.fromisoformat(record["expires_at"]) > datetime.now(UTC)
        )

    @staticmethod
    def _principal(record: dict, tenant_name: str) -> Principal:
        return Principal(
            id=record["id"],
            name=record["display_name"],
            role=record["role"],
            kind="user",
            tenant_id=record["tenant_id"],
            tenant_name=tenant_name,
            system_admin=bool(record["system_admin"]),
            username=record["username"],
        )

    @staticmethod
    def _digest(value: str) -> str:
        return hashlib.sha256(value.encode("utf-8")).hexdigest()


class ApiKeyManager:
    def __init__(self, database: Database, bootstrap_key: str) -> None:
        self.database = database
        self.bootstrap_key = bootstrap_key

    def authenticate(self, provided: str | None) -> Principal | None:
        if not provided or len(provided) > 256:
            return None
        if hmac.compare_digest(provided, self.bootstrap_key):
            tenant = self.database.get_tenant(DEFAULT_TENANT_ID)
            tenant_name = tenant["name"] if tenant else "Organização padrão"
            return Principal(
                id="bootstrap",
                name="Bootstrap do ambiente",
                role="admin",
                kind="bootstrap",
                tenant_id=DEFAULT_TENANT_ID,
                tenant_name=tenant_name,
                system_admin=True,
            )

        prefix = self._parse_prefix(provided)
        if prefix is None:
            return None
        record = self.database.get_api_key_by_prefix(prefix)
        if record is None or record["revoked_at"]:
            return None
        tenant = self.database.get_tenant(record["tenant_id"])
        if tenant is None or not tenant["enabled"]:
            return None
        if record["expires_at"] and datetime.fromisoformat(record["expires_at"]) <= datetime.now(UTC):
            return None
        supplied_hash = self._digest(provided)
        if not hmac.compare_digest(supplied_hash, record["key_hash"]):
            return None
        self.database.touch_api_key(record["id"])
        return Principal(
            id=record["id"],
            name=record["name"],
            role=record["role"],
            kind="managed",
            tenant_id=record["tenant_id"],
            tenant_name=tenant["name"],
        )

    def list_keys(self, actor: Principal) -> list[dict]:
        bootstrap = {
            "id": "bootstrap",
            "name": "Bootstrap do ambiente",
            "prefix": "ASM_API_KEY",
            "role": "admin",
            "created_at": None,
            "created_by": "environment",
            "expires_at": None,
            "last_used_at": None,
            "revoked_at": None,
            "status": "active",
            "kind": "bootstrap",
            "tenant_id": DEFAULT_TENANT_ID,
        }
        if actor.system_admin:
            return [bootstrap, *self.database.list_api_keys(None)]
        return self.database.list_api_keys(actor.tenant_id)

    def create(
        self,
        name: str,
        role: str,
        expires_in_days: int | None,
        actor: Principal,
        tenant_id: str | None = None,
    ) -> dict:
        requested_tenant = tenant_id or actor.tenant_id
        if not actor.system_admin and requested_tenant != actor.tenant_id:
            raise PermissionError("Tenant administrators can only create keys for their own organization")
        tenant = self.database.get_tenant(requested_tenant)
        if tenant is None or not tenant["enabled"]:
            raise ValueError("Tenant not found or disabled")
        for _ in range(5):
            token, prefix, key_hash = self._new_secret()
            key_id = str(uuid.uuid4())
            try:
                result = self.database.create_api_key(
                    key_id=key_id,
                    name=name,
                    prefix=prefix,
                    key_hash=key_hash,
                    role=role,
                    expires_at=self._expiry(expires_in_days),
                    actor_id=actor.id,
                    actor_name=actor.name,
                    tenant_id=requested_tenant,
                )
            except sqlite3.IntegrityError:
                continue
            return {**result, "api_key": token}
        raise RuntimeError("Could not generate a unique API key")

    def revoke(self, key_id: str, actor: Principal) -> bool:
        if key_id == "bootstrap":
            raise ValueError("The bootstrap key can only be changed in ASM_API_KEY and requires a restart")
        record = self.database.get_api_key(key_id, None)
        if record is None:
            return False
        if not actor.system_admin and record["tenant_id"] != actor.tenant_id:
            return False
        return self.database.revoke_api_key(key_id, actor.id, actor.name, record["tenant_id"])

    def rotate(self, key_id: str, expires_in_days: int | None, actor: Principal) -> dict | None:
        if key_id == "bootstrap":
            raise ValueError("The bootstrap key can only be changed in ASM_API_KEY and requires a restart")
        record = self.database.get_api_key(key_id, None)
        if record is None or (not actor.system_admin and record["tenant_id"] != actor.tenant_id):
            return None
        for _ in range(5):
            token, prefix, key_hash = self._new_secret()
            try:
                result = self.database.rotate_api_key(
                    old_key_id=key_id,
                    new_key_id=str(uuid.uuid4()),
                    prefix=prefix,
                    key_hash=key_hash,
                    expires_at=self._expiry(expires_in_days),
                    actor_id=actor.id,
                    actor_name=actor.name,
                    tenant_id=record["tenant_id"],
                )
            except sqlite3.IntegrityError:
                continue
            return {**result, "api_key": token} if result else None
        raise RuntimeError("Could not generate a unique API key")

    @staticmethod
    def _new_secret() -> tuple[str, str, str]:
        prefix = secrets.token_hex(6)
        token = f"agk_{prefix}_{secrets.token_urlsafe(32)}"
        return token, prefix, ApiKeyManager._digest(token)

    @staticmethod
    def _digest(token: str) -> str:
        return hashlib.sha256(token.encode("utf-8")).hexdigest()

    @staticmethod
    def _parse_prefix(token: str) -> str | None:
        parts = token.split("_", 2)
        if len(parts) != 3 or parts[0] != "agk" or len(parts[1]) != 12:
            return None
        try:
            int(parts[1], 16)
        except ValueError:
            return None
        return parts[1]

    @staticmethod
    def _expiry(expires_in_days: int | None) -> str | None:
        if expires_in_days is None:
            return None
        return (datetime.now(UTC) + timedelta(days=expires_in_days)).isoformat(timespec="seconds")
