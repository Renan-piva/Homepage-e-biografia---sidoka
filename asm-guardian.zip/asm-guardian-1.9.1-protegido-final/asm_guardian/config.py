from __future__ import annotations

import ipaddress
import os
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit


ORIGIN_HOST_RE = re.compile(
    r"(?=^.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)*"
    r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$"
)
USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{2,63}$")


def _getenv(env: Mapping[str, str] | None, name: str, default: str = "") -> str:
    source = os.environ if env is None else env
    return source.get(name, default)


def _csv(name: str, default: str = "", env: Mapping[str, str] | None = None) -> tuple[str, ...]:
    return tuple(item.strip() for item in _getenv(env, name, default).split(",") if item.strip())


def _int(name: str, default: int, minimum: int, maximum: int, env: Mapping[str, str] | None = None) -> int:
    raw = _getenv(env, name, str(default))
    try:
        value = int(raw)
    except ValueError as exc:
        raise ValueError(f"{name} must be an integer") from exc
    if not minimum <= value <= maximum:
        raise ValueError(f"{name} must be between {minimum} and {maximum}")
    return value


def _bool(name: str, default: bool, env: Mapping[str, str] | None = None) -> bool:
    raw = _getenv(env, name, "true" if default else "false").strip().lower()
    if raw in {"1", "true", "yes", "on"}:
        return True
    if raw in {"0", "false", "no", "off"}:
        return False
    raise ValueError(f"{name} must be true or false")


def _normalize_frame_ancestor(value: str) -> str:
    source = value.strip()
    keyword = source.lower()
    if keyword in {"self", "'self'"}:
        return "'self'"
    if keyword in {"none", "'none'"}:
        return "'none'"

    try:
        parsed = urlsplit(source)
        port = parsed.port
    except ValueError as exc:
        raise ValueError("ASM_FRAME_ANCESTORS contains an invalid HTTPS origin") from exc
    if (
        parsed.scheme.lower() != "https"
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
        or parsed.path
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("ASM_FRAME_ANCESTORS accepts only 'self', 'none', or path-free HTTPS origins")
    if port is not None and not 1 <= port <= 65535:
        raise ValueError("ASM_FRAME_ANCESTORS contains an invalid port")

    hostname = parsed.hostname.lower()
    try:
        normalized_host = ipaddress.ip_address(hostname).compressed
        rendered_host = f"[{normalized_host}]" if ":" in normalized_host else normalized_host
    except ValueError:
        try:
            normalized_host = hostname.encode("idna").decode("ascii")
        except UnicodeError as exc:
            raise ValueError("ASM_FRAME_ANCESTORS contains an invalid hostname") from exc
        if not ORIGIN_HOST_RE.fullmatch(normalized_host):
            raise ValueError("ASM_FRAME_ANCESTORS contains an invalid hostname")
        rendered_host = normalized_host
    return f"https://{rendered_host}{f':{port}' if port is not None else ''}"


@dataclass(frozen=True, slots=True)
class Settings:
    database_path: Path = Path("data/asm_guardian.db")
    api_key: str = ""
    admin_username: str = ""
    admin_password: str = ""
    session_ttl_minutes: int = 480
    session_cookie_secure: bool = False
    login_rate_limit: int = 5
    allowed_networks: tuple[str, ...] = ("127.0.0.0/8", "::1/128")
    allowed_hosts: tuple[str, ...] = ()
    cors_origins: tuple[str, ...] = ()
    frame_ancestors: tuple[str, ...] = ("'self'",)
    request_rate_limit: int = 120
    scan_rate_limit: int = 6
    max_concurrent_scans: int = 2
    max_pending_scans: int = 16
    scheduler_poll_seconds: int = 15
    nmap_binary: str = "nmap"
    nmap_max_rate: int = 50
    nmap_timeout_seconds: int = 3600
    gobuster_binary: str = "gobuster"
    gobuster_wordlist: Path | None = None
    gobuster_threads: int = 5
    gobuster_timeout_seconds: int = 300
    subfinder_binary: str = "subfinder"
    subfinder_rate_limit: int = 10
    subfinder_timeout_seconds: int = 300
    discovery_rate_limit: int = 2
    max_concurrent_discoveries: int = 1
    max_pending_discoveries: int = 4
    web_probe_rate_limit: int = 6
    web_probe_timeout_seconds: int = 5
    web_probe_max_response_bytes: int = 65_536
    web_probe_max_addresses: int = 4
    max_concurrent_web_probes: int = 2
    tls_expiry_warning_days: int = 30

    def __post_init__(self) -> None:
        if len(self.api_key) < 16:
            raise ValueError("ASM_API_KEY must contain at least 16 characters")
        if bool(self.admin_username) != bool(self.admin_password):
            raise ValueError("ASM_ADMIN_USERNAME and ASM_ADMIN_PASSWORD must be configured together")
        if self.admin_username and not USERNAME_RE.fullmatch(self.admin_username):
            raise ValueError("ASM_ADMIN_USERNAME must contain 3 to 64 lowercase letters, numbers, '.', '_' or '-'")
        if self.admin_password and not 12 <= len(self.admin_password) <= 256:
            raise ValueError("ASM_ADMIN_PASSWORD must contain between 12 and 256 characters")
        if not self.allowed_networks:
            raise ValueError("At least one ASM_ALLOWED_NETWORKS entry is required")
        if self.max_pending_scans < self.max_concurrent_scans:
            raise ValueError("ASM_MAX_PENDING_SCANS must be greater than or equal to ASM_MAX_CONCURRENT_SCANS")
        if self.max_pending_discoveries < self.max_concurrent_discoveries:
            raise ValueError(
                "ASM_MAX_PENDING_DISCOVERIES must be greater than or equal to ASM_MAX_CONCURRENT_DISCOVERIES"
            )
        if not self.frame_ancestors:
            raise ValueError("ASM_FRAME_ANCESTORS cannot be empty")
        normalized_ancestors = tuple(_normalize_frame_ancestor(item) for item in self.frame_ancestors)
        if "'none'" in normalized_ancestors and len(normalized_ancestors) != 1:
            raise ValueError("ASM_FRAME_ANCESTORS 'none' cannot be combined with another source")
        object.__setattr__(self, "frame_ancestors", normalized_ancestors)

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "Settings":
        return cls(
            database_path=Path(_getenv(env, "ASM_DATABASE_PATH", "data/asm_guardian.db")),
            api_key=_getenv(env, "ASM_API_KEY"),
            admin_username=_getenv(env, "ASM_ADMIN_USERNAME"),
            admin_password=_getenv(env, "ASM_ADMIN_PASSWORD"),
            session_ttl_minutes=_int("ASM_SESSION_TTL_MINUTES", 480, 15, 10_080, env),
            session_cookie_secure=_bool("ASM_SESSION_COOKIE_SECURE", False, env),
            login_rate_limit=_int("ASM_LOGIN_RATE_LIMIT", 5, 1, 100, env),
            allowed_networks=_csv("ASM_ALLOWED_NETWORKS", "127.0.0.0/8,::1/128", env),
            allowed_hosts=_csv("ASM_ALLOWED_HOSTS", env=env),
            cors_origins=_csv("ASM_CORS_ORIGINS", env=env),
            frame_ancestors=_csv("ASM_FRAME_ANCESTORS", "'self'", env),
            request_rate_limit=_int("ASM_REQUEST_RATE_LIMIT", 120, 10, 10_000, env),
            scan_rate_limit=_int("ASM_SCAN_RATE_LIMIT", 6, 1, 100, env),
            max_concurrent_scans=_int("ASM_MAX_CONCURRENT_SCANS", 2, 1, 8, env),
            max_pending_scans=_int("ASM_MAX_PENDING_SCANS", 16, 1, 256, env),
            scheduler_poll_seconds=_int("ASM_SCHEDULER_POLL_SECONDS", 15, 5, 300, env),
            nmap_binary=_getenv(env, "ASM_NMAP_BINARY", "nmap"),
            nmap_max_rate=_int("ASM_NMAP_MAX_RATE", 50, 1, 1_000, env),
            nmap_timeout_seconds=_int("ASM_NMAP_TIMEOUT_SECONDS", 3600, 30, 14_400, env),
            gobuster_binary=_getenv(env, "ASM_GOBUSTER_BINARY", "gobuster"),
            gobuster_wordlist=(
                Path(value) if (value := _getenv(env, "ASM_GOBUSTER_WORDLIST").strip()) else None
            ),
            gobuster_threads=_int("ASM_GOBUSTER_THREADS", 5, 1, 10, env),
            gobuster_timeout_seconds=_int("ASM_GOBUSTER_TIMEOUT_SECONDS", 300, 30, 1_800, env),
            subfinder_binary=_getenv(env, "ASM_SUBFINDER_BINARY", "subfinder"),
            subfinder_rate_limit=_int("ASM_SUBFINDER_RATE_LIMIT", 10, 1, 50, env),
            subfinder_timeout_seconds=_int("ASM_SUBFINDER_TIMEOUT_SECONDS", 300, 30, 1_800, env),
            discovery_rate_limit=_int("ASM_DISCOVERY_RATE_LIMIT", 2, 1, 20, env),
            max_concurrent_discoveries=_int("ASM_MAX_CONCURRENT_DISCOVERIES", 1, 1, 2, env),
            max_pending_discoveries=_int("ASM_MAX_PENDING_DISCOVERIES", 4, 1, 16, env),
            web_probe_rate_limit=_int("ASM_WEB_PROBE_RATE_LIMIT", 6, 1, 60, env),
            web_probe_timeout_seconds=_int("ASM_WEB_PROBE_TIMEOUT_SECONDS", 5, 1, 30, env),
            web_probe_max_response_bytes=_int(
                "ASM_WEB_PROBE_MAX_RESPONSE_BYTES", 65_536, 4_096, 262_144, env
            ),
            web_probe_max_addresses=_int("ASM_WEB_PROBE_MAX_ADDRESSES", 4, 1, 8, env),
            max_concurrent_web_probes=_int("ASM_MAX_CONCURRENT_WEB_PROBES", 2, 1, 8, env),
            tls_expiry_warning_days=_int("ASM_TLS_EXPIRY_WARNING_DAYS", 30, 1, 180, env),
        )


DEFAULT_PORTS: tuple[int, ...] = (
    21,
    22,
    25,
    53,
    80,
    110,
    143,
    443,
    445,
    587,
    993,
    995,
    1433,
    1521,
    3306,
    3389,
    5432,
    6379,
    8080,
    8443,
)
