"""ASM Guardian - defensive attack surface monitoring."""

__version__ = "1.9.1"
