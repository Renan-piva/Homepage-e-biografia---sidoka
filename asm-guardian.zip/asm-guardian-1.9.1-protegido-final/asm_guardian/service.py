from __future__ import annotations

import asyncio
import logging
from collections.abc import Callable
from typing import Any, Protocol

from .database import DEFAULT_TENANT_ID, Database, iso
from .discovery import DiscoveryOutput
from .scanner import NmapRunner
from .security import ScopePolicy


logger = logging.getLogger("asm_guardian")


class DiscoveryRunner(Protocol):
    def run(self, domain: str) -> DiscoveryOutput: ...


class ScanCapacityError(RuntimeError):
    """Raised when accepting another scan would exceed the bounded backlog."""


class DiscoveryCapacityError(RuntimeError):
    """Raised when accepting another discovery would exceed the bounded backlog."""


class DiscoveryService:
    def __init__(
        self,
        database: Database,
        policy_for_tenant: Callable[[str], ScopePolicy],
        runners: dict[str, DiscoveryRunner],
        max_concurrent: int = 1,
        max_pending: int = 4,
    ) -> None:
        self.database = database
        self.policy_for_tenant = policy_for_tenant
        self.runners = runners
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.max_pending = max_pending
        self.tasks: set[asyncio.Task[Any]] = set()

    async def stop(self) -> None:
        for task in tuple(self.tasks):
            task.cancel()
        await asyncio.gather(*tuple(self.tasks), return_exceptions=True)

    async def submit(
        self,
        domain: str,
        engine: str = "gobuster",
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict:
        if len(self.tasks) >= self.max_pending:
            raise DiscoveryCapacityError("DNS discovery capacity is temporarily exhausted")
        authorized = self.policy_for_tenant(tenant_id).authorize_discovery_domain(domain)
        if engine not in self.runners:
            raise ValueError("Unsupported discovery engine")
        if len(self.tasks) >= self.max_pending:
            raise DiscoveryCapacityError("DNS discovery capacity is temporarily exhausted")
        discovery = self.database.create_discovery(authorized, engine, tenant_id)
        task = asyncio.create_task(
            self._execute(discovery["id"], tenant_id), name=f"discovery-{discovery['id']}"
        )
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        return discovery

    async def _execute(self, discovery_id: str, tenant_id: str) -> None:
        try:
            async with self.semaphore:
                discovery = self.database.get_discovery(discovery_id, tenant_id)
                if discovery is None or discovery["status"] == "cancelled":
                    return
                self.database.mark_discovery_running(discovery_id)
                runner = self.runners[discovery["engine"]]
                output = await asyncio.to_thread(runner.run, discovery["domain"])
                self.database.complete_discovery(discovery_id, output.hostnames)
        except asyncio.CancelledError:
            self.database.fail_discovery(discovery_id, "Discovery cancelled during application shutdown")
            raise
        except Exception as exc:  # noqa: BLE001 - boundary records a controlled failure
            logger.warning("discovery_failed", extra={"discovery_id": discovery_id, "error_type": type(exc).__name__})
            self.database.fail_discovery(discovery_id, str(exc) or type(exc).__name__)

    def cancel(self, discovery_id: str, tenant_id: str) -> dict | None:
        return self.database.cancel_discovery(discovery_id, tenant_id)


class ScanService:
    def __init__(
        self,
        database: Database,
        policy_for_tenant: Callable[[str], ScopePolicy],
        runner: NmapRunner,
        max_concurrent: int = 2,
        max_pending: int = 16,
        scheduler_poll_seconds: int = 15,
    ) -> None:
        self.database = database
        self.policy_for_tenant = policy_for_tenant
        self.runner = runner
        self.semaphore = asyncio.Semaphore(max_concurrent)
        self.max_pending = max_pending
        self.scheduler_poll_seconds = scheduler_poll_seconds
        self.tasks: set[asyncio.Task[Any]] = set()
        self.scheduler_task: asyncio.Task[None] | None = None

    def start(self) -> None:
        self.scheduler_task = asyncio.create_task(self._scheduler_loop(), name="monitor-scheduler")

    async def stop(self) -> None:
        if self.scheduler_task:
            self.scheduler_task.cancel()
        for task in tuple(self.tasks):
            task.cancel()
        await asyncio.gather(
            *(tuple(self.tasks) + ((self.scheduler_task,) if self.scheduler_task else ())),
            return_exceptions=True,
        )

    async def submit(
        self,
        target: str,
        ports: tuple[int, ...],
        service_detection: bool,
        port_profile: str = "custom",
        monitor_id: str | None = None,
        tenant_id: str = DEFAULT_TENANT_ID,
    ) -> dict:
        if len(self.tasks) >= self.max_pending:
            raise ScanCapacityError("Scan capacity is temporarily exhausted")
        resolved = await asyncio.to_thread(self.policy_for_tenant(tenant_id).resolve_target, target)
        if len(self.tasks) >= self.max_pending:
            raise ScanCapacityError("Scan capacity is temporarily exhausted")
        scan = self.database.create_scan(
            resolved.requested,
            resolved.addresses,
            ports,
            service_detection,
            monitor_id,
            port_profile,
            tenant_id,
        )
        task = asyncio.create_task(self._execute(scan["id"], tenant_id), name=f"scan-{scan['id']}")
        self.tasks.add(task)
        task.add_done_callback(self.tasks.discard)
        return scan

    async def _execute(self, scan_id: str, tenant_id: str) -> None:
        try:
            async with self.semaphore:
                scan = self.database.get_scan(scan_id, tenant_id)
                if scan is None or scan["status"] == "cancelled":
                    return
                self.database.mark_scan_running(scan_id)
                output = await asyncio.to_thread(
                    self.runner.run,
                    tuple(scan["resolved_targets"]),
                    tuple(scan["ports"]),
                    scan["service_detection"],
                    scan["port_profile"],
                )
                self.database.complete_scan(scan_id, output.hosts, output.findings)
        except asyncio.CancelledError:
            self.database.fail_scan(scan_id, "Scan cancelled during application shutdown")
            raise
        except Exception as exc:  # noqa: BLE001 - boundary records a controlled failure
            logger.warning("scan_failed", extra={"scan_id": scan_id, "error_type": type(exc).__name__})
            self.database.fail_scan(scan_id, str(exc) or type(exc).__name__)

    def cancel(self, scan_id: str, tenant_id: str) -> dict | None:
        return self.database.cancel_scan(scan_id, tenant_id)

    async def _scheduler_loop(self) -> None:
        while True:
            try:
                for monitor in self.database.due_monitors(iso()):
                    self.database.mark_monitor_scheduled(monitor["id"], monitor["interval_minutes"])
                    try:
                        await self.submit(
                            monitor["target"],
                            tuple(monitor["ports"]),
                            monitor["service_detection"],
                            monitor["port_profile"],
                            monitor["id"],
                            monitor["tenant_id"],
                        )
                    except Exception as exc:  # noqa: BLE001 - scheduler must survive bad entries
                        self.database.set_monitor_error(monitor["id"], str(exc) or type(exc).__name__)
                await asyncio.sleep(self.scheduler_poll_seconds)
            except asyncio.CancelledError:
                raise
            except Exception:  # noqa: BLE001 - keep monitor engine alive and log internals
                logger.exception("monitor_scheduler_error")
                await asyncio.sleep(self.scheduler_poll_seconds)
