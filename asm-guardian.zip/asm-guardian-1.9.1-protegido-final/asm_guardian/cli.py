from __future__ import annotations

import argparse
import os
import re
import shutil
import sqlite3
import subprocess
import sys
from collections.abc import Mapping, Sequence
from pathlib import Path

from .config import Settings
from .discovery import BUNDLED_WORDLIST, GobusterRunner
from .security import ScopePolicy


ENV_NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")


def load_env_file(path: Path) -> dict[str, str]:
    """Read the simple KEY=VALUE format used by the systemd EnvironmentFile."""
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise ValueError(f"cannot read environment file: {path}") from exc

    values: dict[str, str] = {}
    for line_number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if not line or line.startswith(("#", ";")):
            continue
        if "=" not in line:
            raise ValueError(f"invalid environment entry on line {line_number}")
        name, raw_value = line.split("=", 1)
        name = name.strip()
        if not ENV_NAME.fullmatch(name):
            raise ValueError(f"invalid environment name on line {line_number}")
        value = raw_value.strip()
        if value.startswith(("'", '"')):
            quote = value[0]
            if len(value) < 2 or value[-1] != quote:
                raise ValueError(f"invalid quoting on line {line_number}")
            value = value[1:-1]
            if quote == '"':
                value = value.replace(r'\"', '"').replace("\\\\", "\\")
        values[name] = value
    return values


def check_configuration(env_file: Path, base_env: Mapping[str, str] | None = None) -> tuple[str, ...]:
    environment = dict(os.environ if base_env is None else base_env)
    environment.update(load_env_file(env_file))

    settings = Settings.from_env(environment)
    if not settings.admin_username:
        raise ValueError("ASM_ADMIN_USERNAME and ASM_ADMIN_PASSWORD are required for browser login")
    ScopePolicy(settings.allowed_networks, settings.allowed_hosts)

    database_parent = settings.database_path.expanduser().resolve(strict=False).parent
    if not database_parent.is_dir():
        raise ValueError(f"database directory does not exist: {database_parent}")
    if not os.access(database_parent, os.R_OK | os.W_OK | os.X_OK):
        raise ValueError(f"database directory is not accessible: {database_parent}")
    if settings.database_path.exists() and not settings.database_path.is_file():
        raise ValueError(f"database path is not a regular file: {settings.database_path}")

    executable = shutil.which(settings.nmap_binary, path=environment.get("PATH"))
    if executable is None:
        raise ValueError("Nmap is not installed or ASM_NMAP_BINARY is invalid")
    try:
        result = subprocess.run(
            [executable, "--version"],
            shell=False,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise ValueError("Nmap could not be executed") from exc
    if result.returncode != 0:
        raise ValueError(f"Nmap version check failed with status {result.returncode}")

    gobuster = shutil.which(settings.gobuster_binary, path=environment.get("PATH"))
    if gobuster is None:
        raise ValueError("Gobuster is not installed or ASM_GOBUSTER_BINARY is invalid")
    wordlist = settings.gobuster_wordlist or BUNDLED_WORDLIST
    try:
        validated_wordlist = GobusterRunner(
            settings.gobuster_binary,
            wordlist,
            settings.gobuster_threads,
            settings.gobuster_timeout_seconds,
        ).validate_wordlist()
    except (ValueError, RuntimeError) as exc:
        raise ValueError(str(exc)) from exc

    subfinder = shutil.which(settings.subfinder_binary, path=environment.get("PATH"))
    subfinder_status = subfinder or "not installed (optional; passive DNS discovery unavailable)"

    return (
        f"environment file: {env_file}",
        f"password login: {settings.admin_username}",
        f"allowlist: {len(settings.allowed_networks)} network(s), {len(settings.allowed_hosts)} hostname rule(s)",
        f"database directory: {database_parent}",
        f"Nmap executable: {executable}",
        f"Gobuster executable: {gobuster}",
        f"Subfinder executable: {subfinder_status}",
        f"DNS discovery wordlist: {validated_wordlist}",
    )


def backup_database(
    env_file: Path,
    output: Path,
    base_env: Mapping[str, str] | None = None,
) -> Path:
    environment = dict(os.environ if base_env is None else base_env)
    environment.update(load_env_file(env_file))
    settings = Settings.from_env(environment)
    source_path = settings.database_path.expanduser().resolve(strict=False)
    destination_path = output.expanduser().resolve(strict=False)
    if not source_path.is_file():
        raise ValueError(f"database file does not exist: {source_path}")
    if destination_path.exists():
        raise ValueError(f"backup destination already exists: {destination_path}")
    if not destination_path.parent.is_dir():
        raise ValueError(f"backup directory does not exist: {destination_path.parent}")
    if source_path == destination_path:
        raise ValueError("backup destination must differ from the database path")
    try:
        with sqlite3.connect(source_path) as source, sqlite3.connect(destination_path) as destination:
            source.backup(destination)
        destination_path.chmod(0o600)
    except (OSError, sqlite3.Error) as exc:
        try:
            if destination_path.exists():
                destination_path.unlink()
        except OSError:
            pass
        raise ValueError(f"database backup failed: {exc}") from exc
    return destination_path


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="asm-guardian")
    parser.add_argument("--env-file", type=Path, required=True, help="systemd-style environment file")
    subcommands = parser.add_subparsers(dest="command", required=True)
    subcommands.add_parser("check", help="validate configuration and local dependencies without scanning")
    backup = subcommands.add_parser("backup", help="create a consistent SQLite backup without stopping the service")
    backup.add_argument("--output", type=Path, required=True, help="new backup file; existing files are never replaced")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    arguments = build_parser().parse_args(argv)
    if arguments.command == "check":
        try:
            results = check_configuration(arguments.env_file)
        except ValueError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        for result in results:
            print(f"OK: {result}")
        print("ASM Guardian check completed successfully.")
        return 0
    if arguments.command == "backup":
        try:
            result = backup_database(arguments.env_file, arguments.output)
        except ValueError as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1
        print(f"OK: database backup created: {result}")
        return 0
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
