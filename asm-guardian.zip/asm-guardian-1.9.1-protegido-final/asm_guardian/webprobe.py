from __future__ import annotations

import html
import ipaddress
import re
import socket
import ssl
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


MAX_HEADER_BYTES = 16_384
STATUS_LINE_RE = re.compile(rb"^HTTP/\d(?:\.\d)?\s+(\d{3})(?:\s|$)")
TITLE_RE = re.compile(rb"<title\b[^>]*>(.*?)</title\s*>", re.IGNORECASE | re.DOTALL)
SPACE_RE = re.compile(r"\s+")


@dataclass(frozen=True, slots=True)
class WebProbeOutput:
    observations: tuple[dict[str, Any], ...]


def parse_http_response(data: bytes) -> dict[str, Any]:
    header_blob, separator, body = data.partition(b"\r\n\r\n")
    if not separator or len(header_blob) > MAX_HEADER_BYTES:
        raise ValueError("HTTP response headers are missing or exceed 16 KiB")
    lines = header_blob.split(b"\r\n")
    match = STATUS_LINE_RE.match(lines[0]) if lines else None
    if match is None:
        raise ValueError("HTTP response status line is invalid")

    headers: dict[str, str] = {}
    for raw_line in lines[1:]:
        name, delimiter, raw_value = raw_line.partition(b":")
        if not delimiter or not name or any(byte <= 32 or byte >= 127 for byte in name):
            continue
        normalized_name = name.decode("ascii").strip().lower()
        headers.setdefault(normalized_name, raw_value.decode("latin-1", errors="replace").strip())

    title = ""
    title_match = TITLE_RE.search(body)
    if title_match is not None:
        decoded = title_match.group(1).decode("utf-8", errors="replace")
        title = SPACE_RE.sub(" ", html.unescape(decoded)).strip()[:200]

    return {
        "status_code": int(match.group(1)),
        "title": title,
        "server": headers.get("server", "")[:200],
        "content_type": headers.get("content-type", "")[:200],
        "location": headers.get("location", "")[:500],
    }


def _certificate_value(certificate: dict[str, Any], field: str) -> str:
    for relative_name in certificate.get(field, ()):
        for name, value in relative_name:
            if name == "commonName":
                return str(value)[:253]
    return ""


def _host_header(target: str, port: int, scheme: str) -> str:
    try:
        address = ipaddress.ip_address(target)
        host = f"[{address.compressed}]" if address.version == 6 else address.compressed
    except ValueError:
        host = target
    default_port = 443 if scheme == "https" else 80
    return host if port == default_port else f"{host}:{port}"


class WebProbeRunner:
    def __init__(self, timeout_seconds: int = 5, max_response_bytes: int = 65_536) -> None:
        if not 1 <= timeout_seconds <= 30:
            raise ValueError("Web probe timeout must be between 1 and 30 seconds")
        if not 4_096 <= max_response_bytes <= 262_144:
            raise ValueError("Web probe response limit must be between 4096 and 262144 bytes")
        self.timeout_seconds = timeout_seconds
        self.max_response_bytes = max_response_bytes

    def run(self, target: str, addresses: tuple[str, ...]) -> WebProbeOutput:
        observations = tuple(
            self._probe(target, address, scheme, port)
            for address in addresses
            for scheme, port in (("https", 443), ("http", 80))
        )
        return WebProbeOutput(observations)

    def _probe(self, target: str, address: str, scheme: str, port: int) -> dict[str, Any]:
        observation: dict[str, Any] = {
            "ip": address,
            "scheme": scheme,
            "port": port,
            "status_code": None,
            "title": "",
            "server": "",
            "content_type": "",
            "location": "",
            "tls_subject": "",
            "tls_issuer": "",
            "tls_not_after": None,
            "tls_days_remaining": None,
            "error": "",
        }
        connection: socket.socket | ssl.SSLSocket | None = None
        try:
            connection = socket.create_connection((address, port), timeout=self.timeout_seconds)
            connection.settimeout(self.timeout_seconds)
            if scheme == "https":
                context = ssl.create_default_context()
                connection = context.wrap_socket(connection, server_hostname=target)
                certificate = connection.getpeercert()
                observation["tls_subject"] = _certificate_value(certificate, "subject")
                observation["tls_issuer"] = _certificate_value(certificate, "issuer")
                if not_after := certificate.get("notAfter"):
                    expires_at = datetime.fromtimestamp(ssl.cert_time_to_seconds(not_after), UTC)
                    observation["tls_not_after"] = expires_at.isoformat(timespec="seconds")
                    remaining = (expires_at - datetime.now(UTC)).total_seconds()
                    observation["tls_days_remaining"] = int(remaining // 86_400)

            request = (
                "GET / HTTP/1.1\r\n"
                f"Host: {_host_header(target, port, scheme)}\r\n"
                "User-Agent: ASM-Guardian/1.5\r\n"
                "Accept: text/html,application/xhtml+xml;q=0.9,*/*;q=0.1\r\n"
                "Accept-Encoding: identity\r\n"
                "Connection: close\r\n\r\n"
            ).encode("ascii")
            connection.sendall(request)
            response = bytearray()
            while len(response) < self.max_response_bytes:
                chunk = connection.recv(min(8_192, self.max_response_bytes - len(response)))
                if not chunk:
                    break
                response.extend(chunk)
            observation.update(parse_http_response(bytes(response)))
        except (OSError, ssl.SSLError, ValueError) as exc:
            observation["error"] = f"{type(exc).__name__}: {str(exc)[:260]}"
        finally:
            if connection is not None:
                try:
                    connection.close()
                except OSError:
                    pass
        return observation
