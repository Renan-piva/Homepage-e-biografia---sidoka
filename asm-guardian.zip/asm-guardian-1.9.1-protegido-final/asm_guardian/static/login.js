"use strict";

const form = document.getElementById("login-form");
const button = document.getElementById("login-button");
const notice = document.getElementById("login-notice");
const username = document.getElementById("username");
const password = document.getElementById("password");

function showNotice(message, kind = "") {
  notice.textContent = message;
  notice.className = `login-notice${kind ? ` ${kind}` : ""}`;
}

const pendingMessage = sessionStorage.getItem("asm-login-message");
sessionStorage.removeItem("asm-login-message");
sessionStorage.removeItem("asm-csrf-token");
if (pendingMessage) showNotice(pendingMessage, "info");

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  button.disabled = true;
  button.querySelector("span").textContent = "Validando acesso...";
  showNotice("Validando credenciais e escopo da conta.", "info");

  try {
    const response = await fetch("/api/v1/auth/login", {
      method: "POST",
      credentials: "same-origin",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: username.value.trim(),
        password: password.value,
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        throw new Error("Muitas tentativas. Aguarde um minuto antes de tentar novamente.");
      }
      throw new Error("Usuário ou senha inválidos.");
    }

    const session = await response.json();
    sessionStorage.setItem("asm-csrf-token", session.csrf_token);
    password.value = "";
    showNotice("Acesso confirmado. Abrindo o ambiente...", "success");
    window.location.replace("/");
  } catch (error) {
    password.value = "";
    password.focus();
    showNotice(error.message, "error");
    button.disabled = false;
    button.querySelector("span").textContent = "Entrar no painel";
  }
});
