const CSRF_COOKIE_NAME = "asm_guardian_csrf";

function csrfFromCookie() {
  const prefix = `${CSRF_COOKIE_NAME}=`;
  const item = document.cookie.split("; ").find((value) => value.startsWith(prefix));
  return item ? decodeURIComponent(item.slice(prefix.length)) : "";
}

const state = {
  csrfToken: csrfFromCookie() || sessionStorage.getItem("asm-csrf-token") || "",
  session: null,
  assets: [],
  portCategory: "all",
  loading: false,
  snapshots: Object.create(null),
};
const AUTO_REFRESH_MS = 60000;
const API_TIMEOUT_MS = 15000;
const MUTATION_TIMEOUT_MS = 120000;
const MAX_PORT_CHIPS_PER_ASSET = 24;
const MAX_ASSET_MAP_CARDS = 60;
const MAX_ASSET_TABLE_ROWS = 100;
const MAX_SECONDARY_TABLE_ROWS = 100;
const FILTER_DEBOUNCE_MS = 150;
let refreshTimer = null;
let filterTimer = null;
const $ = (id) => document.getElementById(id);
const roleNames = { viewer: "Leitura", operator: "Operação", admin: "Administração" };
const profileNames = { custom: "personalizado", "top-1000": "top 1.000", "all-tcp": "todas as portas TCP" };
const statusNames = { queued: "na fila", running: "executando", completed: "concluído", failed: "falhou" };
statusNames.cancelled = "cancelado";
statusNames.active = "ativa";
statusNames.revoked = "encerrada";
statusNames.expired = "expirada";
const portCategories = [
  { id: "remote", label: "Acesso remoto", ports: new Set([22, 23, 3389, 5900, 5985, 5986]) },
  { id: "web", label: "Web", ports: new Set([80, 443, 8000, 8080, 8081, 8443, 8888]) },
  { id: "data", label: "Dados", ports: new Set([1433, 1521, 27017, 3306, 5432, 6379, 9042, 9200]) },
  { id: "mail", label: "Mensageria", ports: new Set([25, 110, 143, 465, 587, 993, 995]) },
];
const categoryLabels = {
  remote: "Acesso remoto",
  web: "Web",
  data: "Dados",
  mail: "Mensageria",
  other: "Outras",
};
const categoryWeights = { remote: 4, data: 3, mail: 2, web: 1, other: 1 };

function notify(message, kind = "") {
  $("notice").textContent = message;
  $("notice").className = `notice ${kind}`;
}

function dataChanged(key, value) {
  const signature = JSON.stringify(value);
  if (state.snapshots[key] === signature) return false;
  state.snapshots[key] = signature;
  return true;
}

function cell(text) {
  const td = document.createElement("td");
  td.textContent = text;
  return td;
}

function emptyRow(message, columns) {
  const row = document.createElement("tr");
  const item = cell(message);
  item.colSpan = columns;
  item.className = "empty";
  row.append(item);
  return row;
}

function clearData() {
  state.assets = [];
  state.portCategory = "all";
  for (const id of ["stat-assets", "stat-ports", "stat-scans", "stat-discoveries", "stat-alerts", "stat-monitors"]) {
    $(id).textContent = "-";
  }
  $("assets-body").replaceChildren(emptyRow("Nenhum dado carregado.", 8));
  $("discovered-hosts-body").replaceChildren(emptyRow("Nenhum host carregado.", 4));
  $("web-observations-body").replaceChildren(emptyRow("Nenhum serviço web observado.", 6));
  $("open-port-map").replaceChildren();
  const noPorts = document.createElement("p");
  noPorts.className = "empty";
  noPorts.textContent = "Nenhuma porta aberta observada.";
  $("open-port-map").append(noPorts);
  $("exposure-leader").textContent = "-";
  $("exposure-leader-detail").textContent = "Nenhuma porta observada";
  $("environment-posture").textContent = "Aguardando dados";
  $("posture-copy").textContent = "Conecte-se para consolidar exposição, atividade e mudanças recentes.";
  $("exposure-command-center").dataset.state = "empty";
  for (const id of ["posture-active", "posture-failed", "posture-web", "posture-alerts"]) $(id).textContent = "-";
  for (const id of ["category-spectrum", "priority-assets"]) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = id === "category-spectrum" ? "Nenhuma distribuição carregada." : "Nenhum ativo carregado.";
    $(id).replaceChildren(empty);
  }
  updatePortFilters([]);
  for (const id of ["scans", "monitors", "alerts", "discovery-history"]) $(id).replaceChildren();
  $("alert-counter").textContent = "0";
  $("session").hidden = true;
}

function classifyPort(port) {
  return portCategories.find((category) => category.ports.has(Number(port))) || {
    id: "other",
    label: "Outra",
  };
}

function exposureGroups(assets) {
  const groups = new Map();
  for (const asset of assets) {
    const key = `${asset.ip}|${asset.hostname || ""}`;
    if (!groups.has(key)) {
      groups.set(key, {
        ip: asset.ip,
        hostname: asset.hostname || "",
        ports: [],
        categories: { remote: 0, web: 0, data: 0, mail: 0, other: 0 },
        score: 0,
        observedAt: asset.observed_at,
      });
    }
    const group = groups.get(key);
    const category = classifyPort(asset.port).id;
    group.ports.push(asset);
    group.categories[category] += 1;
    group.score += categoryWeights[category];
    if (Date.parse(asset.observed_at) > Date.parse(group.observedAt)) group.observedAt = asset.observed_at;
  }
  return [...groups.values()];
}

function updatePortFilters(assets) {
  const counts = { all: assets.length, remote: 0, web: 0, data: 0, mail: 0, other: 0 };
  for (const asset of assets) counts[classifyPort(asset.port).id] += 1;
  for (const [category, count] of Object.entries(counts)) {
    const target = $(`filter-${category}-count`);
    if (target) target.textContent = String(count);
  }
  for (const button of $("port-filters").querySelectorAll("button[data-category]")) {
    button.setAttribute("aria-pressed", String(button.dataset.category === state.portCategory));
  }
}

function setPortCategory(category) {
  if (!["all", "remote", "web", "data", "mail", "other"].includes(category)) return;
  state.portCategory = category;
  updatePortFilters(state.assets);
  renderFilteredAssets();
}

function renderCategorySpectrum(assets) {
  const root = $("category-spectrum");
  root.replaceChildren();
  updatePortFilters(assets);
  if (!assets.length) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "Nenhuma distribuição de portas disponível.";
    root.append(empty);
    return;
  }
  const counts = { remote: 0, web: 0, data: 0, mail: 0, other: 0 };
  for (const asset of assets) counts[classifyPort(asset.port).id] += 1;
  const maximum = Math.max(...Object.values(counts), 1);
  for (const category of ["remote", "web", "data", "mail", "other"]) {
    const item = document.createElement("div");
    item.className = `spectrum-item ${category}`;
    const label = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = categoryLabels[category];
    const count = document.createElement("small");
    count.textContent = `${counts[category]} porta${counts[category] === 1 ? "" : "s"}`;
    label.append(name, count);
    const track = document.createElement("span");
    track.className = "spectrum-track";
    const bar = document.createElement("i");
    bar.className = "spectrum-bar";
    bar.style.setProperty("--share", `${Math.round((counts[category] / maximum) * 100)}%`);
    track.append(bar);
    item.append(label, track);
    root.append(item);
  }
}

function renderPriorityAssets(assets) {
  const root = $("priority-assets");
  root.replaceChildren();
  const groups = exposureGroups(assets).sort((left, right) =>
    right.score - left.score || right.ports.length - left.ports.length || left.ip.localeCompare(right.ip)
  );
  if (!groups.length) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "Nenhum ativo com portas abertas observado.";
    root.append(empty);
    return;
  }
  for (const [index, group] of groups.slice(0, 5).entries()) {
    const categories = Object.entries(group.categories).filter(([, count]) => count > 0);
    const primary = categories.sort((left, right) =>
      categoryWeights[right[0]] * right[1] - categoryWeights[left[0]] * left[1]
    )[0][0];
    const card = document.createElement("article");
    card.className = `priority-asset ${primary}`;
    const rank = document.createElement("span");
    rank.className = "priority-rank";
    rank.textContent = String(index + 1).padStart(2, "0");
    const identity = document.createElement("div");
    const name = document.createElement("strong");
    name.textContent = group.hostname || group.ip;
    const details = document.createElement("small");
    details.textContent = `${group.ip} · ${group.ports.length} porta${group.ports.length === 1 ? "" : "s"} · ${new Date(group.observedAt).toLocaleString()}`;
    identity.append(name, details);
    const signal = document.createElement("span");
    signal.className = "priority-signal";
    signal.textContent = primary === "remote"
      ? "Revisar acesso remoto"
      : primary === "data" ? "Revisar serviço de dados" : `Revisar ${categoryLabels[primary].toLowerCase()}`;
    card.append(rank, identity, signal);
    root.append(card);
  }
}

function renderExposureCockpit(overview, assets) {
  $("posture-active").textContent = String(overview.active_scans);
  $("posture-failed").textContent = String(overview.failed_scans);
  $("posture-web").textContent = String(overview.web_endpoints);
  $("posture-alerts").textContent = String(overview.unacknowledged_alerts);
  const cockpit = $("exposure-command-center");
  let stateName = "quiet";
  let title = "Superfície acompanhada";
  let copy = `${overview.assets} ativo(s), ${overview.open_ports} porta(s) e ${overview.web_endpoints} endpoint(s) Web/TLS observados.`;
  if (!assets.length) {
    stateName = "empty";
    title = "Sem linha de base";
    copy = "Execute uma varredura autorizada para iniciar o inventário observável.";
  } else if (overview.unacknowledged_alerts > 0 || overview.failed_scans > 0) {
    stateName = "attention";
    title = "Revisão necessária";
    copy = `${overview.unacknowledged_alerts} alerta(s) pendente(s) e ${overview.failed_scans} varredura(s) com falha exigem triagem operacional.`;
  } else if (overview.active_scans > 0) {
    stateName = "active";
    title = "Observação em curso";
    copy = `${overview.active_scans} varredura(s) em execução ou na fila. Os dados serão consolidados automaticamente.`;
  }
  cockpit.dataset.state = stateName;
  $("environment-posture").textContent = title;
  $("posture-copy").textContent = copy;
  renderCategorySpectrum(assets);
  renderPriorityAssets(assets);
}

function renderOpenPortMap(assets) {
  const root = $("open-port-map");
  const ordered = exposureGroups(assets).sort((left, right) =>
    right.ports.length - left.ports.length || left.ip.localeCompare(right.ip)
  );
  if (!ordered.length) {
    const empty = document.createElement("p");
    empty.className = "empty";
    empty.textContent = "Nenhuma porta aberta observada.";
    root.replaceChildren(empty);
    $("exposure-leader").textContent = "—";
    $("exposure-leader-detail").textContent = "Nenhuma porta observada";
    return;
  }

  const leader = ordered[0];
  $("exposure-leader").textContent = leader.hostname || leader.ip;
  $("exposure-leader-detail").textContent = `${leader.ports.length} porta${leader.ports.length === 1 ? "" : "s"} aberta${leader.ports.length === 1 ? "" : "s"} · ${leader.ip}`;

  const fragment = document.createDocumentFragment();
  for (const group of ordered.slice(0, MAX_ASSET_MAP_CARDS)) {
    const card = document.createElement("article");
    const activeCategories = Object.entries(group.categories).filter(([, count]) => count > 0);
    const primaryCategory = activeCategories.sort((left, right) =>
      categoryWeights[right[0]] * right[1] - categoryWeights[left[0]] * left[1]
    )[0][0];
    card.className = `asset-port-card focus-${primaryCategory}`;
    const header = document.createElement("header");
    const identity = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = group.hostname || group.ip;
    const address = document.createElement("small");
    address.textContent = group.hostname ? group.ip : "Endereço observado";
    identity.append(title, address);
    const count = document.createElement("span");
    count.className = "open-count";
    count.textContent = `${group.ports.length} aberta${group.ports.length === 1 ? "" : "s"}`;
    header.append(identity, count);

    const metadata = document.createElement("div");
    metadata.className = "asset-port-metadata";
    const categoryText = document.createElement("span");
    categoryText.textContent = activeCategories.map(([category, total]) => `${categoryLabels[category]} ${total}`).join(" · ");
    const observed = document.createElement("small");
    observed.textContent = `Última observação ${new Date(group.observedAt).toLocaleString()}`;
    metadata.append(categoryText, observed);

    const cloud = document.createElement("div");
    cloud.className = "port-cloud";
    const visiblePorts = group.ports
      .sort((left, right) => left.port - right.port)
      .slice(0, MAX_PORT_CHIPS_PER_ASSET);
    for (const asset of visiblePorts) {
      const category = classifyPort(asset.port);
      const chip = document.createElement("span");
      chip.className = `port-chip ${category.id}`;
      chip.title = [category.label, asset.service, asset.product, asset.version].filter(Boolean).join(" · ");
      const number = document.createElement("strong");
      number.textContent = String(asset.port);
      const detail = document.createElement("small");
      detail.textContent = `${asset.protocol.toUpperCase()} · ${asset.service || category.label}`;
      chip.append(number, detail);
      cloud.append(chip);
    }
    if (group.ports.length > visiblePorts.length) {
      const overflow = document.createElement("span");
      overflow.className = "port-chip overflow";
      overflow.textContent = `+${group.ports.length - visiblePorts.length} portas`;
      overflow.title = "Use o detalhamento técnico ou a exportação CSV para consultar todas as portas.";
      cloud.append(overflow);
    }
    card.append(header, metadata, cloud);
    fragment.append(card);
  }
  if (ordered.length > MAX_ASSET_MAP_CARDS) {
    const overflow = document.createElement("p");
    overflow.className = "map-overflow";
    overflow.textContent = `${ordered.length - MAX_ASSET_MAP_CARDS} ativo(s) adicionais disponíveis no detalhamento técnico e na exportação CSV.`;
    fragment.append(overflow);
  }
  root.replaceChildren(fragment);
}

function portCell(asset) {
  const td = document.createElement("td");
  const category = classifyPort(asset.port);
  const badge = document.createElement("span");
  badge.className = `table-port ${category.id}`;
  const number = document.createElement("strong");
  number.textContent = String(asset.port);
  const protocol = document.createElement("small");
  protocol.textContent = asset.protocol.toUpperCase();
  badge.append(number, protocol);
  const label = document.createElement("small");
  label.className = "port-category-label";
  label.textContent = category.label;
  td.append(badge, label);
  return td;
}

function filterAssets(assets, query, category = "all") {
  return assets.filter((asset) => {
    if (category !== "all" && classifyPort(asset.port).id !== category) return false;
    if (!query) return true;
    return [
    asset.hostname,
    asset.ip,
    asset.port,
    asset.protocol,
    asset.service,
    asset.product,
    asset.version,
    asset.display_name,
    asset.owner,
    asset.environment,
    asset.criticality,
    ...(asset.tags || []),
  ].filter((value) => value !== null && value !== undefined)
    .join(" ")
    .toLocaleLowerCase("pt-BR")
    .includes(query);
  });
}

function renderFilteredAssets() {
  const query = $("asset-filter").value.trim().toLocaleLowerCase("pt-BR");
  renderAssets(filterAssets(state.assets, query, state.portCategory), false);
}

function scheduleAssetFilter() {
  if (filterTimer !== null) window.clearTimeout(filterTimer);
  filterTimer = window.setTimeout(() => {
    filterTimer = null;
    renderFilteredAssets();
  }, FILTER_DEBOUNCE_MS);
}

function disconnect(message = "Sessão encerrada. Entre novamente.") {
  state.csrfToken = "";
  state.session = null;
  sessionStorage.removeItem("asm-csrf-token");
  sessionStorage.setItem("asm-login-message", message);
  window.location.replace("/login");
}

function rememberCsrf(csrfToken) {
  state.csrfToken = csrfToken;
  sessionStorage.setItem("asm-csrf-token", csrfToken);
}

async function refreshCsrfToken() {
  const response = await fetch("/api/v1/auth/csrf", {
    method: "POST",
    credentials: "same-origin",
    headers: { "Content-Type": "application/json" },
  });
  if (!response.ok) {
    if (response.status === 401) disconnect("Sessão expirada. Entre novamente.");
    throw new Error("Não foi possível renovar a proteção da sessão.");
  }
  const payload = await response.json();
  rememberCsrf(payload.csrf_token);
  return payload.csrf_token;
}

async function api(path, options = {}) {
  const { _csrfRetried = false, ...requestOptions } = options;
  const method = (requestOptions.method || "GET").toUpperCase();
  const sharedCsrf = csrfFromCookie();
  if (sharedCsrf && sharedCsrf !== state.csrfToken) rememberCsrf(sharedCsrf);
  const headers = { "Content-Type": "application/json", ...(requestOptions.headers || {}) };
  if (!["GET", "HEAD", "OPTIONS"].includes(method) && state.csrfToken) {
    headers["X-CSRF-Token"] = state.csrfToken;
  }
  const controller = new AbortController();
  const timeoutMs = ["GET", "HEAD"].includes(method) ? API_TIMEOUT_MS : MUTATION_TIMEOUT_MS;
  const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
  let response;
  try {
    response = await fetch(path, {
      ...requestOptions,
      credentials: "same-origin",
      headers,
      signal: controller.signal,
    });
  } catch (error) {
    if (error.name === "AbortError") throw new Error("O servidor demorou para responder. Tente atualizar novamente.");
    throw error;
  } finally {
    window.clearTimeout(timeout);
  }
  if (!response.ok) {
    let message = `Erro ${response.status}`;
    try { message = (await response.json()).detail || message; } catch (_) { /* resposta sem JSON */ }
    if (response.status === 401) disconnect("Sessão expirada ou credenciais inválidas. Entre novamente.");
    if (response.status === 403 && message === "Invalid CSRF token" && !_csrfRetried) {
      await refreshCsrfToken();
      return api(path, { ...requestOptions, _csrfRetried: true });
    }
    throw new Error(message);
  }
  if (response.status === 204) return null;
  return response.json();
}

function actionButton(label, action, danger = false) {
  const button = document.createElement("button");
  button.type = "button";
  button.className = danger ? "table-action danger" : "table-action";
  button.textContent = label;
  button.addEventListener("click", action);
  return button;
}

async function copyScanId(scanId) {
  try {
    await navigator.clipboard.writeText(scanId);
    notify(`Scan ID copiado: ${scanId}`, "success");
  } catch (_) {
    notify(`Não foi possível copiar automaticamente. Scan ID: ${scanId}`, "error");
  }
}

function parsePorts(value) {
  const parts = value.split(",").map((item) => item.trim()).filter(Boolean);
  const ports = parts.map(Number);
  if (!ports.length || ports.length > 4096 || ports.some((port) => !Number.isInteger(port) || port < 1 || port > 65535)) {
    throw new Error("Use entre 1 e 4.096 portas válidas, separadas por vírgula.");
  }
  if (new Set(ports).size !== ports.length) throw new Error("A lista contém portas duplicadas.");
  return ports;
}

function portSelection(profileId, portsId) {
  const portProfile = $(profileId).value;
  const value = { port_profile: portProfile };
  if (portProfile === "custom") value.ports = parsePorts($(portsId).value);
  return value;
}

function updateProfile(profileId, wrapId, warningId = null) {
  const allTcp = $(profileId).value === "all-tcp";
  const custom = $(profileId).value === "custom";
  $(wrapId).hidden = !custom;
  $(wrapId).querySelector("input").required = custom;
  if (warningId) {
    $(warningId).textContent = allTcp
      ? "Cobertura completa: pode demorar. Allowlist, taxa e fila continuam obrigatórias."
      : custom ? "O perfil personalizado é o padrão mais rápido." : "O Nmap seleciona as 1.000 portas TCP mais comuns.";
    $(warningId).classList.toggle("warning", allTcp);
  }
}

function renderSession() {
  const root = $("session");
  root.textContent = `${state.session.tenant.name} • ${state.session.name} • ${roleNames[state.session.role]} • sessão protegida`;
  root.hidden = false;
  $("change-password").hidden = state.session.kind !== "user";
  $("manage-sessions").hidden = state.session.kind !== "user";
  const canOperate = state.session.role !== "viewer";
  for (const formId of ["scan-form", "monitor-form", "discovery-form", "web-probe-form"]) {
    for (const control of $(formId).elements) control.disabled = !canOperate;
  }
}

const environmentNames = {
  unknown: "Não definido",
  development: "Desenvolvimento",
  test: "Teste",
  staging: "Homologação",
  production: "Produção",
};
const riskNames = { low: "Baixo", medium: "Médio", high: "Alto", critical: "Crítico" };

function setupInventoryHeader() {
  const row = $("assets-body").closest("table").querySelector("thead tr");
  row.replaceChildren(...[
    "Ativo", "Endereço", "Porta", "Serviço", "Contexto", "Risco", "Última observação", "",
  ].map((label) => {
    const heading = document.createElement("th");
    heading.textContent = label;
    return heading;
  }));
}

function openAssetEditor(asset) {
  $("asset-ip").value = asset.ip;
  $("asset-dialog-title").textContent = asset.display_name || asset.hostname || asset.ip;
  $("asset-name").value = asset.display_name || "";
  $("asset-owner").value = asset.owner || "";
  $("asset-environment").value = asset.environment || "unknown";
  $("asset-criticality").value = asset.criticality || "medium";
  $("asset-tags").value = (asset.tags || []).join(", ");
  $("asset-notes").value = asset.notes || "";
  $("asset-dialog").showModal();
}

async function loadSessions() {
  const root = $("session-list");
  root.replaceChildren();
  try {
    const sessions = await api("/api/v1/sessions");
    for (const session of sessions) {
      const card = document.createElement("article");
      card.className = `session-card ${session.status}`;
      const text = document.createElement("div");
      const title = document.createElement("strong");
      title.textContent = session.current ? "Esta sessão" : "Sessão do navegador";
      const detail = document.createElement("small");
      detail.textContent = `Último uso ${new Date(session.last_seen_at).toLocaleString()} · ${statusNames[session.status] || session.status}`;
      text.append(title, detail);
      card.append(text);
      if (session.status === "active") {
        card.append(actionButton("Encerrar", async () => {
          try {
            await api(`/api/v1/sessions/${session.id}`, { method: "DELETE" });
            if (session.current) disconnect("Sessão encerrada. Entre novamente.");
            await loadSessions();
          } catch (error) { notify(error.message, "error"); }
        }, true));
      }
      root.append(card);
    }
    if (!sessions.length) {
      const empty = document.createElement("p");
      empty.className = "empty";
      empty.textContent = "Nenhuma sessão registrada.";
      root.append(empty);
    }
  } catch (error) {
    notify(error.message, "error");
  }
}

function renderAssets(assets, remember = true) {
  if (remember) state.assets = assets;
  renderOpenPortMap(assets);
  const body = $("assets-body");
  if (!assets.length) {
    body.replaceChildren(emptyRow("Nenhuma porta aberta observada.", 8));
    return;
  }
  const fragment = document.createDocumentFragment();
  for (const asset of assets.slice(0, MAX_ASSET_TABLE_ROWS)) {
    const row = document.createElement("tr");
    row.append(
      cell(asset.hostname || "-"),
      cell(asset.ip),
      portCell(asset),
      cell([asset.service, asset.product, asset.version].filter(Boolean).join(" • ") || "—"),
      cell(new Date(asset.observed_at).toLocaleString()),
    );
    row.children[0].textContent = asset.display_name || asset.hostname || "-";
    const context = cell([asset.owner, environmentNames[asset.environment], ...(asset.tags || [])]
      .filter(Boolean).join(" · ") || "Não classificado");
    const risk = cell(`${riskNames[asset.risk_level] || asset.risk_level} · ${asset.risk_score}`);
    risk.className = `risk-cell ${asset.risk_level}`;
    const actions = document.createElement("td");
    if (state.session.role !== "viewer") actions.append(actionButton("Contexto", () => openAssetEditor(asset)));
    row.insertBefore(context, row.children[4]);
    row.insertBefore(risk, row.children[5]);
    row.append(actions);
    fragment.append(row);
  }
  if (assets.length > MAX_ASSET_TABLE_ROWS) {
    fragment.append(emptyRow(
      `${assets.length - MAX_ASSET_TABLE_ROWS} registro(s) adicional(is). Refine o filtro ou use a exportação CSV.`,
      8,
    ));
  }
  body.replaceChildren(fragment);
}

function renderScans(scans) {
  const root = $("scans");
  root.replaceChildren();
  if (!scans.length) {
    const item = document.createElement("p");
    item.className = "empty";
    item.textContent = "Nenhuma varredura registrada.";
    root.append(item);
    return;
  }
  for (const scan of scans) {
    const card = document.createElement("article");
    card.className = "scan-card";
    const target = document.createElement("strong");
    target.textContent = scan.target;
    const badge = document.createElement("span");
    badge.className = `status ${scan.status}`;
    badge.textContent = statusNames[scan.status] || scan.status;
    const detail = document.createElement("small");
    detail.textContent = `${Number(scan.port_count).toLocaleString("pt-BR")} portas • ${profileNames[scan.port_profile] || scan.port_profile} • ${new Date(scan.created_at).toLocaleString()}`;
    const reference = document.createElement("div");
    reference.className = "scan-reference";
    const identifier = document.createElement("code");
    identifier.textContent = `Scan ID: ${scan.id}`;
    identifier.title = scan.id;
    reference.append(identifier, actionButton("Copiar ID", () => copyScanId(scan.id)));
    card.append(target, badge, detail, reference);
    if (["queued", "running"].includes(scan.status) && state.session.role !== "viewer") {
      card.append(actionButton("Cancelar", async () => {
        if (!confirm(`Cancelar a varredura de ${scan.target}?`)) return;
        try {
          await api(`/api/v1/scans/${scan.id}`, { method: "DELETE" });
          notify("Cancelamento registrado. Resultados tardios serão descartados.", "success");
          await load(true);
        } catch (error) { notify(error.message, "error"); }
      }, true));
    }
    root.append(card);
  }
}

function renderMonitors(monitors) {
  const root = $("monitors");
  root.replaceChildren();
  for (const monitor of monitors) {
    const card = document.createElement("article");
    card.className = "monitor-card";
    const name = document.createElement("strong");
    name.textContent = monitor.name;
    const detail = document.createElement("small");
    detail.textContent = `${monitor.target} • ${profileNames[monitor.port_profile]} • a cada ${monitor.interval_minutes} min`;
    card.append(name);
    if (state.session.role !== "viewer") {
      card.append(actionButton("Remover", async () => {
        if (!confirm(`Remover o monitor "${monitor.name}"?`)) return;
        try { await api(`/api/v1/monitors/${monitor.id}`, { method: "DELETE" }); await load(true); }
        catch (error) { notify(error.message, "error"); }
      }, true));
    }
    card.append(detail);
    root.append(card);
  }
}

function renderDiscoveries(discoveries) {
  const root = $("discovery-history");
  root.replaceChildren();
  for (const discovery of discoveries.slice(0, 8)) {
    const card = document.createElement("article");
    card.className = "discovery-card";
    const domain = document.createElement("strong");
    domain.textContent = discovery.domain;
    const badge = document.createElement("span");
    badge.className = `status ${discovery.status}`;
    badge.textContent = statusNames[discovery.status] || discovery.status;
    const detail = document.createElement("small");
    detail.textContent = `${discovery.engine || "gobuster"} • ${discovery.found_count} host(s) • ${new Date(discovery.created_at).toLocaleString()}`;
    card.append(domain, badge, detail);
    if (["queued", "running"].includes(discovery.status) && state.session.role !== "viewer") {
      card.append(actionButton("Cancelar", async () => {
        try {
          await api(`/api/v1/discoveries/${discovery.id}`, { method: "DELETE" });
          await load(true);
        } catch (error) { notify(error.message, "error"); }
      }, true));
    }
    root.append(card);
  }
}

function renderWebObservations(observations) {
  const body = $("web-observations-body");
  if (!observations.length) {
    body.replaceChildren(emptyRow("Nenhum serviço web observado.", 6));
    return;
  }
  const fragment = document.createDocumentFragment();
  for (const observation of observations.slice(0, MAX_SECONDARY_TABLE_ROWS)) {
    const row = document.createElement("tr");
    const endpoint = `${observation.scheme}://${observation.target}:${observation.port}`;
    const statusCell = cell(observation.error || observation.status_code || "-");
    if (observation.error) statusCell.className = "probe-error";
    const hasTlsDays = observation.tls_days_remaining !== null && observation.tls_days_remaining !== undefined;
    const tlsCell = cell(observation.scheme === "https"
      ? (hasTlsDays ? `${observation.tls_days_remaining} dias` : "Certificado indisponível")
      : "-");
    if (observation.scheme === "https" && hasTlsDays) {
      tlsCell.className = observation.tls_days_remaining < 30 ? "tls-warn" : "tls-good";
    }
    row.append(
      cell(endpoint),
      statusCell,
      cell(observation.title || observation.location || "-"),
      cell(observation.server || observation.content_type || "-"),
      tlsCell,
      cell(new Date(observation.observed_at).toLocaleString()),
    );
    fragment.append(row);
  }
  if (observations.length > MAX_SECONDARY_TABLE_ROWS) {
    fragment.append(emptyRow(`${observations.length - MAX_SECONDARY_TABLE_ROWS} observação(ões) adicional(is).`, 6));
  }
  body.replaceChildren(fragment);
}

function renderDiscoveredHosts(hosts) {
  const body = $("discovered-hosts-body");
  if (!hosts.length) {
    body.replaceChildren(emptyRow("Nenhum subdomínio observado.", 4));
    return;
  }
  const fragment = document.createDocumentFragment();
  for (const host of hosts.slice(0, MAX_SECONDARY_TABLE_ROWS)) {
    const row = document.createElement("tr");
    const actions = document.createElement("td");
    if (state.session.role !== "viewer") {
      actions.append(actionButton("Usar no Nmap", () => {
        $("target").value = host.hostname;
        $("target").focus();
        window.scrollTo({ top: $("scan-form").getBoundingClientRect().top + window.scrollY - 110, behavior: "smooth" });
      }));
    }
    row.append(cell(host.hostname), cell(host.domain), cell(new Date(host.observed_at).toLocaleString()), actions);
    fragment.append(row);
  }
  if (hosts.length > MAX_SECONDARY_TABLE_ROWS) {
    fragment.append(emptyRow(`${hosts.length - MAX_SECONDARY_TABLE_ROWS} host(s) adicional(is).`, 4));
  }
  body.replaceChildren(fragment);
}

function renderAlerts(alerts) {
  const root = $("alerts");
  root.replaceChildren();
  const pending = alerts.filter((alert) => !alert.acknowledged_at).length;
  $("alert-counter").textContent = String(pending);
  if (!alerts.length) {
    const item = document.createElement("p");
    item.className = "empty";
    item.textContent = "Nenhuma mudança detectada.";
    root.append(item);
    return;
  }
  for (const alert of alerts) {
    const card = document.createElement("article");
    card.className = alert.acknowledged_at ? "alert-card acknowledged" : "alert-card";
    const dot = document.createElement("span");
    dot.className = "alert-dot";
    const text = document.createElement("div");
    const title = document.createElement("strong");
    title.textContent = alert.title;
    const detail = document.createElement("small");
    detail.textContent = `${alert.ip}${alert.port ? `:${alert.port}/${alert.protocol}` : ""} • ${new Date(alert.created_at).toLocaleString()}`;
    text.append(title, detail);
    card.append(dot, text);
    if (!alert.acknowledged_at && state.session.role !== "viewer") {
      card.append(actionButton("Reconhecer", async () => {
        try { await api(`/api/v1/alerts/${alert.id}/acknowledge`, { method: "POST" }); await load(true); }
        catch (error) { notify(error.message, "error"); }
      }));
    }
    root.append(card);
  }
}

async function load(force = false) {
  if (state.loading || (!force && !state.session)) return;
  state.loading = true;
  try {
    const firstLoad = state.session === null;
    if (firstLoad) {
      state.session = await api("/api/v1/session");
      renderSession();
      if (state.session.kind === "user" && !state.csrfToken) await refreshCsrfToken();
    }
    const common = [
      api("/api/v1/overview"),
      api("/api/v1/assets?limit=200"),
      api("/api/v1/scans?limit=30"),
      api("/api/v1/monitors"),
      api("/api/v1/discoveries?limit=20"),
      api("/api/v1/discovered-hosts?limit=200"),
      api("/api/v1/web-observations?limit=200"),
      api("/api/v1/alerts?limit=50"),
    ];
    const [overview, assets, scans, monitors, discoveries, hosts, webObservations, alerts] = await Promise.all(common);
    if (dataChanged("overview", overview)) {
      $("stat-assets").textContent = overview.assets;
      $("stat-ports").textContent = overview.open_ports;
      $("stat-scans").textContent = overview.scans;
      $("stat-discoveries").textContent = overview.discovered_hosts;
      $("stat-alerts").textContent = overview.unacknowledged_alerts;
      $("stat-monitors").textContent = overview.monitors;
    }
    if (dataChanged("exposure", { overview, assets })) renderExposureCockpit(overview, assets);
    if (dataChanged("assets", assets)) {
      state.assets = assets;
      renderFilteredAssets();
    }
    if (dataChanged("scans", scans)) renderScans(scans);
    if (dataChanged("monitors", monitors)) renderMonitors(monitors);
    if (dataChanged("discoveries", discoveries)) renderDiscoveries(discoveries);
    if (dataChanged("hosts", hosts)) renderDiscoveredHosts(hosts);
    if (dataChanged("web-observations", webObservations)) renderWebObservations(webObservations);
    if (dataChanged("alerts", alerts)) renderAlerts(alerts);
    $("last-sync").textContent = `Atualizado às ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    if (firstLoad) notify("Conectado. Atualização otimizada a cada 60 segundos.", "success");
  } catch (error) {
    if (state.session) notify(error.message, "error");
  } finally {
    state.loading = false;
  }
}

function scheduleRefresh() {
  if (refreshTimer !== null) window.clearTimeout(refreshTimer);
  if (document.hidden) {
    refreshTimer = null;
    return;
  }
  refreshTimer = window.setTimeout(async () => {
    refreshTimer = null;
    await load();
    scheduleRefresh();
  }, AUTO_REFRESH_MS);
}

$("logout").addEventListener("click", async () => {
  try {
    await api("/api/v1/auth/logout", { method: "POST" });
    disconnect();
  } catch (error) {
    notify(error.message, "error");
  }
});
$("open-report").addEventListener("click", () => window.open("/report", "_blank", "noopener"));
$("manage-sessions").addEventListener("click", async () => {
  $("sessions-dialog").showModal();
  await loadSessions();
});
$("close-sessions").addEventListener("click", () => $("sessions-dialog").close());
$("change-password").addEventListener("click", () => $("password-dialog").showModal());
$("cancel-password").addEventListener("click", () => $("password-dialog").close());
$("password-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await api("/api/v1/users/me/password", {
      method: "POST",
      body: JSON.stringify({
        current_password: $("current-password").value,
        new_password: $("new-password").value,
      }),
    });
    $("password-dialog").close();
    event.target.reset();
    disconnect("Senha alterada. Entre novamente com a nova senha.");
  } catch (error) {
    notify(error.message, "error");
  }
});
$("cancel-asset").addEventListener("click", () => $("asset-dialog").close());
$("asset-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const ip = $("asset-ip").value;
    await api(`/api/v1/assets/${encodeURIComponent(ip)}`, {
      method: "PUT",
      body: JSON.stringify({
        display_name: $("asset-name").value.trim(),
        owner: $("asset-owner").value.trim(),
        environment: $("asset-environment").value,
        criticality: $("asset-criticality").value,
        tags: $("asset-tags").value.split(",").map((item) => item.trim()).filter(Boolean),
        notes: $("asset-notes").value.trim(),
      }),
    });
    $("asset-dialog").close();
    notify("Contexto e prioridade do ativo atualizados.", "success");
    await load(true);
  } catch (error) { notify(error.message, "error"); }
});
$("scan-profile").addEventListener("change", () => updateProfile("scan-profile", "scan-ports-wrap", "scan-profile-warning"));
$("monitor-profile").addEventListener("change", () => updateProfile("monitor-profile", "monitor-ports-wrap"));
$("scan-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const selection = portSelection("scan-profile", "ports");
    const scan = await api("/api/v1/scans", {
      method: "POST",
      body: JSON.stringify({ target: $("target").value.trim(), ...selection, service_detection: $("service-detection").checked }),
    });
    notify(`Varredura enfileirada. Scan ID: ${scan.id}`, "success");
    await load(true);
  } catch (error) { notify(error.message, "error"); }
});
$("discovery-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await api("/api/v1/discoveries", {
      method: "POST",
      body: JSON.stringify({
        domain: $("discovery-domain").value.trim(),
        engine: $("discovery-engine").value,
      }),
    });
    notify("Descoberta DNS controlada enfileirada.", "success");
    await load(true);
  } catch (error) { notify(error.message, "error"); }
});
$("web-probe-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    await api("/api/v1/web-probes", {
      method: "POST",
      body: JSON.stringify({ target: $("web-probe-target").value.trim() }),
    });
    notify("Inventário HTTP/TLS atualizado.", "success");
    await load(true);
  } catch (error) { notify(error.message, "error"); }
});
$("monitor-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  try {
    const selection = portSelection("monitor-profile", "monitor-ports");
    await api("/api/v1/monitors", {
      method: "POST",
      body: JSON.stringify({
        name: $("monitor-name").value.trim(),
        target: $("monitor-target").value.trim(),
        ...selection,
        interval_minutes: Number($("monitor-interval").value),
        service_detection: $("monitor-service-detection").checked,
      }),
    });
    notify("Monitor criado.", "success");
    event.target.reset();
    updateProfile("monitor-profile", "monitor-ports-wrap");
    await load(true);
  } catch (error) { notify(error.message, "error"); }
});
$("refresh").addEventListener("click", () => load(true).finally(scheduleRefresh));
$("asset-filter").addEventListener("input", scheduleAssetFilter);
for (const button of $("port-filters").querySelectorAll("button[data-category]")) {
  button.addEventListener("click", () => setPortCategory(button.dataset.category));
}

document.addEventListener("visibilitychange", () => {
  document.body.classList.toggle("ui-paused", document.hidden);
  if (document.hidden) {
    if (refreshTimer !== null) window.clearTimeout(refreshTimer);
    refreshTimer = null;
  } else {
    load().finally(scheduleRefresh);
  }
});

setupInventoryHeader();
load(true).finally(scheduleRefresh);
