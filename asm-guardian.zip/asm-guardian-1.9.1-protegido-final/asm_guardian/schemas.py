from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .config import DEFAULT_PORTS


USERNAME_PATTERN = r"^[a-z0-9][a-z0-9._-]{2,63}$"


class LoginRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    username: str = Field(pattern=USERNAME_PATTERN, min_length=3, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class UserCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    username: str = Field(pattern=USERNAME_PATTERN, min_length=3, max_length=64)
    display_name: str = Field(min_length=1, max_length=120)
    password: str = Field(min_length=12, max_length=256)
    role: Literal["admin", "operator", "viewer"] = "operator"
    tenant_id: str | None = Field(default=None, min_length=1, max_length=64)

    @field_validator("display_name")
    @classmethod
    def clean_display_name(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("display_name cannot be blank")
        return cleaned


class PasswordChangeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=12, max_length=256)


class PasswordResetRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    password: str = Field(min_length=12, max_length=256)


class ScanRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    target: str = Field(min_length=1, max_length=253)
    port_profile: Literal["custom", "top-1000", "all-tcp"] = "custom"
    ports: list[int] | None = Field(default=None, max_length=4096)
    service_detection: bool = False

    @model_validator(mode="after")
    def validate_port_selection(self) -> "ScanRequest":
        if self.port_profile == "custom":
            self.ports = list(DEFAULT_PORTS) if self.ports is None else self.ports
            if not self.ports:
                raise ValueError("custom profile requires at least one port")
        elif self.ports not in (None, []):
            raise ValueError("ports must be omitted for top-1000 and all-tcp profiles")
        else:
            self.ports = []
        return self

    @field_validator("ports")
    @classmethod
    def valid_ports(cls, value: list[int] | None) -> list[int] | None:
        if value is None:
            return None
        if any(port < 1 or port > 65535 for port in value):
            raise ValueError("ports must be between 1 and 65535")
        if len(set(value)) != len(value):
            raise ValueError("ports must not contain duplicates")
        return sorted(value)


class MonitorRequest(ScanRequest):
    name: str = Field(min_length=1, max_length=80)
    interval_minutes: int = Field(default=1440, ge=15, le=10080)


class DiscoveryRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    domain: str = Field(min_length=1, max_length=253)
    engine: Literal["gobuster", "subfinder"] = "gobuster"

    @field_validator("domain")
    @classmethod
    def clean_domain(cls, value: str) -> str:
        if value != value.strip():
            raise ValueError("domain cannot contain leading or trailing whitespace")
        return value


class WebProbeRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    target: str = Field(min_length=1, max_length=253)

    @field_validator("target")
    @classmethod
    def clean_target(cls, value: str) -> str:
        if value != value.strip():
            raise ValueError("target cannot contain leading or trailing whitespace")
        return value


class AssetMetadataRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    display_name: str = Field(default="", max_length=120)
    owner: str = Field(default="", max_length=120)
    environment: Literal["unknown", "development", "test", "staging", "production"] = "unknown"
    criticality: Literal["low", "medium", "high", "critical"] = "medium"
    tags: list[str] = Field(default_factory=list, max_length=20)
    notes: str = Field(default="", max_length=1_000)

    @field_validator("display_name", "owner", "notes")
    @classmethod
    def clean_context_text(cls, value: str) -> str:
        return value.strip()

    @field_validator("tags")
    @classmethod
    def clean_tags(cls, value: list[str]) -> list[str]:
        cleaned = sorted({item.strip().lower() for item in value if item.strip()})
        if any(len(item) > 32 for item in cleaned):
            raise ValueError("tags must contain at most 32 characters")
        return cleaned


class RetentionRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    older_than_days: int = Field(default=365, ge=30, le=3650)
    dry_run: bool = True


class ApiKeyCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str = Field(min_length=1, max_length=80)
    role: Literal["admin", "operator", "viewer"] = "operator"
    expires_in_days: int | None = Field(default=90, ge=1, le=3650)
    tenant_id: str | None = Field(default=None, min_length=1, max_length=64)

    @field_validator("name")
    @classmethod
    def clean_name(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("name cannot be blank")
        return cleaned


class ApiKeyRotateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    expires_in_days: int | None = Field(default=90, ge=1, le=3650)


class TenantCreateRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    slug: str = Field(pattern=r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$", max_length=63)
    name: str = Field(min_length=1, max_length=120)
    allowed_networks: list[str] = Field(min_length=1, max_length=256)
    allowed_hosts: list[str] = Field(default_factory=list, max_length=256)

    @field_validator("name")
    @classmethod
    def clean_tenant_name(cls, value: str) -> str:
        cleaned = value.strip()
        if not cleaned:
            raise ValueError("name cannot be blank")
        return cleaned
