# ASM Guardian 1.9.1

Scanner defensivo de superfície de ataque para Ubuntu Linux. Inclui autenticação por usuário e senha, dashboard incorporável, SQLite persistente, Nmap controlado, descoberta DNS ativa com Gobuster, descoberta passiva opcional com Subfinder, inventário HTTP/TLS e alertas de mudança.

Use somente em ativos próprios ou com autorização explícita. A aplicação não executa exploração ativa, NSE, força bruta, UDP ou detecção de sistema operacional.

## Instalar ou atualizar no Ubuntu

```bash
cd "$HOME/Desktop/asm-guardian-1.9.1-protegido-final"
sudo bash scripts/install-ubuntu.sh
sudo /opt/asm-guardian/venv/bin/asm-guardian --env-file /etc/asm-guardian.env check
sudo systemctl status asm-guardian --no-pager
```

A atualização preserva `/etc/asm-guardian.env` e `/var/lib/asm-guardian/asm_guardian.db`. O banco é migrado automaticamente.

## Configurar alvos autorizados

```bash
sudoedit /etc/asm-guardian.env
```

Exemplo:

```dotenv
ASM_API_KEY=SUA_CHAVE_ADMINISTRATIVA_COM_16_OU_MAIS_CARACTERES
ASM_ADMIN_USERNAME=admin
ASM_ADMIN_PASSWORD=SUA_SENHA_FORTE_COM_12_OU_MAIS_CARACTERES
ASM_SESSION_TTL_MINUTES=480
ASM_SESSION_COOKIE_SECURE=false
ASM_LOGIN_RATE_LIMIT=5
ASM_DATABASE_PATH=/var/lib/asm-guardian/asm_guardian.db
ASM_ALLOWED_NETWORKS=10.20.0.0/16,2001:db8:1234::/48
ASM_ALLOWED_HOSTS=interno.example,*.interno.example
ASM_NMAP_TIMEOUT_SECONDS=3600
ASM_GOBUSTER_THREADS=5
ASM_GOBUSTER_TIMEOUT_SECONDS=300
ASM_SUBFINDER_BINARY=subfinder
ASM_SUBFINDER_RATE_LIMIT=10
ASM_WEB_PROBE_RATE_LIMIT=6
ASM_WEB_PROBE_TIMEOUT_SECONDS=5
ASM_FRAME_ANCESTORS='self'
```

```bash
sudo systemctl restart asm-guardian
sudo /opt/asm-guardian/venv/bin/asm-guardian --env-file /etc/asm-guardian.env check
```

Um hostname só pode ser varrido quando o nome corresponde a `ASM_ALLOWED_HOSTS` e todos os IPs retornados pertencem a `ASM_ALLOWED_NETWORKS`.

```bash
getent ahosts interno.example | awk '{print $1}' | sort -u
```

## Abrir o dashboard

```text
http://127.0.0.1:8080
```

```bash
sudo grep -E '^ASM_ADMIN_(USERNAME|PASSWORD)=' /etc/asm-guardian.env
```

A interface 1.9.1 possui uma página exclusiva em `/login`, com a mesma identidade visual abstrata do painel. O endereço `/` só entrega o dashboard quando existe uma sessão válida; sem sessão, redireciona para a entrada. Os arquivos HTML também não são expostos diretamente pela rota de recursos estáticos.

A senha é armazenada com `scrypt`; a sessão usa cookie `HttpOnly`/`SameSite=Strict`, expira no servidor e exige proteção CSRF em alterações. O token CSRF usa um cookie separado `SameSite=Strict`, não autentica sozinho e é renovado automaticamente quando uma sessão preservada não possui mais o token da aba. O painel não armazena senha nem chave de API no navegador. O botão **Trocar senha** encerra todas as sessões da conta.

O painel atualiza os dados a cada 60 segundos, pausa a atualização quando a aba não está visível e só redesenha blocos cujo conteúdo mudou. A interface consulta no máximo 200 registros por coleção, renderiza até 100 linhas por tabela e mostra até 24 portas por cartão; filtros, detalhamento técnico e CSV continuam disponíveis. Efeitos abstratos permanecem visíveis como gradientes estáticos, sem animações, desfoques de composição ou filtros caros, para melhorar o uso em VMs e navegadores sem aceleração gráfica.

## Operação, inventário e relatórios

A versão 1.9.1 permite cancelar trabalhos em fila ou execução. Quando o processo externo já começou, o cancelamento é registrado imediatamente e qualquer resultado tardio é descartado com segurança.

O inventário aceita nome amigável, responsável, ambiente, criticidade, etiquetas e observações. Uma pontuação contextual ajuda a ordenar a revisão; ela representa prioridade operacional e não confirma vulnerabilidades.

O dashboard exporta o inventário em CSV e oferece um relatório imprimível que pode ser salvo como PDF pelo navegador. A conta também pode listar e encerrar suas próprias sessões. Alertas adicionais identificam porta removida, mudança de serviço, novo subdomínio, alteração Web e certificado TLS próximo do vencimento.

Backup consistente do SQLite, sem substituir arquivos existentes:

```bash
sudo /opt/asm-guardian/venv/bin/asm-guardian \
  --env-file /etc/asm-guardian.env \
  backup --output "/var/backups/asm-guardian-$(date +%F).db"
```

## Identificadores de varredura

Cada execução Nmap recebe um UUID persistente. O dashboard mostra o `Scan ID` completo no histórico e oferece o botão **Copiar ID**; a resposta de `POST /api/v1/scans` também devolve o mesmo campo `id`. Use esse identificador para correlacionar alertas, registros e chamados.

O `Scan ID` do ASM Guardian não é um `scanId` do Codex Security. O identificador do Codex Security é emitido pelo próprio serviço ao iniciar uma auditoria de código e não deve ser inventado ou gravado como segredo permanente na aplicação.

## Varredura completa de portas TCP

Não há limite de quantidade total de varreduras ou licença. O perfil `all-tcp` cobre as 65.535 portas TCP. Rate limiting, fila, concorrência e allowlist continuam obrigatórios para proteger o serviço e a rede.

```bash
export ASM_KEY='COLE_A_CHAVE_AQUI'

curl -X POST http://127.0.0.1:8080/api/v1/scans \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${ASM_KEY}" \
  -d '{"target":"127.0.0.1","port_profile":"all-tcp","service_detection":false}'
```

Perfis disponíveis: `custom` (até 4.096 portas), `top-1000` e `all-tcp`.

## Descoberta DNS controlada

Configure o domínio-base e o curinga quando quiser descobrir e posteriormente varrer seus subdomínios:

```dotenv
ASM_ALLOWED_HOSTS=interno.example,*.interno.example
```

```bash
curl -X POST http://127.0.0.1:8080/api/v1/discoveries \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${ASM_KEY}" \
  -d '{"domain":"interno.example","engine":"gobuster"}'
```

Gobuster usa consultas DNS ativas e uma lista pequena incorporada, no máximo 10 threads e uma fila limitada. Ele exige um domínio porque forma candidatos como `api.interno.example`; um IP não possui esse namespace de subdomínios.

O mecanismo `subfinder` é passivo e opcional. Instale uma versão fixada do projeto oficial antes de selecioná-lo no dashboard:

```bash
sudo apt-get install -y golang-go
mkdir -p "$HOME/.local/bin"
GOBIN="$HOME/.local/bin" go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@v2.16.0
sudo install -m 0755 "$HOME/.local/bin/subfinder" /usr/local/bin/subfinder
sudo systemctl restart asm-guardian
```

Ambos registram nomes, mas nunca iniciam Nmap. Ao selecionar um hostname para varredura, a aplicação valida novamente a regra de host e todos os IPs resolvidos.

## Inventário HTTP/TLS

O formulário **Web/TLS** aceita IP ou hostname autorizado. A aplicação conecta diretamente aos IPs validados nas portas 80 e 443, solicita apenas `/`, não segue redirecionamentos e registra status, título, servidor, tipo de conteúdo e validade do certificado. Timeout, tamanho de resposta, concorrência, taxa e quantidade de endereços são limitados.

```bash
curl -X POST http://127.0.0.1:8080/api/v1/web-probes \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${ASM_KEY}" \
  -d '{"target":"interno.example"}'
```

## Usuários e senhas

```bash
export ASM_KEY="$(sudo sed -n 's/^ASM_API_KEY=//p' /etc/asm-guardian.env)"

curl -X POST http://127.0.0.1:8080/api/v1/users \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${ASM_KEY}" \
  -d '{"username":"operador.soc","display_name":"Operador SOC","password":"TROQUE-ESTA-SENHA-FORTE","role":"operator"}'
```

- `viewer`: leitura do painel e inventário.
- `operator`: leitura, varreduras, descobertas, monitores e alertas.
- `admin`: também gerencia usuários e integrações da própria organização.

Os usuários têm nomes globais de 3 a 64 caracteres minúsculos, números, ponto, hífen ou sublinhado. Senhas têm no mínimo 12 caracteres. Redefinir ou desativar uma conta revoga todas as suas sessões.

## Chaves de API para automações

A chave `ASM_API_KEY` é somente a credencial administrativa de recuperação. Para scripts, CI ou integrações sem navegador, crie uma chave gerenciada dedicada:

```bash
curl -X POST http://127.0.0.1:8080/api/v1/api-keys \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${ASM_KEY}" \
  -d '{"name":"Operador SOC","role":"operator","expires_in_days":90}'
```

- `viewer`: leitura de painel e inventário.
- `operator`: leitura, varreduras, descobertas, monitores e reconhecimento de alertas.
- `admin`: também cria, rotaciona e revoga chaves e consulta a auditoria.

O segredo completo aparece uma única vez. O banco armazena somente o hash SHA-256, o prefixo e os metadados. Chaves não são usadas pelo dashboard.

## Organizações e isolamento de clientes

A conta inicial e a chave `ASM_API_KEY` são administradoras globais. Elas operam na organização `default`, criam novas organizações e podem criar o primeiro usuário administrativo de cada cliente. Allowlists, usuários, sessões, chaves de integração, scans, ativos, descobertas, inventário Web/TLS, monitores, alertas e auditoria ficam separados por organização.

```bash
curl -X POST http://127.0.0.1:8080/api/v1/tenants \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${ASM_KEY}" \
  -d '{"slug":"cliente-a","name":"Cliente A","allowed_networks":["10.30.0.0/16"],"allowed_hosts":["portal.cliente-a.example","*.cliente-a.example"]}'
```

Copie o campo `id` retornado e use-o somente com a chave global para criar o primeiro usuário do cliente:

```bash
curl -X POST http://127.0.0.1:8080/api/v1/users \
  -H "Content-Type: application/json" \
  -H "X-API-Key: ${ASM_KEY}" \
  -d '{"username":"admin.cliente-a","display_name":"Administrador Cliente A","password":"TROQUE-ESTA-SENHA-FORTE","role":"admin","tenant_id":"COLE_O_ID_DA_ORGANIZACAO"}'
```

O administrador do cliente gerencia apenas usuários e integrações da própria organização. O `tenant_id` nunca é aceito nos endpoints operacionais: ele é obtido da sessão ou chave autenticada, evitando que um cliente selecione o espaço de outro. Instalações antigas são migradas automaticamente para `default`, cuja allowlist continua vindo de `ASM_ALLOWED_NETWORKS` e `ASM_ALLOWED_HOSTS`.

## Principais opções

| Variável | Padrão | Limite/finalidade |
| --- | --- | --- |
| `ASM_REQUEST_RATE_LIMIT` | `120` | requisições de API por IP/minuto |
| `ASM_LOGIN_RATE_LIMIT` | `5` | tentativas de login por IP e usuário/minuto |
| `ASM_SESSION_TTL_MINUTES` | `480` | validade fixa da sessão, entre 15 e 10.080 minutos |
| `ASM_SESSION_COOKIE_SECURE` | `false` | use `true` atrás de HTTPS |
| `ASM_SCAN_RATE_LIMIT` | `6` | novas varreduras ou monitores por chave e IP/minuto |
| `ASM_MAX_CONCURRENT_SCANS` | `2` | Nmap simultâneo, máximo 8 |
| `ASM_MAX_PENDING_SCANS` | `16` | trabalhos Nmap na fila, máximo 256 |
| `ASM_NMAP_MAX_RATE` | `50` | probes por segundo |
| `ASM_NMAP_TIMEOUT_SECONDS` | `3600` | máximo 14.400 segundos |
| `ASM_DISCOVERY_RATE_LIMIT` | `2` | descobertas por chave e IP/minuto |
| `ASM_MAX_PENDING_DISCOVERIES` | `4` | descobertas na fila, máximo 16 |
| `ASM_GOBUSTER_THREADS` | `5` | máximo 10 |
| `ASM_GOBUSTER_TIMEOUT_SECONDS` | `300` | máximo 1.800 segundos |
| `ASM_GOBUSTER_WORDLIST` | incorporada | arquivo opcional, regular e de até 1 MiB |
| `ASM_SUBFINDER_RATE_LIMIT` | `10` | limite interno do mecanismo passivo, máximo 50 |
| `ASM_SUBFINDER_TIMEOUT_SECONDS` | `300` | máximo 1.800 segundos |
| `ASM_WEB_PROBE_RATE_LIMIT` | `6` | inspeções HTTP/TLS por chave e IP/minuto |
| `ASM_WEB_PROBE_TIMEOUT_SECONDS` | `5` | timeout por endpoint, máximo 30 segundos |
| `ASM_WEB_PROBE_MAX_RESPONSE_BYTES` | `65536` | leitura máxima por endpoint, até 262.144 bytes |
| `ASM_WEB_PROBE_MAX_ADDRESSES` | `4` | IPs autorizados por inspeção, máximo 8 |
| `ASM_TLS_EXPIRY_WARNING_DAYS` | `30` | alerta de expiração TLS, entre 1 e 180 dias |
| `ASM_FRAME_ANCESTORS` | `'self'` | origens HTTPS autorizadas a incorporar o painel |

Para acesso remoto, mantenha a aplicação em loopback e use um proxy reverso HTTPS autenticado. Não exponha a porta 8080 diretamente à Internet.

## Verificar o código

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements-dev.txt
ruff check .
pytest --cov=asm_guardian --cov-report=term-missing
```

Os testes automatizados substituem Nmap, Gobuster, Subfinder e o inspetor web por executores controlados; eles não varrem a rede.
