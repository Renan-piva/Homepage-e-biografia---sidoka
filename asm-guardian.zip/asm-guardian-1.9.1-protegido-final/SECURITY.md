# Segurança do ASM Guardian

## Modelo operacional

O ASM Guardian é uma ferramenta defensiva para ativos próprios ou formalmente autorizados. A configuração padrão vincula o serviço ao loopback. A versão 1.6 separa organizações, allowlists, chaves e dados no mesmo banco; ambientes com exigência regulatória de isolamento físico ainda devem usar uma implantação e banco separados por cliente.

Os controles principais são:

- somente IPs em `ASM_ALLOWED_NETWORKS` podem chegar ao Nmap;
- hostnames precisam corresponder a `ASM_ALLOWED_HOSTS`, e todos os endereços DNS resolvidos devem permanecer nas redes autorizadas;
- Nmap usa argumentos fixos, `shell=False`, taxa e timeout limitados, sem NSE, UDP, força bruta ou exploração;
- cobertura completa significa apenas o perfil fixo TCP `1-65535`; ela não libera flags arbitrárias nem ignora a allowlist;
- Gobuster é restrito ao modo DNS, domínio-base explicitamente permitido, wordlist limitada, argumentos fixos, `shell=False`, timeout, rate limit e fila próprios;
- nomes descobertos não são varridos automaticamente e precisam passar pela allowlist completa antes do Nmap;
- todas as rotas de dados exigem `X-API-Key`; somente `/health` é público;
- chaves gerenciadas têm função `viewer`, `operator` ou `admin`, expiração, rotação, revogação e auditoria;
- a organização é obtida da chave autenticada; endpoints operacionais não aceitam um `tenant_id` selecionável pelo cliente;
- somente a chave de recuperação pode criar organizações ou emitir uma chave para outra organização;
- segredos gerenciados aparecem uma única vez e o banco armazena somente seus hashes;
- respostas da API não são inseridas por HTML dinâmico no dashboard;
- rate limits, concorrência e backlog são limitados dentro de um processo.

## Operação segura

- Mantenha `/etc/asm-guardian.env` como `root:root` e modo `0600`.
- Preserve `ASM_API_KEY` como chave administrativa de recuperação; não a distribua para uso diário.
- Crie uma chave por pessoa ou integração, conceda a menor função necessária e defina expiração.
- Guarde os segredos em um cofre. Rotacione imediatamente quando houver suspeita de exposição.
- Não publique a porta 8080 diretamente na Internet. Use proxy reverso HTTPS, SSO/MFA quando necessário e limites de tráfego na borda.
- Restrinja a allowlist ao menor conjunto necessário. Não use `0.0.0.0/0` ou `::/0`.
- Use `all-tcp` e descoberta DNS de modo intencional: ambos podem consumir tempo, banda ou capacidade do DNS mesmo com limites.
- Proteja backups do SQLite como dados sensíveis e teste restauração.
- Atualize dependências e repita testes e consulta a avisos antes de cada implantação importante.

## Relato de falhas

Não publique chaves, bancos, resultados de varredura ou detalhes de ativos. Envie uma descrição reproduzível ao responsável pela implantação por canal privado.
