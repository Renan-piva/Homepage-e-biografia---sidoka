from __future__ import annotations

import socket

import pytest

from asm_guardian.security import ScopeError, ScopePolicy, SlidingWindowLimiter


def record(address: str) -> tuple:
    family = socket.AF_INET6 if ":" in address else socket.AF_INET
    return (family, socket.SOCK_STREAM, 6, "", (address, 0))


def test_hostname_requires_name_and_every_resolved_ip_to_be_allowed() -> None:
    policy = ScopePolicy(("10.0.0.0/8",), ("portal.example.com", "*.corp.example.com"))
    resolved = policy.resolve_target("portal.example.com", resolver=lambda *_args, **_kwargs: [record("10.2.3.4")])
    assert resolved.addresses == ("10.2.3.4",)

    with pytest.raises(ScopeError, match="Every resolved address"):
        policy.resolve_target(
            "portal.example.com",
            resolver=lambda *_args, **_kwargs: [record("10.2.3.4"), record("203.0.113.9")],
        )


def test_wildcard_does_not_authorize_parent_or_unrelated_host() -> None:
    policy = ScopePolicy(("10.0.0.0/8",), ("*.corp.example.com",))
    for host in ("corp.example.com", "evilcorp.example.com"):
        with pytest.raises(ScopeError, match="ASM_ALLOWED_HOSTS"):
            policy.resolve_target(host, resolver=lambda *_args, **_kwargs: [record("10.0.0.1")])


def test_scope_rejects_urls_and_command_syntax() -> None:
    policy = ScopePolicy(("127.0.0.0/8",))
    for target in ("http://127.0.0.1", "127.0.0.1 -p 1-65535", "127.0.0.1\nexample.com"):
        with pytest.raises(ScopeError):
            policy.resolve_target(target)


def test_dns_discovery_requires_an_explicit_allowed_domain() -> None:
    policy = ScopePolicy(("10.0.0.0/8",), ("example.com", "*.corp.example.com"))

    assert policy.authorize_discovery_domain("example.com") == "example.com"
    assert policy.authorize_discovery_domain("corp.example.com") == "corp.example.com"
    with pytest.raises(ScopeError, match="discovery"):
        policy.authorize_discovery_domain("unrelated.example")


def test_sliding_window_limiter_has_deterministic_boundary() -> None:
    limiter = SlidingWindowLimiter(window_seconds=60)
    assert limiter.allow("client", 2, now=100)
    assert limiter.allow("client", 2, now=101)
    assert not limiter.allow("client", 2, now=102)
    assert limiter.allow("client", 2, now=160)


def test_sliding_window_limiter_bounds_and_expires_client_keys() -> None:
    limiter = SlidingWindowLimiter(window_seconds=60, max_keys=2)

    assert limiter.allow("client-a", 1, now=100)
    assert limiter.allow("client-b", 1, now=100)
    assert not limiter.allow("client-c", 1, now=101)

    assert limiter.allow("client-c", 1, now=160)
    assert len(limiter._events) == 1
