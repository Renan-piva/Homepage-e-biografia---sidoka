from __future__ import annotations

import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from asm_guardian.config import Settings
from asm_guardian.main import create_app
from asm_guardian.scanner import ScanOutput
from asm_guardian.discovery import DiscoveryOutput
from asm_guardian.webprobe import WebProbeOutput


API_KEY = "test-api-key-at-least-16"


class FakeRunner:
    def __init__(self, fail: bool = False) -> None:
        self.calls: list[tuple] = []
        self.fail = fail

    def run(
        self,
        addresses: tuple[str, ...],
        ports: tuple[int, ...],
        service_detection: bool,
        port_profile: str = "custom",
    ) -> ScanOutput:
        self.calls.append((addresses, ports, service_detection, port_profile))
        if self.fail:
            raise RuntimeError("controlled runner failure")
        observed_port = ports[0] if ports else 80
        return ScanOutput(
            hosts=({"ip": addresses[0], "hostname": "", "state": "up"},),
            findings=(
                {
                    "ip": addresses[0],
                    "hostname": "",
                    "port": observed_port,
                    "protocol": "tcp",
                    "state": "open",
                    "service": "ssh",
                    "product": "OpenSSH",
                    "version": "",
                },
            ),
        )


class FakeDiscoveryRunner:
    def __init__(self, fail: bool = False) -> None:
        self.calls: list[str] = []
        self.fail = fail

    def run(self, domain: str) -> DiscoveryOutput:
        self.calls.append(domain)
        if self.fail:
            raise RuntimeError("controlled discovery failure")
        return DiscoveryOutput(hostnames=(f"api.{domain}", f"www.{domain}"))


class FakeWebProbeRunner:
    def __init__(self) -> None:
        self.calls: list[tuple[str, tuple[str, ...]]] = []

    def run(self, target: str, addresses: tuple[str, ...]) -> WebProbeOutput:
        self.calls.append((target, addresses))
        return WebProbeOutput(
            observations=(
                {
                    "ip": addresses[0],
                    "scheme": "https",
                    "port": 443,
                    "status_code": 200,
                    "title": "Portal autorizado",
                    "server": "nginx",
                    "content_type": "text/html",
                    "location": "",
                    "tls_subject": target,
                    "tls_issuer": "Test CA",
                    "tls_not_after": "2030-01-01T00:00:00+00:00",
                    "tls_days_remaining": 100,
                    "error": "",
                },
            )
        )


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return Settings(
        database_path=tmp_path / "asm.db",
        api_key=API_KEY,
        allowed_networks=("127.0.0.0/8", "10.20.0.0/16"),
        request_rate_limit=100,
        scan_rate_limit=3,
        scheduler_poll_seconds=60,
    )


@pytest.fixture
def fake_runner() -> FakeRunner:
    return FakeRunner()


@pytest.fixture
def fake_discovery_runner() -> FakeDiscoveryRunner:
    return FakeDiscoveryRunner()


@pytest.fixture
def fake_web_probe_runner() -> FakeWebProbeRunner:
    return FakeWebProbeRunner()


@pytest.fixture
def client(
    settings: Settings,
    fake_runner: FakeRunner,
    fake_discovery_runner: FakeDiscoveryRunner,
    fake_web_probe_runner: FakeWebProbeRunner,
):
    app = create_app(settings, fake_runner, fake_discovery_runner, web_probe_runner=fake_web_probe_runner)
    with TestClient(app) as test_client:
        yield test_client


@pytest.fixture
def auth() -> dict[str, str]:
    return {"X-API-Key": API_KEY}


def wait_for_scan(client: TestClient, scan_id: str, auth: dict[str, str]) -> dict:
    for _ in range(50):
        scan = client.get(f"/api/v1/scans/{scan_id}", headers=auth).json()
        if scan["status"] in {"completed", "failed"}:
            return scan
        time.sleep(0.01)
    raise AssertionError("scan did not finish")
