from __future__ import annotations

import threading
import time
from pathlib import Path

from fastapi.testclient import TestClient

from asm_guardian.config import Settings
from asm_guardian.database import Database
from asm_guardian.main import create_app
from asm_guardian.reporting import assets_csv, printable_report
from asm_guardian.scanner import ScanOutput


API_KEY = "operations-key-at-least-16"


def _settings(tmp_path: Path, **overrides) -> Settings:
    values = {
        "database_path": tmp_path / "operations.db",
        "api_key": API_KEY,
        "admin_username": "admin",
        "admin_password": "correct-horse-battery-staple",
        "allowed_networks": ("127.0.0.0/8",),
        "request_rate_limit": 500,
        "scan_rate_limit": 20,
        "scheduler_poll_seconds": 60,
    }
    values.update(overrides)
    return Settings(**values)


def _finding(port: int = 443, *, service: str = "https", product: str = "nginx") -> dict:
    return {
        "ip": "127.0.0.1",
        "hostname": "localhost",
        "port": port,
        "protocol": "tcp",
        "state": "open",
        "service": service,
        "product": product,
        "version": "1",
    }


def test_scan_can_be_cancelled_without_persisting_late_results(tmp_path: Path) -> None:
    release = threading.Event()

    class BlockingRunner:
        def run(self, addresses, ports, service_detection, port_profile="custom"):
            release.wait(timeout=5)
            return ScanOutput(
                hosts=({"ip": addresses[0], "hostname": "", "state": "up"},),
                findings=(_finding(ports[0]),),
            )

    settings = _settings(tmp_path, max_concurrent_scans=1, max_pending_scans=2)
    try:
        with TestClient(create_app(settings, BlockingRunner())) as client:
            auth = {"X-API-Key": API_KEY}
            created = client.post(
                "/api/v1/scans",
                headers=auth,
                json={"target": "127.0.0.1", "ports": [443]},
            )
            assert created.status_code == 202
            scan_id = created.json()["id"]
            for _ in range(50):
                if client.get(f"/api/v1/scans/{scan_id}", headers=auth).json()["status"] == "running":
                    break
                time.sleep(0.01)

            cancelled = client.delete(f"/api/v1/scans/{scan_id}", headers=auth)
            assert cancelled.status_code == 200
            assert cancelled.json()["status"] == "cancelled"
            release.set()
            time.sleep(0.05)
            stored = client.get(f"/api/v1/scans/{scan_id}", headers=auth).json()
            assert stored["status"] == "cancelled"
            assert stored["findings"] == []
    finally:
        release.set()


def test_inventory_context_risk_and_exports_are_available(tmp_path: Path) -> None:
    class Runner:
        def run(self, addresses, ports, service_detection, port_profile="custom"):
            return ScanOutput(
                hosts=({"ip": addresses[0], "hostname": "localhost", "state": "up"},),
                findings=(_finding(3389, service="ms-wbt-server", product="RDP"),),
            )

    with TestClient(create_app(_settings(tmp_path), Runner())) as client:
        auth = {"X-API-Key": API_KEY}
        created = client.post(
            "/api/v1/scans", headers=auth, json={"target": "127.0.0.1", "ports": [3389]}
        )
        for _ in range(50):
            if client.get(f"/api/v1/scans/{created.json()['id']}", headers=auth).json()["status"] == "completed":
                break
            time.sleep(0.01)

        updated = client.put(
            "/api/v1/assets/127.0.0.1",
            headers=auth,
            json={
                "display_name": "Servidor financeiro",
                "owner": "Infraestrutura",
                "environment": "production",
                "criticality": "critical",
                "tags": ["pci", "erp"],
                "notes": "Ativo autorizado",
            },
        )
        assert updated.status_code == 200
        inventory = client.get("/api/v1/inventory", headers=auth).json()
        assert inventory[0]["display_name"] == "Servidor financeiro"
        assert inventory[0]["open_ports"] == [3389]
        assert inventory[0]["risk_level"] == "critical"
        assert inventory[0]["tags"] == ["erp", "pci"]

        summary = client.get("/api/v1/reports/summary", headers=auth)
        assert summary.status_code == 200
        assert summary.json()["inventory"][0]["ip"] == "127.0.0.1"
        exported = client.get("/api/v1/exports/assets.csv", headers=auth)
        assert exported.status_code == 200
        assert exported.headers["content-type"].startswith("text/csv")
        assert "Servidor financeiro" in exported.text


def test_change_detection_covers_closed_ports_services_dns_and_tls(tmp_path: Path) -> None:
    database = Database(tmp_path / "changes.db")
    database.initialize()

    baseline = database.create_scan("127.0.0.1", ("127.0.0.1",), (443, 8443), True)
    database.complete_scan(baseline["id"], (), (_finding(443), _finding(8443, product="old")))
    changed = database.create_scan("127.0.0.1", ("127.0.0.1",), (443, 8443), True)
    database.complete_scan(changed["id"], (), (_finding(443, product="new"),))

    first_dns = database.create_discovery("example.com")
    database.complete_discovery(first_dns["id"], ("www.example.com",))
    second_dns = database.create_discovery("example.com")
    database.complete_discovery(second_dns["id"], ("www.example.com", "api.example.com"))

    safe_tls = {
        "ip": "127.0.0.1",
        "scheme": "https",
        "port": 443,
        "status_code": 200,
        "tls_days_remaining": 45,
        "error": "",
    }
    database.record_web_observations("example.com", (safe_tls,), tls_warning_days=30)
    database.record_web_observations(
        "example.com", ({**safe_tls, "tls_days_remaining": 20},), tls_warning_days=30
    )

    kinds = {item["kind"] for item in database.list_alerts(limit=20)}
    assert {"closed_port", "service_changed", "new_subdomain", "tls_expiring"} <= kinds


def test_password_user_can_list_and_revoke_own_sessions(tmp_path: Path) -> None:
    with TestClient(create_app(_settings(tmp_path))) as client:
        signed_in = client.post(
            "/api/v1/auth/login",
            json={"username": "admin", "password": "correct-horse-battery-staple"},
        )
        csrf = signed_in.json()["csrf_token"]
        sessions = client.get("/api/v1/sessions")
        assert sessions.status_code == 200
        assert sessions.json()[0]["current"] is True

        revoked = client.delete(
            f"/api/v1/sessions/{sessions.json()[0]['id']}",
            headers={"X-CSRF-Token": csrf},
        )
        assert revoked.status_code == 204
        assert client.get("/api/v1/session").status_code == 401


def test_retention_preview_and_prune_are_explicit(tmp_path: Path) -> None:
    database = Database(tmp_path / "retention.db")
    database.initialize()
    scan = database.create_scan("127.0.0.1", ("127.0.0.1",), (443,), False)
    database.complete_scan(scan["id"], (), (_finding(),))

    with database.connect() as connection:
        connection.execute(
            "UPDATE scans SET completed_at='2020-01-01T00:00:00+00:00', created_at='2020-01-01T00:00:00+00:00'"
        )

    preview = database.prune_history(older_than_days=30, dry_run=True)
    assert preview["scans"] == 1
    assert database.get_scan(scan["id"]) is not None
    removed = database.prune_history(older_than_days=30, dry_run=False)
    assert removed["scans"] == 1
    assert database.get_scan(scan["id"]) is None


def test_printable_report_requires_session_and_renders_authenticated_data(tmp_path: Path) -> None:
    with TestClient(create_app(_settings(tmp_path))) as client:
        anonymous = client.get("/report", follow_redirects=False)
        assert anonymous.status_code == 303
        assert anonymous.headers["location"] == "/login"

        signed_in = client.post(
            "/api/v1/auth/login",
            json={"username": "admin", "password": "correct-horse-battery-staple"},
        )
        assert signed_in.status_code == 200
        report = client.get("/report")
        assert report.status_code == 200
        assert "Resumo da superfície de ataque" in report.text
        assert "Organização padrão" in report.text
        assert 'src="/static/report.js?v=1.9.1"' in report.text


def test_exports_neutralize_spreadsheet_formulas_and_escape_report_html() -> None:
    inventory = [{
        "ip": "127.0.0.1",
        "hostname": "localhost",
        "display_name": '=HYPERLINK("https://invalid.example")',
        "owner": "<script>alert(1)</script>",
        "environment": "production",
        "criticality": "high",
        "risk_level": "high",
        "risk_score": 70,
        "open_ports": [443],
        "services": ["https"],
        "tags": ["web"],
        "last_observed_at": "2026-10-07T00:00:00+00:00",
    }]
    exported = assets_csv(inventory)
    assert "'=HYPERLINK" in exported

    rendered = printable_report({
        "generated_at": "2026-10-07T00:00:00+00:00",
        "tenant": {"name": "<b>Cliente</b>"},
        "overview": {"assets": 1, "open_ports": 1, "scans": 1, "unacknowledged_alerts": 0},
        "inventory": inventory,
        "alerts": [],
    })
    assert "<script>alert(1)</script>" not in rendered
    assert "&lt;script&gt;alert(1)&lt;/script&gt;" in rendered
    assert "&lt;b&gt;Cliente&lt;/b&gt;" in rendered
