from __future__ import annotations

from fastapi.testclient import TestClient

from conftest import wait_for_scan


def _create_tenant(
    client: TestClient,
    auth: dict[str, str],
    *,
    slug: str,
    network: str,
) -> dict:
    response = client.post(
        "/api/v1/tenants",
        headers=auth,
        json={
            "slug": slug,
            "name": f"Cliente {slug.upper()}",
            "allowed_networks": [network],
            "allowed_hosts": [],
        },
    )
    assert response.status_code == 201
    return response.json()


def _create_tenant_key(
    client: TestClient,
    auth: dict[str, str],
    *,
    tenant_id: str,
    name: str,
    role: str = "admin",
) -> dict:
    response = client.post(
        "/api/v1/api-keys",
        headers=auth,
        json={
            "name": name,
            "role": role,
            "tenant_id": tenant_id,
            "expires_in_days": 90,
        },
    )
    assert response.status_code == 201
    return response.json()


def test_tenant_data_and_scope_are_isolated(client: TestClient, auth: dict[str, str]) -> None:
    tenant_a = _create_tenant(client, auth, slug="acme", network="127.0.0.0/8")
    tenant_b = _create_tenant(client, auth, slug="beta", network="10.20.0.0/16")
    key_a = _create_tenant_key(client, auth, tenant_id=tenant_a["id"], name="Acme admin")
    key_b = _create_tenant_key(client, auth, tenant_id=tenant_b["id"], name="Beta admin")
    auth_a = {"X-API-Key": key_a["api_key"]}
    auth_b = {"X-API-Key": key_b["api_key"]}

    session_a = client.get("/api/v1/session", headers=auth_a)
    assert session_a.status_code == 200
    assert session_a.json()["tenant"] == {"id": tenant_a["id"], "name": "Cliente ACME"}
    assert session_a.json()["system_admin"] is False

    created_a = client.post(
        "/api/v1/scans",
        headers=auth_a,
        json={"target": "127.0.0.1", "ports": [443]},
    )
    assert created_a.status_code == 202
    scan_a = wait_for_scan(client, created_a.json()["id"], auth_a)
    assert scan_a["status"] == "completed"

    created_b = client.post(
        "/api/v1/scans",
        headers=auth_b,
        json={"target": "10.20.1.10", "ports": [8443]},
    )
    assert created_b.status_code == 202
    scan_b = wait_for_scan(client, created_b.json()["id"], auth_b)
    assert scan_b["status"] == "completed"

    assert client.post(
        "/api/v1/scans",
        headers=auth_b,
        json={"target": "127.0.0.1", "ports": [80]},
    ).status_code == 403
    assert client.get(f"/api/v1/scans/{scan_b['id']}", headers=auth_a).status_code == 404
    assert client.get(f"/api/v1/scans/{scan_a['id']}", headers=auth_b).status_code == 404
    assert {item["id"] for item in client.get("/api/v1/scans", headers=auth_a).json()} == {scan_a["id"]}
    assert {item["id"] for item in client.get("/api/v1/scans", headers=auth_b).json()} == {scan_b["id"]}
    assert {item["ip"] for item in client.get("/api/v1/assets", headers=auth_a).json()} == {"127.0.0.1"}
    assert {item["ip"] for item in client.get("/api/v1/assets", headers=auth_b).json()} == {"10.20.1.10"}


def test_tenant_admin_cannot_cross_administrative_boundary(
    client: TestClient, auth: dict[str, str]
) -> None:
    tenant_a = _create_tenant(client, auth, slug="alpha", network="127.0.0.0/8")
    tenant_b = _create_tenant(client, auth, slug="bravo", network="10.20.0.0/16")
    key_a = _create_tenant_key(client, auth, tenant_id=tenant_a["id"], name="Alpha admin")
    auth_a = {"X-API-Key": key_a["api_key"]}

    assert client.get("/api/v1/tenants", headers=auth_a).status_code == 403
    forbidden = client.post(
        "/api/v1/api-keys",
        headers=auth_a,
        json={
            "name": "Cross tenant",
            "role": "viewer",
            "tenant_id": tenant_b["id"],
            "expires_in_days": 30,
        },
    )
    assert forbidden.status_code == 403

    local = client.post(
        "/api/v1/api-keys",
        headers=auth_a,
        json={"name": "Alpha viewer", "role": "viewer", "expires_in_days": 30},
    )
    assert local.status_code == 201
    listed = client.get("/api/v1/api-keys", headers=auth_a)
    assert listed.status_code == 200
    assert {item["tenant_id"] for item in listed.json()} == {tenant_a["id"]}
    assert {item["name"] for item in listed.json()} == {"Alpha admin", "Alpha viewer"}

    tenants = client.get("/api/v1/tenants", headers=auth)
    assert tenants.status_code == 200
    assert {item["slug"] for item in tenants.json()} >= {"default", "alpha", "bravo"}


def test_discoveries_web_inventory_and_monitors_are_tenant_scoped(
    client: TestClient, auth: dict[str, str]
) -> None:
    tenant_a = _create_tenant(client, auth, slug="north", network="127.0.0.0/8")
    tenant_b = _create_tenant(client, auth, slug="south", network="10.20.0.0/16")
    key_a = _create_tenant_key(client, auth, tenant_id=tenant_a["id"], name="North admin")
    key_b = _create_tenant_key(client, auth, tenant_id=tenant_b["id"], name="South admin")
    auth_a = {"X-API-Key": key_a["api_key"]}
    auth_b = {"X-API-Key": key_b["api_key"]}
    database = client.app.state.database

    discovery_a = database.create_discovery("north.example", tenant_id=tenant_a["id"])
    discovery_b = database.create_discovery("south.example", tenant_id=tenant_b["id"])
    database.complete_discovery(discovery_a["id"], ("api.north.example",))
    database.complete_discovery(discovery_b["id"], ("api.south.example",))
    observation = {
        "ip": "127.0.0.1",
        "scheme": "https",
        "port": 443,
        "status_code": 200,
        "title": "North",
        "server": "nginx",
        "content_type": "text/html",
        "location": "",
        "tls_subject": "north.example",
        "tls_issuer": "Test CA",
        "tls_not_after": None,
        "tls_days_remaining": None,
        "error": "",
    }
    database.record_web_observations("north.example", (observation,), tenant_a["id"])
    database.record_web_observations(
        "south.example",
        ({**observation, "ip": "10.20.1.1", "title": "South"},),
        tenant_b["id"],
    )
    database.create_monitor("North", "127.0.0.1", (443,), False, 1440, tenant_id=tenant_a["id"])
    database.create_monitor("South", "10.20.1.1", (443,), False, 1440, tenant_id=tenant_b["id"])

    assert [item["domain"] for item in client.get("/api/v1/discoveries", headers=auth_a).json()] == [
        "north.example"
    ]
    assert client.get(f"/api/v1/discoveries/{discovery_b['id']}", headers=auth_a).status_code == 404
    assert [item["target"] for item in client.get("/api/v1/web-observations", headers=auth_a).json()] == [
        "north.example"
    ]
    assert [item["name"] for item in client.get("/api/v1/monitors", headers=auth_b).json()] == ["South"]
    assert client.get("/api/v1/overview", headers=auth_a).json()["web_endpoints"] == 1
    assert client.get("/api/v1/overview", headers=auth_b).json()["web_endpoints"] == 1


def test_inventory_reports_and_maintenance_preserve_tenant_and_role_boundaries(
    client: TestClient, auth: dict[str, str]
) -> None:
    tenant_a = _create_tenant(client, auth, slug="red", network="127.0.0.0/8")
    tenant_b = _create_tenant(client, auth, slug="blue", network="10.20.0.0/16")
    admin_a = _create_tenant_key(client, auth, tenant_id=tenant_a["id"], name="Red admin")
    admin_b = _create_tenant_key(client, auth, tenant_id=tenant_b["id"], name="Blue admin")
    viewer_a = _create_tenant_key(
        client,
        auth,
        tenant_id=tenant_a["id"],
        name="Red viewer",
        role="viewer",
    )
    auth_a = {"X-API-Key": admin_a["api_key"]}
    auth_b = {"X-API-Key": admin_b["api_key"]}
    auth_viewer_a = {"X-API-Key": viewer_a["api_key"]}

    scan_a = client.post(
        "/api/v1/scans", headers=auth_a, json={"target": "127.0.0.1", "ports": [443]}
    )
    scan_b = client.post(
        "/api/v1/scans", headers=auth_b, json={"target": "10.20.1.10", "ports": [8443]}
    )
    assert scan_a.status_code == scan_b.status_code == 202
    assert wait_for_scan(client, scan_a.json()["id"], auth_a)["status"] == "completed"
    assert wait_for_scan(client, scan_b.json()["id"], auth_b)["status"] == "completed"

    context_a = {
        "display_name": "Portal Red",
        "owner": "Equipe Red",
        "environment": "production",
        "criticality": "high",
        "tags": ["internet"],
        "notes": "Contexto exclusivo da Red",
    }
    context_b = {
        "display_name": "Portal Blue",
        "owner": "Equipe Blue",
        "environment": "staging",
        "criticality": "medium",
        "tags": ["internal"],
        "notes": "Contexto exclusivo da Blue",
    }
    assert client.put("/api/v1/assets/127.0.0.1", headers=auth_a, json=context_a).status_code == 200
    assert client.put("/api/v1/assets/10.20.1.10", headers=auth_b, json=context_b).status_code == 200

    inventory_a = client.get("/api/v1/inventory", headers=auth_a).json()
    report_a = client.get("/api/v1/reports/summary", headers=auth_a).json()
    export_a = client.get("/api/v1/exports/assets.csv", headers=auth_a).text
    assert {item["ip"] for item in inventory_a} == {"127.0.0.1"}
    assert {item["display_name"] for item in report_a["inventory"]} == {"Portal Red"}
    assert "Portal Red" in export_a
    assert "Portal Blue" not in export_a

    assert client.put(
        "/api/v1/assets/10.20.1.10", headers=auth_a, json=context_a
    ).status_code == 404
    assert client.delete(
        f"/api/v1/scans/{scan_b.json()['id']}", headers=auth_a
    ).status_code == 404
    assert client.put(
        "/api/v1/assets/127.0.0.1", headers=auth_viewer_a, json=context_a
    ).status_code == 403
    assert client.post(
        "/api/v1/maintenance/retention",
        headers=auth_viewer_a,
        json={"older_than_days": 365, "dry_run": True},
    ).status_code == 403
    assert client.post(
        "/api/v1/maintenance/retention",
        headers=auth_a,
        json={"older_than_days": 365, "dry_run": True},
    ).status_code == 200
    assert client.get("/api/v1/sessions", headers=auth_a).status_code == 400
