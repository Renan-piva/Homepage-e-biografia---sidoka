from __future__ import annotations

import sqlite3

from fastapi.testclient import TestClient


def _create_key(client: TestClient, auth: dict[str, str], name: str, role: str) -> dict:
    response = client.post(
        "/api/v1/api-keys",
        headers=auth,
        json={"name": name, "role": role, "expires_in_days": 90},
    )
    assert response.status_code == 201
    return response.json()


def test_managed_key_is_shown_once_stored_as_hash_and_can_be_revoked(
    client: TestClient, auth: dict[str, str], settings
) -> None:
    created = _create_key(client, auth, "automation", "operator")
    token = created["api_key"]
    assert token.startswith("agk_")
    managed_auth = {"X-API-Key": token}

    session = client.get("/api/v1/session", headers=managed_auth)
    assert session.status_code == 200
    assert session.json()["role"] == "operator"
    assert client.post(
        "/api/v1/scans", headers=managed_auth, json={"target": "127.0.0.1", "ports": [443]}
    ).status_code == 202
    assert client.get("/api/v1/api-keys", headers=managed_auth).status_code == 403

    listed = client.get("/api/v1/api-keys", headers=auth).json()
    managed = next(item for item in listed if item["id"] == created["id"])
    assert "api_key" not in managed
    assert "key_hash" not in managed
    assert managed["status"] == "active"

    connection = sqlite3.connect(settings.database_path)
    try:
        stored_hash = connection.execute("SELECT key_hash FROM api_keys WHERE id=?", (created["id"],)).fetchone()[0]
    finally:
        connection.close()
    assert token not in settings.database_path.read_bytes().decode("latin-1")
    assert stored_hash != token

    assert client.delete(f"/api/v1/api-keys/{created['id']}", headers=auth).status_code == 204
    assert client.get("/api/v1/session", headers=managed_auth).status_code == 401


def test_viewer_is_read_only(client: TestClient, auth: dict[str, str]) -> None:
    created = _create_key(client, auth, "dashboard", "viewer")
    viewer_auth = {"X-API-Key": created["api_key"]}

    assert client.get("/api/v1/overview", headers=viewer_auth).status_code == 200
    assert client.post(
        "/api/v1/scans", headers=viewer_auth, json={"target": "127.0.0.1", "ports": [80]}
    ).status_code == 403


def test_rotation_invalidates_old_secret_and_audits_key_lifecycle(
    client: TestClient, auth: dict[str, str]
) -> None:
    created = _create_key(client, auth, "integration", "admin")
    old_auth = {"X-API-Key": created["api_key"]}

    rotated_response = client.post(
        f"/api/v1/api-keys/{created['id']}/rotate",
        headers=old_auth,
        json={"expires_in_days": 30},
    )
    assert rotated_response.status_code == 201
    rotated = rotated_response.json()
    new_auth = {"X-API-Key": rotated["api_key"]}
    assert rotated["id"] != created["id"]
    assert client.get("/api/v1/session", headers=old_auth).status_code == 401
    assert client.get("/api/v1/session", headers=new_auth).status_code == 200

    events = client.get("/api/v1/security-events", headers=new_auth).json()
    actions = {event["action"] for event in events}
    assert {"api_key.created", "api_key.rotated"} <= actions


def test_bootstrap_key_cannot_be_revoked_or_rotated(client: TestClient, auth: dict[str, str]) -> None:
    assert client.delete("/api/v1/api-keys/bootstrap", headers=auth).status_code == 409
    assert client.post(
        "/api/v1/api-keys/bootstrap/rotate", headers=auth, json={"expires_in_days": 30}
    ).status_code == 409


def test_expired_managed_key_is_rejected_and_reported(client: TestClient, auth: dict[str, str]) -> None:
    manager = client.app.state.api_key_manager
    token, prefix, key_hash = manager._new_secret()
    client.app.state.database.create_api_key(
        key_id="expired-test-key",
        name="Expired integration",
        prefix=prefix,
        key_hash=key_hash,
        role="viewer",
        expires_at="2000-01-01T00:00:00+00:00",
        actor_id="bootstrap",
        actor_name="Bootstrap do ambiente",
    )

    assert client.get("/api/v1/session", headers={"X-API-Key": token}).status_code == 401
    listed = client.get("/api/v1/api-keys", headers=auth).json()
    expired = next(item for item in listed if item["id"] == "expired-test-key")
    assert expired["status"] == "expired"
