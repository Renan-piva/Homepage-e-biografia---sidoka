from __future__ import annotations

import threading
import time
from dataclasses import replace

from fastapi.testclient import TestClient

from conftest import FakeDiscoveryRunner, FakeRunner, FakeWebProbeRunner, wait_for_scan


def test_health_is_public_but_data_requires_api_key(client: TestClient) -> None:
    assert client.get("/health").json() == {"status": "ok"}
    assert client.get("/api/v1/overview").status_code == 401
    assert client.get("/api/v1/overview", headers={"X-API-Key": "wrong"}).status_code == 401


def test_scan_runs_through_public_api_and_persists_findings(
    client: TestClient, auth: dict[str, str], fake_runner: FakeRunner
) -> None:
    response = client.post(
        "/api/v1/scans",
        headers=auth,
        json={"target": "10.20.30.40", "ports": [443, 22], "service_detection": False},
    )
    assert response.status_code == 202
    scan = wait_for_scan(client, response.json()["id"], auth)
    assert scan["status"] == "completed"
    assert scan["resolved_targets"] == ["10.20.30.40"]
    assert scan["findings"][0]["port"] == 22
    assert fake_runner.calls == [(('10.20.30.40',), (22, 443), False, "custom")]

    assets = client.get("/api/v1/assets", headers=auth).json()
    assert assets[0]["ip"] == "10.20.30.40"
    assert assets[0]["service"] == "ssh"


def test_out_of_scope_and_malformed_targets_never_create_scan(client: TestClient, auth: dict[str, str]) -> None:
    for target in ("8.8.8.8", "127.0.0.1;id", " https://127.0.0.1"):
        response = client.post("/api/v1/scans", headers=auth, json={"target": target, "ports": [80]})
        assert response.status_code == 403
    assert client.get("/api/v1/scans", headers=auth).json() == []


def test_scan_rate_limit_is_enforced(client: TestClient, auth: dict[str, str]) -> None:
    statuses = [
        client.post("/api/v1/scans", headers=auth, json={"target": "127.0.0.1", "ports": [port]}).status_code
        for port in (20, 21, 22, 23)
    ]
    assert statuses == [202, 202, 202, 429]


def test_runner_failure_is_recorded(settings, auth: dict[str, str]) -> None:
    from asm_guardian.main import create_app

    with TestClient(create_app(settings, FakeRunner(fail=True))) as test_client:
        response = test_client.post("/api/v1/scans", headers=auth, json={"target": "127.0.0.1", "ports": [80]})
        scan = wait_for_scan(test_client, response.json()["id"], auth)
        assert scan["status"] == "failed"
        assert "controlled runner failure" in scan["error"]


def test_monitor_crud_and_validation(client: TestClient, auth: dict[str, str]) -> None:
    body = {"name": "Internal gateway", "target": "10.20.1.1", "ports": [80, 443], "interval_minutes": 60}
    response = client.post("/api/v1/monitors", headers=auth, json=body)
    assert response.status_code == 201
    monitor = response.json()
    assert monitor["enabled"] is True
    assert client.get("/api/v1/monitors", headers=auth).json()[0]["target"] == "10.20.1.1"
    assert client.delete(f"/api/v1/monitors/{monitor['id']}", headers=auth).status_code == 204
    assert client.get("/api/v1/monitors", headers=auth).json() == []


def test_monitor_creation_rate_limit_is_enforced(client: TestClient, auth: dict[str, str]) -> None:
    statuses = []
    for index in range(4):
        response = client.post(
            "/api/v1/monitors",
            headers=auth,
            json={"name": f"Monitor {index}", "target": "127.0.0.1", "ports": [443], "interval_minutes": 60},
        )
        statuses.append(response.status_code)
    assert statuses == [201, 201, 201, 429]


def test_security_headers_allow_configured_embedding(client: TestClient) -> None:
    response = client.get("/")
    assert response.status_code == 200
    assert "frame-ancestors 'self'" in response.headers["content-security-policy"]
    assert response.headers["x-content-type-options"] == "nosniff"

    api_response = client.get("/api/v1/overview", headers={"X-API-Key": "test-api-key-at-least-16"})
    assert api_response.headers["cache-control"] == "no-store"


def test_scan_backlog_has_a_global_capacity_limit(settings, auth: dict[str, str]) -> None:
    from asm_guardian.main import create_app

    release = threading.Event()

    class BlockingRunner(FakeRunner):
        def run(
            self,
            addresses: tuple[str, ...],
            ports: tuple[int, ...],
            service_detection: bool,
            port_profile: str = "custom",
        ):
            release.wait(timeout=5)
            return super().run(addresses, ports, service_detection, port_profile)

    limited = replace(settings, max_concurrent_scans=1, max_pending_scans=2)
    try:
        with TestClient(create_app(limited, BlockingRunner())) as test_client:
            first = test_client.post(
                "/api/v1/scans", headers=auth, json={"target": "127.0.0.1", "ports": [80]}
            )
            second = test_client.post(
                "/api/v1/scans", headers=auth, json={"target": "127.0.0.1", "ports": [443]}
            )
            rejected = test_client.post(
                "/api/v1/scans", headers=auth, json={"target": "127.0.0.1", "ports": [8080]}
            )

            assert first.status_code == 202
            assert second.status_code == 202
            assert rejected.status_code == 503
            assert rejected.headers["retry-after"] == "5"
            release.set()
    finally:
        release.set()


def test_all_tcp_scan_uses_full_profile_without_materializing_65535_ports(
    client: TestClient, auth: dict[str, str], fake_runner: FakeRunner
) -> None:
    response = client.post(
        "/api/v1/scans",
        headers=auth,
        json={"target": "127.0.0.1", "port_profile": "all-tcp", "service_detection": False},
    )
    assert response.status_code == 202
    scan = wait_for_scan(client, response.json()["id"], auth)
    assert scan["port_profile"] == "all-tcp"
    assert scan["port_count"] == 65535
    assert scan["ports"] == []
    assert fake_runner.calls[-1] == (("127.0.0.1",), (), False, "all-tcp")


def test_controlled_dns_discovery_is_scoped_persisted_and_rate_limited(settings, auth: dict[str, str]) -> None:
    from asm_guardian.main import create_app

    configured = replace(settings, allowed_hosts=("example.com", "*.example.com"), discovery_rate_limit=2)
    discovery_runner = FakeDiscoveryRunner()
    with TestClient(create_app(configured, FakeRunner(), discovery_runner)) as test_client:
        first = test_client.post("/api/v1/discoveries", headers=auth, json={"domain": "example.com"})
        second = test_client.post("/api/v1/discoveries", headers=auth, json={"domain": "example.com"})
        limited = test_client.post("/api/v1/discoveries", headers=auth, json={"domain": "example.com"})
        denied = test_client.post("/api/v1/discoveries", headers=auth, json={"domain": "outside.example"})

        assert first.status_code == second.status_code == 202
        assert limited.status_code == 429
        assert denied.status_code == 403
        for _ in range(50):
            history = test_client.get("/api/v1/discoveries", headers=auth).json()
            if history and all(item["status"] == "completed" for item in history):
                break
            time.sleep(0.01)
        else:
            raise AssertionError("discovery did not finish")

        hosts = test_client.get("/api/v1/discovered-hosts", headers=auth).json()
        assert {item["hostname"] for item in hosts} == {"api.example.com", "www.example.com"}
        assert discovery_runner.calls == ["example.com", "example.com"]


def test_passive_subfinder_discovery_uses_selected_engine(settings, auth: dict[str, str]) -> None:
    from asm_guardian.main import create_app

    configured = replace(settings, allowed_hosts=("example.com", "*.example.com"))
    gobuster = FakeDiscoveryRunner()
    subfinder = FakeDiscoveryRunner()
    with TestClient(
        create_app(configured, FakeRunner(), gobuster, subfinder_runner=subfinder, web_probe_runner=FakeWebProbeRunner())
    ) as test_client:
        response = test_client.post(
            "/api/v1/discoveries",
            headers=auth,
            json={"domain": "example.com", "engine": "subfinder"},
        )
        assert response.status_code == 202
        for _ in range(50):
            discovery = test_client.get(f"/api/v1/discoveries/{response.json()['id']}", headers=auth).json()
            if discovery["status"] == "completed":
                break
            time.sleep(0.01)
        assert discovery["engine"] == "subfinder"
        assert gobuster.calls == []
        assert subfinder.calls == ["example.com"]


def test_web_probe_is_scoped_rate_limited_and_persisted(
    settings, auth: dict[str, str], fake_web_probe_runner: FakeWebProbeRunner
) -> None:
    from asm_guardian.main import create_app

    with TestClient(create_app(settings, FakeRunner(), FakeDiscoveryRunner(), web_probe_runner=fake_web_probe_runner)) as test_client:
        response = test_client.post("/api/v1/web-probes", headers=auth, json={"target": "127.0.0.1"})
        denied = test_client.post("/api/v1/web-probes", headers=auth, json={"target": "192.0.2.10"})

        assert response.status_code == 200
        assert denied.status_code == 403
        assert fake_web_probe_runner.calls == [("127.0.0.1", ("127.0.0.1",))]
        history = test_client.get("/api/v1/web-observations", headers=auth).json()
        assert history[0]["title"] == "Portal autorizado"
        assert history[0]["tls_issuer"] == "Test CA"


def test_alert_api_allows_viewing_and_acknowledgement(client: TestClient, auth: dict[str, str]) -> None:
    database = client.app.state.database
    first = database.create_scan("10.20.1.5", ("10.20.1.5",), (443,), False)
    database.complete_scan(first["id"], (), ())
    second = database.create_scan("10.20.1.5", ("10.20.1.5",), (443,), False)
    finding = {
        "ip": "10.20.1.5", "hostname": "", "port": 443, "protocol": "tcp", "state": "open",
        "service": "https", "product": "", "version": "",
    }
    database.complete_scan(second["id"], (), (finding,))

    alerts = client.get("/api/v1/alerts", headers=auth).json()
    assert len(alerts) == 1
    response = client.post(f"/api/v1/alerts/{alerts[0]['id']}/acknowledge", headers=auth)
    assert response.status_code == 200
    assert response.json()["acknowledged_at"] is not None
