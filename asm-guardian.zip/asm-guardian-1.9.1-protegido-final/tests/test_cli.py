from __future__ import annotations

import subprocess
import tomllib
from pathlib import Path

from asm_guardian.cli import load_env_file, main
from asm_guardian.database import Database


def write_environment(path: Path, database_path: Path, networks: str = "127.0.0.0/8,::1/128") -> None:
    path.write_text(
        "\n".join(
            (
                "ASM_API_KEY=test-api-key-at-least-16",
                "ASM_ADMIN_USERNAME=admin",
                "ASM_ADMIN_PASSWORD=test-admin-password-123",
                f"ASM_DATABASE_PATH={database_path}",
                f"ASM_ALLOWED_NETWORKS={networks}",
                "ASM_ALLOWED_HOSTS=",
                "ASM_FRAME_ANCESTORS='self'",
            )
        ),
        encoding="utf-8",
    )


def test_project_registers_the_expected_console_command() -> None:
    data = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    assert data["project"]["scripts"]["asm-guardian"] == "asm_guardian.cli:main"


def test_check_validates_configuration_and_nmap_without_scanning(tmp_path, monkeypatch, capsys) -> None:
    env_file = tmp_path / "asm-guardian.env"
    write_environment(env_file, tmp_path / "asm.db")
    calls: list[list[str]] = []

    monkeypatch.setattr(
        "asm_guardian.cli.shutil.which",
        lambda binary, **_kwargs: f"/usr/bin/{binary}",
    )

    def fake_run(command, **_options):
        calls.append(command)
        return subprocess.CompletedProcess(command, 0, stdout="Nmap 7.95", stderr="")

    monkeypatch.setattr("asm_guardian.cli.subprocess.run", fake_run)

    assert main(["--env-file", str(env_file), "check"]) == 0
    assert calls == [["/usr/bin/nmap", "--version"]]
    output = capsys.readouterr()
    assert "completed successfully" in output.out
    assert "Gobuster executable" in output.out
    assert "test-api-key" not in output.out


def test_check_rejects_an_invalid_allowlist_before_running_nmap(tmp_path, monkeypatch, capsys) -> None:
    env_file = tmp_path / "asm-guardian.env"
    write_environment(env_file, tmp_path / "asm.db", networks="127.0.0.1/8")
    called = False

    def fake_run(*_args, **_kwargs):
        nonlocal called
        called = True

    monkeypatch.setattr("asm_guardian.cli.subprocess.run", fake_run)

    assert main(["--env-file", str(env_file), "check"]) == 1
    assert called is False
    assert "Invalid allowlist network" in capsys.readouterr().err


def test_check_reports_a_missing_environment_file_without_traceback(tmp_path, capsys) -> None:
    assert main(["--env-file", str(tmp_path / "missing.env"), "check"]) == 1
    error = capsys.readouterr().err
    assert "cannot read environment file" in error
    assert "Traceback" not in error


def test_environment_file_parser_does_not_expand_shell_expressions(tmp_path) -> None:
    env_file = tmp_path / "asm-guardian.env"
    env_file.write_text("ASM_API_KEY='literal-$(not-executed)'\n", encoding="utf-8")
    assert load_env_file(env_file)["ASM_API_KEY"] == "literal-$(not-executed)"


def test_backup_creates_a_consistent_copy_and_never_overwrites(tmp_path, capsys) -> None:
    database_path = tmp_path / "asm.db"
    database = Database(database_path)
    database.initialize()
    database.create_scan("127.0.0.1", ("127.0.0.1",), (443,), False)
    env_file = tmp_path / "asm-guardian.env"
    write_environment(env_file, database_path)
    backup_path = tmp_path / "asm-backup.db"

    assert main(["--env-file", str(env_file), "backup", "--output", str(backup_path)]) == 0
    assert backup_path.is_file()
    assert len(Database(backup_path).list_scans()) == 1
    assert main(["--env-file", str(env_file), "backup", "--output", str(backup_path)]) == 1
    assert "already exists" in capsys.readouterr().err
