from __future__ import annotations

import hashlib
import sqlite3
from pathlib import Path

from fastapi.testclient import TestClient

from asm_guardian.config import Settings
from asm_guardian.main import create_app


ADMIN_PASSWORD = "correct-horse-battery-staple"


def authenticated_app(tmp_path: Path, *, login_rate_limit: int = 5) -> tuple[TestClient, Settings]:
    settings = Settings(
        database_path=tmp_path / "auth.db",
        api_key="automation-key-at-least-16",
        admin_username="admin",
        admin_password=ADMIN_PASSWORD,
        allowed_networks=("127.0.0.0/8",),
        request_rate_limit=100,
        login_rate_limit=login_rate_limit,
        scheduler_poll_seconds=60,
    )
    return TestClient(create_app(settings)), settings


def login(client: TestClient, username: str = "admin", password: str = ADMIN_PASSWORD):
    return client.post("/api/v1/auth/login", json={"username": username, "password": password})


def test_dashboard_requires_a_session_and_login_has_a_dedicated_page(tmp_path: Path) -> None:
    client, _settings = authenticated_app(tmp_path)
    with client:
        unauthenticated = client.get("/", follow_redirects=False)
        assert unauthenticated.status_code == 303
        assert unauthenticated.headers["location"] == "/login"

        login_page = client.get("/login", follow_redirects=False)
        assert login_page.status_code == 200
        assert 'id="login-form"' in login_page.text
        assert 'id="username"' in login_page.text
        assert 'id="password"' in login_page.text
        assert 'class="login-atom"' in login_page.text
        assert client.get("/static/index.html").status_code == 404
        assert client.get("/static/login.html").status_code == 404

        assert login(client).status_code == 200
        dashboard = client.get("/", follow_redirects=False)
        assert dashboard.status_code == 200
        assert 'id="login-form"' not in dashboard.text
        assert 'id="session-controls"' in dashboard.text

        authenticated_login_page = client.get("/login", follow_redirects=False)
        assert authenticated_login_page.status_code == 303
        assert authenticated_login_page.headers["location"] == "/"


def test_password_login_uses_hardened_cookie_and_server_side_session(tmp_path: Path) -> None:
    client, settings = authenticated_app(tmp_path)
    with client:
        response = login(client)

        assert response.status_code == 200
        payload = response.json()
        assert payload["username"] == "admin"
        assert payload["role"] == "admin"
        assert payload["kind"] == "user"
        assert len(payload["csrf_token"]) >= 32
        assert "password" not in payload
        cookie = response.headers["set-cookie"]
        assert "asm_guardian_session=" in cookie
        assert "HttpOnly" in cookie
        assert "SameSite=strict" in cookie

        session = client.get("/api/v1/session")
        assert session.status_code == 200
        assert session.json()["username"] == "admin"

        session_token = client.cookies.get("asm_guardian_session")
        connection = sqlite3.connect(settings.database_path)
        try:
            password_hash = connection.execute("SELECT password_hash FROM users WHERE username='admin'").fetchone()[0]
            token_hash, csrf_hash = connection.execute(
                "SELECT token_hash,csrf_hash FROM user_sessions"
            ).fetchone()
        finally:
            connection.close()
        assert password_hash != ADMIN_PASSWORD
        assert password_hash.startswith("scrypt$")
        assert token_hash == hashlib.sha256(session_token.encode()).hexdigest()
        assert token_hash != session_token
        assert csrf_hash == hashlib.sha256(payload["csrf_token"].encode()).hexdigest()
        assert csrf_hash != payload["csrf_token"]


def test_cookie_session_requires_csrf_for_state_changes_and_logout_revokes_it(tmp_path: Path) -> None:
    client, _settings = authenticated_app(tmp_path)
    with client:
        signed_in = login(client)
        csrf = signed_in.json()["csrf_token"]
        scan = {"target": "127.0.0.1", "ports": [80], "port_profile": "custom"}

        assert client.post("/api/v1/scans", json=scan).status_code == 403
        accepted = client.post("/api/v1/scans", json=scan, headers={"X-CSRF-Token": csrf})
        assert accepted.status_code == 202

        logout = client.post("/api/v1/auth/logout", headers={"X-CSRF-Token": csrf})
        assert logout.status_code == 204
        assert client.get("/api/v1/session").status_code == 401


def test_existing_session_can_recover_missing_csrf_and_logout(tmp_path: Path) -> None:
    client, _settings = authenticated_app(tmp_path)
    with client:
        signed_in = login(client)
        original_csrf = signed_in.json()["csrf_token"]
        client.cookies.delete("asm_guardian_csrf")

        assert client.post("/api/v1/auth/logout").status_code == 403

        recovered = client.post("/api/v1/auth/csrf")
        assert recovered.status_code == 200
        replacement_csrf = recovered.json()["csrf_token"]
        assert replacement_csrf != original_csrf
        assert len(replacement_csrf) >= 32
        assert client.cookies.get("asm_guardian_csrf") == replacement_csrf
        csrf_cookie = next(
            value for value in recovered.headers.get_list("set-cookie") if value.startswith("asm_guardian_csrf=")
        )
        assert "SameSite=strict" in csrf_cookie
        assert "HttpOnly" not in csrf_cookie

        assert client.post(
            "/api/v1/auth/logout",
            headers={"X-CSRF-Token": original_csrf},
        ).status_code == 403
        assert client.post(
            "/api/v1/auth/logout",
            headers={"X-CSRF-Token": replacement_csrf},
        ).status_code == 204
        assert client.cookies.get("asm_guardian_csrf") is None


def test_csrf_recovery_requires_a_user_session(tmp_path: Path) -> None:
    client, _settings = authenticated_app(tmp_path)
    with client:
        assert client.post("/api/v1/auth/csrf").status_code == 401
        automated = client.post(
            "/api/v1/auth/csrf",
            headers={"X-API-Key": "automation-key-at-least-16"},
        )
        assert automated.status_code == 400


def test_login_is_rate_limited_and_does_not_reveal_whether_user_exists(tmp_path: Path) -> None:
    client, _settings = authenticated_app(tmp_path, login_rate_limit=2)
    with client:
        first = login(client, "admin", "wrong-password-value")
        second = login(client, "unknown", "wrong-password-value")
        limited = login(client, "admin", ADMIN_PASSWORD)

        assert first.status_code == second.status_code == 401
        assert first.json() == second.json() == {"detail": "Invalid username or password"}
        assert limited.status_code == 429
        assert limited.headers["retry-after"] == "60"


def test_administrator_can_create_user_and_api_key_auth_remains_available(tmp_path: Path) -> None:
    client, _settings = authenticated_app(tmp_path)
    with client:
        signed_in = login(client)
        csrf = signed_in.json()["csrf_token"]
        created = client.post(
            "/api/v1/users",
            headers={"X-CSRF-Token": csrf},
            json={
                "username": "analista",
                "display_name": "Analista SOC",
                "password": "another-correct-password",
                "role": "viewer",
            },
        )
        assert created.status_code == 201
        assert created.json()["username"] == "analista"
        assert "password_hash" not in created.json()

        client.post("/api/v1/auth/logout", headers={"X-CSRF-Token": csrf})
        analyst = login(client, "analista", "another-correct-password")
        assert analyst.status_code == 200
        assert analyst.json()["role"] == "viewer"

        automated = client.get(
            "/api/v1/session",
            headers={"X-API-Key": "automation-key-at-least-16"},
        )
        assert automated.status_code == 200
        assert automated.json()["kind"] == "bootstrap"


def test_user_can_change_password_and_all_existing_sessions_are_revoked(tmp_path: Path) -> None:
    client, _settings = authenticated_app(tmp_path)
    with client:
        signed_in = login(client)
        csrf = signed_in.json()["csrf_token"]

        changed = client.post(
            "/api/v1/users/me/password",
            headers={"X-CSRF-Token": csrf},
            json={
                "current_password": ADMIN_PASSWORD,
                "new_password": "a-new-strong-password-value",
            },
        )
        assert changed.status_code == 204
        assert client.get("/api/v1/session").status_code == 401
        assert login(client, password=ADMIN_PASSWORD).status_code == 401
        assert login(client, password="a-new-strong-password-value").status_code == 200
