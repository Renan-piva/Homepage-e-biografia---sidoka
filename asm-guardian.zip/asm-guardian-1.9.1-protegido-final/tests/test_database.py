from __future__ import annotations

from pathlib import Path
import sqlite3

from asm_guardian.database import Database


def test_database_survives_new_repository_instance(tmp_path: Path) -> None:
    path = tmp_path / "persistent.db"
    first = Database(path)
    first.initialize()
    scan = first.create_scan("127.0.0.1", ("127.0.0.1",), (80,), False)
    first.mark_scan_running(scan["id"])
    first.complete_scan(
        scan["id"],
        ({"ip": "127.0.0.1", "hostname": "localhost", "state": "up"},),
        ({"ip": "127.0.0.1", "hostname": "localhost", "port": 80, "protocol": "tcp", "state": "open", "service": "http", "product": "", "version": ""},),
    )

    reopened = Database(path)
    reopened.initialize()
    stored = reopened.get_scan(scan["id"])
    assert stored is not None
    assert stored["status"] == "completed"
    assert stored["findings"][0]["service"] == "http"


def test_interrupted_scans_are_failed_on_restart(tmp_path: Path) -> None:
    database = Database(tmp_path / "recover.db")
    database.initialize()
    scan = database.create_scan("127.0.0.1", ("127.0.0.1",), (443,), False)
    assert database.recover_interrupted_scans() == 1
    recovered = database.get_scan(scan["id"])
    assert recovered["status"] == "failed"
    assert "restarted" in recovered["error"]


def test_asset_inventory_selects_one_latest_observation_on_timestamp_tie(tmp_path: Path) -> None:
    database = Database(tmp_path / "assets.db")
    database.initialize()
    finding = {
        "ip": "127.0.0.1", "hostname": "localhost", "port": 443, "protocol": "tcp",
        "state": "open", "service": "https", "product": "first", "version": "",
    }
    for product in ("first", "second"):
        scan = database.create_scan("127.0.0.1", ("127.0.0.1",), (443,), False)
        database.mark_scan_running(scan["id"])
        database.complete_scan(scan["id"], (), ({**finding, "product": product},))

    assets = database.list_assets()
    assert len(assets) == 1
    assert assets[0]["product"] == "second"


def test_initialize_migrates_existing_scan_tables_to_port_profiles(tmp_path: Path) -> None:
    path = tmp_path / "legacy.db"
    connection = sqlite3.connect(path)
    connection.executescript(
        """
        CREATE TABLE monitors (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, target TEXT NOT NULL, ports TEXT NOT NULL,
            service_detection INTEGER NOT NULL DEFAULT 0, interval_minutes INTEGER NOT NULL,
            enabled INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL, last_run_at TEXT,
            next_run_at TEXT NOT NULL, last_error TEXT
        );
        CREATE TABLE scans (
            id TEXT PRIMARY KEY, monitor_id TEXT, target TEXT NOT NULL, resolved_targets TEXT NOT NULL,
            ports TEXT NOT NULL, service_detection INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL,
            created_at TEXT NOT NULL, started_at TEXT, completed_at TEXT, error TEXT
        );
        """
    )
    connection.close()

    Database(path).initialize()

    connection = sqlite3.connect(path)
    try:
        scan_columns = {row[1] for row in connection.execute("PRAGMA table_info(scans)")}
        monitor_columns = {row[1] for row in connection.execute("PRAGMA table_info(monitors)")}
    finally:
        connection.close()
    assert "port_profile" in scan_columns
    assert "port_profile" in monitor_columns


def test_initialize_backfills_legacy_rows_into_default_tenant(tmp_path: Path) -> None:
    path = tmp_path / "legacy-tenant.db"
    database = Database(path)
    database.initialize()
    scan = database.create_scan("127.0.0.1", ("127.0.0.1",), (443,), False)

    connection = sqlite3.connect(path)
    try:
        connection.execute("ALTER TABLE scans RENAME TO scans_with_tenant")
        connection.execute(
            """CREATE TABLE scans (
                id TEXT PRIMARY KEY, monitor_id TEXT, target TEXT NOT NULL,
                resolved_targets TEXT NOT NULL, ports TEXT NOT NULL,
                port_profile TEXT NOT NULL DEFAULT 'custom',
                service_detection INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL,
                created_at TEXT NOT NULL, started_at TEXT, completed_at TEXT, error TEXT
            )"""
        )
        connection.execute(
            """INSERT INTO scans
               SELECT id,monitor_id,target,resolved_targets,ports,port_profile,service_detection,
                      status,created_at,started_at,completed_at,error
               FROM scans_with_tenant"""
        )
        connection.execute("DROP TABLE scans_with_tenant")
        connection.commit()
    finally:
        connection.close()

    database.initialize(("127.0.0.0/8",), ())

    connection = sqlite3.connect(path)
    try:
        tenant_id = connection.execute("SELECT tenant_id FROM scans WHERE id=?", (scan["id"],)).fetchone()[0]
        default_tenant = connection.execute("SELECT slug FROM tenants WHERE id='default'").fetchone()[0]
    finally:
        connection.close()
    assert tenant_id == "default"
    assert default_tenant == "default"


def test_initialize_migrates_legacy_alerts_for_extended_change_detection(tmp_path: Path) -> None:
    path = tmp_path / "legacy-alerts.db"
    connection = sqlite3.connect(path)
    connection.execute(
        """CREATE TABLE alerts (
            id TEXT PRIMARY KEY,
            tenant_id TEXT NOT NULL DEFAULT 'default',
            kind TEXT NOT NULL CHECK(kind IN ('new_asset','new_open_port')),
            severity TEXT NOT NULL CHECK(severity IN ('info','low','medium','high')),
            title TEXT NOT NULL,target TEXT NOT NULL,ip TEXT NOT NULL,
            port INTEGER,protocol TEXT,scan_id TEXT NOT NULL,
            created_at TEXT NOT NULL,acknowledged_at TEXT
        )"""
    )
    connection.commit()
    connection.close()

    Database(path).initialize()

    connection = sqlite3.connect(path)
    try:
        sql = connection.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='alerts'"
        ).fetchone()[0]
        columns = {row[1] for row in connection.execute("PRAGMA table_info(alerts)")}
    finally:
        connection.close()
    assert "closed_port" in sql
    assert {"source_type", "source_id"} <= columns


def test_new_ports_create_alerts_only_after_the_first_baseline_scan(tmp_path: Path) -> None:
    database = Database(tmp_path / "alerts.db")
    database.initialize()
    base_finding = {
        "ip": "10.20.1.5", "hostname": "", "port": 443, "protocol": "tcp", "state": "open",
        "service": "https", "product": "", "version": "",
    }

    baseline = database.create_scan("10.20.1.5", ("10.20.1.5",), (443,), False)
    database.mark_scan_running(baseline["id"])
    database.complete_scan(baseline["id"], ({"ip": "10.20.1.5", "hostname": "", "state": "up"},), (base_finding,))
    assert database.list_alerts() == []

    changed = database.create_scan("10.20.1.5", ("10.20.1.5",), (443, 8443), False)
    database.mark_scan_running(changed["id"])
    database.complete_scan(
        changed["id"],
        ({"ip": "10.20.1.5", "hostname": "", "state": "up"},),
        (base_finding, {**base_finding, "port": 8443, "service": "https-alt"}),
    )

    alerts = database.list_alerts()
    assert [(item["kind"], item["port"]) for item in alerts] == [("new_open_port", 8443)]
    assert database.acknowledge_alert(alerts[0]["id"])
    assert database.list_alerts()[0]["acknowledged_at"] is not None


def test_dns_discovery_history_is_persistent_and_deduplicated(tmp_path: Path) -> None:
    database = Database(tmp_path / "discoveries.db")
    database.initialize()
    discovery = database.create_discovery("example.com")
    database.mark_discovery_running(discovery["id"])
    database.complete_discovery(discovery["id"], ("api.example.com", "www.example.com", "api.example.com"))

    reopened = Database(database.path)
    reopened.initialize()
    stored = reopened.get_discovery(discovery["id"])
    assert stored["status"] == "completed"
    assert stored["hostnames"] == ["api.example.com", "www.example.com"]
    assert [item["hostname"] for item in reopened.list_discovered_hosts()] == ["api.example.com", "www.example.com"]


def test_discovery_engine_and_web_observations_are_persistent(tmp_path: Path) -> None:
    database = Database(tmp_path / "surface.db")
    database.initialize()
    discovery = database.create_discovery("example.com", "subfinder")
    database.complete_discovery(discovery["id"], ("api.example.com",))
    database.record_web_observations(
        "api.example.com",
        (
            {
                "ip": "10.20.1.10",
                "scheme": "https",
                "port": 443,
                "status_code": 200,
                "title": "Portal",
                "server": "nginx",
                "content_type": "text/html",
                "location": "",
                "tls_subject": "api.example.com",
                "tls_issuer": "Example CA",
                "tls_not_after": "2030-01-01T00:00:00+00:00",
                "tls_days_remaining": 100,
                "error": "",
            },
        ),
    )

    reopened = Database(database.path)
    reopened.initialize()

    assert reopened.get_discovery(discovery["id"])["engine"] == "subfinder"
    observations = reopened.list_web_observations()
    assert len(observations) == 1
    assert observations[0]["target"] == "api.example.com"
    assert observations[0]["status_code"] == 200
    assert reopened.overview()["web_endpoints"] == 1
