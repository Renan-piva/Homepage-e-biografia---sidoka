from __future__ import annotations

from pathlib import Path

import pytest

from asm_guardian.config import Settings


def base_env(tmp_path: Path) -> dict[str, str]:
    return {
        "ASM_API_KEY": "a-secure-test-key-123456",
        "ASM_DATABASE_PATH": str(tmp_path / "asm.db"),
        "ASM_ALLOWED_NETWORKS": "127.0.0.0/8",
    }


def test_frame_ancestors_normalizes_systemd_quotes_and_https_origins(tmp_path: Path) -> None:
    env = base_env(tmp_path)
    env["ASM_FRAME_ANCESTORS"] = "self,https://soc.example:8443"

    settings = Settings.from_env(env)

    assert settings.frame_ancestors == ("'self'", "https://soc.example:8443")


@pytest.mark.parametrize(
    "value",
    ("*", "http://soc.example", "https://user@soc.example", "https://soc.example/path", "'none',https://soc.example"),
)
def test_frame_ancestors_rejects_unsafe_or_ambiguous_sources(tmp_path: Path, value: str) -> None:
    env = base_env(tmp_path)
    env["ASM_FRAME_ANCESTORS"] = value

    with pytest.raises(ValueError, match="ASM_FRAME_ANCESTORS"):
        Settings.from_env(env)


def test_native_deployment_uses_private_data_permissions_and_umask() -> None:
    project_root = Path(__file__).resolve().parents[1]
    installer = (project_root / "scripts" / "install-ubuntu.sh").read_text(encoding="utf-8")
    service = (project_root / "deploy" / "asm-guardian.service").read_text(encoding="utf-8")

    assert 'install -d -m 0750 -o asmguardian -g asmguardian "${DATA_DIR}"' in installer
    assert "UMask=0077" in service


def test_dashboard_exposes_fixed_profiles_without_dynamic_nmap_flags() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'value="all-tcp"' in page
    assert 'value="top-1000"' in page
    assert "innerHTML" not in script
    assert "sessionStorage.removeItem" in script
    assert 'id="discovery-form"' in page
    assert 'id="alerts"' in page


def test_dashboard_uses_compact_cold_theme_and_exposes_copyable_scan_ids() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    styles = (project_root / "asm_guardian" / "static" / "app.css").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'class="compact-ui performance-ui"' in page
    assert 'id="quick-nav"' in page
    assert "--ice:" in styles
    assert "--indigo:" in styles
    assert ".primary-grid, .discovery-grid, .lower-grid { grid-template-columns: 1fr; }" in styles
    assert "copyScanId" in script
    assert 'actionButton("Copiar ID"' in script
    assert 'id="asset-filter"' in page


def test_dashboard_uses_atom_identity_and_hides_api_key_administration() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    login_page = (project_root / "asm_guardian" / "static" / "login.html").read_text(encoding="utf-8")
    styles = (project_root / "asm_guardian" / "static" / "app.css").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")
    login_script = (project_root / "asm_guardian" / "static" / "login.js").read_text(encoding="utf-8")

    assert 'class="atom-logo"' in page
    assert 'class="hero-atom"' in page
    assert 'class="login-atom"' in login_page
    assert 'class="login-shell"' in login_page
    assert 'id="login-form"' in login_page
    assert 'href="#key-management"' not in page
    assert 'id="key-management"' not in page
    assert "Chaves de API" not in page
    assert 'api("/api/v1/api-keys"' not in script
    assert 'api("/api/v1/security-events' not in script
    assert ".hero-atom" in styles
    assert ".login-atom" in styles
    assert "?v=1.9.1" in page
    assert "?v=1.9.1" in login_page
    assert 'id="username"' not in page
    assert 'id="password"' not in page
    assert 'id="username"' in login_page
    assert 'id="password"' in login_page
    assert 'id="api-key"' not in page
    assert 'id="api-key"' not in login_page
    assert "asm-api-key" not in script
    assert "X-API-Key" not in script
    assert 'fetch("/api/v1/auth/login"' in login_script
    assert 'api("/api/v1/auth/logout"' in script
    assert 'auth-form' not in script
    assert "innerHTML" not in login_script


def test_dashboard_exposes_passive_discovery_and_bounded_web_inventory() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'value="subfinder"' in page
    assert 'id="web-probe-form"' in page
    assert 'id="web-observations-body"' in page
    assert 'api("/api/v1/web-probes"' in script
    assert "follow_redirects" not in script
    assert "Nuclei" not in page


def test_dashboard_emphasizes_open_ports_with_an_abstract_asset_map() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    styles = (project_root / "asm_guardian" / "static" / "app.css").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'id="open-port-map"' in page
    assert 'id="exposure-leader"' in page
    assert "Portas abertas por ativo" in page
    assert 'class="port-legend"' in page
    assert "renderOpenPortMap" in script
    assert "classifyPort" in script
    assert "renderFilteredAssets" in script
    assert "state.assets = assets;" in script
    assert ".port-chip" in styles
    assert ".abstract-field" in styles
    assert "innerHTML" not in script


def test_dashboard_exposes_operational_posture_and_category_filters() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    styles = (project_root / "asm_guardian" / "static" / "app.css").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'id="exposure-command-center"' in page
    assert 'id="environment-posture"' in page
    assert 'id="category-spectrum"' in page
    assert 'id="priority-assets"' in page
    assert 'id="port-filters"' in page
    assert 'id="auth-state"' in page
    assert 'id="session-controls"' in page
    assert 'data-category="remote"' in page
    assert 'aria-live="polite"' in page
    assert "renderExposureCockpit" in script
    assert "renderCategorySpectrum" in script
    assert "renderPriorityAssets" in script
    assert "setPortCategory" in script
    assert 'window.location.replace("/login")' in script
    assert "overview.active_scans" in script
    assert "overview.failed_scans" in script
    assert "overview.web_endpoints" in script
    assert ".exposure-cockpit" in styles
    assert ".spectrum-bar" in styles
    assert ".priority-asset" in styles
    assert "innerHTML" not in script


def test_dashboard_refresh_is_visibility_aware_and_skips_unchanged_rendering() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    login_page = (project_root / "asm_guardian" / "static" / "login.html").read_text(encoding="utf-8")
    styles = (project_root / "asm_guardian" / "static" / "app.css").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'class="compact-ui performance-ui"' in page
    assert 'class="login-page performance-ui"' in login_page
    assert "const AUTO_REFRESH_MS = 60000;" in script
    assert "setInterval(() => load(), 8000)" not in script
    assert 'document.addEventListener("visibilitychange"' in script
    assert "function dataChanged(" in script
    assert 'dataChanged("assets"' in script
    assert 'dataChanged("scans"' in script
    assert 'api("/api/v1/assets?limit=200")' in script
    assert 'api("/api/v1/discovered-hosts?limit=200")' in script
    assert 'api("/api/v1/web-observations?limit=200")' in script
    assert "const MAX_PORT_CHIPS_PER_ASSET = 24;" in script
    assert "const MAX_ASSET_TABLE_ROWS = 100;" in script
    assert "const MAX_SECONDARY_TABLE_ROWS = 100;" in script
    assert "const FILTER_DEBOUNCE_MS = 150;" in script
    assert 'document.createDocumentFragment()' in script
    assert 'addEventListener("input", scheduleAssetFilter)' in script
    assert "body.performance-ui .panel" in styles
    assert "body.performance-ui .login-shell" in styles
    assert "body.performance-ui .field-glow" in styles
    assert "filter: none" in styles
    assert "backdrop-filter: none" in styles


def test_dashboard_recovers_missing_or_stale_csrf_before_retrying_a_mutation() -> None:
    project_root = Path(__file__).resolve().parents[1]
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'const CSRF_COOKIE_NAME = "asm_guardian_csrf";' in script
    assert "function csrfFromCookie(" in script
    assert 'fetch("/api/v1/auth/csrf"' in script
    assert 'message === "Invalid CSRF token"' in script
    assert "_csrfRetried: true" in script


def test_dashboard_html_is_not_cached() -> None:
    project_root = Path(__file__).resolve().parents[1]
    source = (project_root / "asm_guardian" / "main.py").read_text(encoding="utf-8")

    assert 'request.url.path.startswith("/api/") or request.url.path in {"/", "/login", "/report"}' in source


def test_dashboard_sources_are_valid_utf8_without_replacement_or_control_characters() -> None:
    static_dir = Path(__file__).resolve().parents[1] / "asm_guardian" / "static"

    for name in (
        "index.html", "login.html", "app.css", "app.js", "login.js", "favicon.svg",
        "report.css", "report.js",
    ):
        content = (static_dir / name).read_text(encoding="utf-8")
        assert "\ufffd" not in content
        assert "\x07" not in content


def test_dashboard_exposes_operational_controls_without_api_key_management() -> None:
    project_root = Path(__file__).resolve().parents[1]
    page = (project_root / "asm_guardian" / "static" / "index.html").read_text(encoding="utf-8")
    script = (project_root / "asm_guardian" / "static" / "app.js").read_text(encoding="utf-8")

    assert 'id="sessions-dialog"' in page
    assert 'id="asset-dialog"' in page
    assert 'href="/api/v1/exports/assets.csv"' in page
    assert 'href="/report"' in page
    assert 'api(`/api/v1/scans/${scan.id}`' in script
    assert 'api(`/api/v1/discoveries/${discovery.id}`' in script
    assert 'api(`/api/v1/assets/${encodeURIComponent(ip)}`' in script
    assert 'api("/api/v1/sessions")' in script
    assert "X-API-Key" not in script
