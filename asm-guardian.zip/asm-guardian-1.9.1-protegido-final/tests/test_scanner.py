from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from asm_guardian.scanner import NmapExecutionError, NmapRunner, parse_nmap_xml


NMAP_XML = """<?xml version="1.0"?>
<nmaprun>
  <host><status state="up"/><address addr="10.20.30.40" addrtype="ipv4"/>
    <hostnames><hostname name="web.internal" type="PTR"/></hostnames>
    <ports>
      <port protocol="tcp" portid="22"><state state="open"/><service name="ssh" product="OpenSSH" version="9.6"/></port>
      <port protocol="tcp" portid="80"><state state="closed"/></port>
    </ports>
  </host>
</nmaprun>"""


def test_command_uses_only_fixed_safe_options_and_normalized_values() -> None:
    command = NmapRunner(max_rate=40).build_command(("10.20.30.40",), (443, 22), False)
    assert command == [
        "nmap", "-sT", "-n", "--open", "-T2", "--max-retries", "2", "--host-timeout", "2m",
        "--max-rate", "40", "-p", "22,443", "-oX", "-", "10.20.30.40",
    ]
    assert "-sV" not in command
    assert "--script" not in command


def test_light_service_detection_is_explicit_and_no_arbitrary_target_survives() -> None:
    command = NmapRunner().build_command(("127.0.0.1",), (80,), True)
    assert command[command.index("-sV"):command.index("-sV") + 2] == ["-sV", "--version-light"]
    with pytest.raises(ValueError):
        NmapRunner().build_command(("127.0.0.1 --script vuln",), (80,), False)


def test_parser_keeps_only_open_ports() -> None:
    output = parse_nmap_xml(NMAP_XML)
    assert output.hosts == ({"ip": "10.20.30.40", "hostname": "web.internal", "state": "up"},)
    assert len(output.findings) == 1
    assert output.findings[0]["port"] == 22
    assert output.findings[0]["product"] == "OpenSSH"


def test_parser_rejects_malformed_or_unexpected_xml() -> None:
    with pytest.raises(NmapExecutionError, match="malformed"):
        parse_nmap_xml("<nmaprun>")
    with pytest.raises(NmapExecutionError, match="unexpected"):
        parse_nmap_xml("<root />")


def test_runner_process_boundary_never_uses_a_shell(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict = {}

    def fake_run(command, **options):
        captured["command"] = command
        captured["options"] = options
        return subprocess.CompletedProcess(command, 0, stdout=NMAP_XML, stderr="")

    monkeypatch.setattr("asm_guardian.scanner.shutil.which", lambda _binary: "/usr/bin/nmap")
    monkeypatch.setattr("asm_guardian.scanner.subprocess.run", fake_run)
    output = NmapRunner(timeout_seconds=90).run(("10.20.30.40",), (22,), False)

    assert output.findings[0]["port"] == 22
    assert captured["command"][-1] == "10.20.30.40"
    assert captured["options"]["shell"] is False
    assert captured["options"]["timeout"] == 90
    assert captured["options"]["env"] == {"PATH": str(Path("/usr/bin/nmap").parent)}


def test_all_tcp_profile_is_exact_and_keeps_dangerous_options_unavailable() -> None:
    command = NmapRunner(timeout_seconds=3600).build_command(
        ("10.20.30.40",), (), False, port_profile="all-tcp"
    )
    assert command[command.index("-p"):command.index("-p") + 2] == ["-p", "1-65535"]
    assert "--script" not in command
    assert "-sU" not in command


def test_top_1000_profile_uses_nmap_curated_port_set() -> None:
    command = NmapRunner().build_command(("10.20.30.40",), (), False, port_profile="top-1000")
    assert command[command.index("--top-ports"):command.index("--top-ports") + 2] == ["--top-ports", "1000"]
    assert "-p" not in command


def test_custom_profile_accepts_more_than_old_64_port_limit() -> None:
    ports = tuple(range(1, 101))
    command = NmapRunner().build_command(("10.20.30.40",), ports, False)
    assert command[command.index("-p") + 1].startswith("1,2,3")
    assert command[command.index("-p") + 1].endswith("99,100")
