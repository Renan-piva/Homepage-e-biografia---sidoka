from __future__ import annotations

import pytest

from asm_guardian.webprobe import WebProbeRunner, parse_http_response


def test_http_response_parser_extracts_bounded_inventory_metadata() -> None:
    response = (
        b"HTTP/1.1 200 OK\r\n"
        b"Server: nginx\r\n"
        b"Content-Type: text/html; charset=utf-8\r\n"
        b"Location: https://example.com/login\r\n\r\n"
        b"<html><head><title>  Portal  Corporativo </title></head></html>"
    )

    parsed = parse_http_response(response)

    assert parsed == {
        "status_code": 200,
        "title": "Portal Corporativo",
        "server": "nginx",
        "content_type": "text/html; charset=utf-8",
        "location": "https://example.com/login",
    }


def test_http_response_parser_rejects_malformed_or_oversized_headers() -> None:
    with pytest.raises(ValueError, match="status line"):
        parse_http_response(b"not-http\r\n\r\n")
    with pytest.raises(ValueError, match="headers"):
        parse_http_response(b"HTTP/1.1 200 OK\r\nX-Large: " + (b"a" * 17_000) + b"\r\n\r\n")


def test_web_probe_runner_has_bounded_defaults() -> None:
    runner = WebProbeRunner(timeout_seconds=5, max_response_bytes=65_536)

    assert runner.timeout_seconds == 5
    assert runner.max_response_bytes == 65_536
    with pytest.raises(ValueError, match="timeout"):
        WebProbeRunner(timeout_seconds=0)
    with pytest.raises(ValueError, match="response"):
        WebProbeRunner(max_response_bytes=1_000_000)


def test_web_probe_connects_only_to_pinned_addresses_and_does_not_follow_redirects(monkeypatch) -> None:
    response = (
        b"HTTP/1.1 302 Found\r\nLocation: https://elsewhere.example/\r\n"
        b"Server: gateway\r\nContent-Type: text/html\r\n\r\n<title>Moved</title>"
    )
    connections: list[tuple[tuple[str, int], int]] = []
    sockets = []

    class FakeSocket:
        def __init__(self) -> None:
            self.response = response
            self.request = b""
            self.closed = False

        def settimeout(self, _timeout) -> None:
            pass

        def sendall(self, data: bytes) -> None:
            self.request += data

        def recv(self, _size: int) -> bytes:
            result, self.response = self.response, b""
            return result

        def getpeercert(self):
            return {
                "subject": ((('commonName', 'example.com'),),),
                "issuer": ((('commonName', 'Example CA'),),),
                "notAfter": "Jan  1 00:00:00 2030 GMT",
            }

        def close(self) -> None:
            self.closed = True

    class FakeContext:
        def wrap_socket(self, sock, server_hostname):
            assert server_hostname == "example.com"
            return sock

    def fake_connection(address, timeout):
        connections.append((address, timeout))
        sock = FakeSocket()
        sockets.append(sock)
        return sock

    monkeypatch.setattr("asm_guardian.webprobe.socket.create_connection", fake_connection)
    monkeypatch.setattr("asm_guardian.webprobe.ssl.create_default_context", FakeContext)

    output = WebProbeRunner().run("example.com", ("192.0.2.10",))

    assert connections == [(('192.0.2.10', 443), 5), (('192.0.2.10', 80), 5)]
    assert len(output.observations) == 2
    assert all(item["status_code"] == 302 for item in output.observations)
    assert output.observations[0]["tls_subject"] == "example.com"
    assert all(b"GET / HTTP/1.1" in sock.request for sock in sockets)
    assert all(b"Host: example.com" in sock.request for sock in sockets)
    assert all(sock.closed for sock in sockets)


def test_web_probe_records_connection_failures_instead_of_raising(monkeypatch) -> None:
    def fail_connection(*_args, **_kwargs):
        raise TimeoutError("timed out")

    monkeypatch.setattr("asm_guardian.webprobe.socket.create_connection", fail_connection)

    output = WebProbeRunner().run("example.com", ("192.0.2.10",))

    assert len(output.observations) == 2
    assert all("TimeoutError" in item["error"] for item in output.observations)
