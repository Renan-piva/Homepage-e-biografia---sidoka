from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from asm_guardian.discovery import (
    GobusterRunner,
    SubfinderRunner,
    parse_gobuster_dns_output,
    parse_subfinder_output,
)


def test_dns_output_keeps_only_valid_children_of_the_authorized_domain() -> None:
    output = """
Found: api.example.com
[+] Found: dev.example.com
Found: example.com.evil.test
Found: bad_name.example.com
"""

    assert parse_gobuster_dns_output(output, "example.com") == ("api.example.com", "dev.example.com")


def test_gobuster_uses_a_fixed_dns_command_without_a_shell(tmp_path: Path, monkeypatch) -> None:
    wordlist = tmp_path / "dns.txt"
    wordlist.write_text("api\ndev\n", encoding="utf-8")
    runner = GobusterRunner("gobuster", wordlist, threads=5, timeout_seconds=120)
    captured: dict = {}

    monkeypatch.setattr("asm_guardian.discovery.shutil.which", lambda _binary: "/usr/bin/gobuster")

    def fake_run(command, **options):
        captured["command"] = command
        captured["options"] = options
        return subprocess.CompletedProcess(command, 0, stdout="Found: api.example.com\n", stderr="")

    monkeypatch.setattr("asm_guardian.discovery.subprocess.run", fake_run)

    result = runner.run("example.com")

    assert result.hostnames == ("api.example.com",)
    assert captured["command"] == [
        "/usr/bin/gobuster",
        "dns",
        "--domain",
        "example.com",
        "--wordlist",
        str(wordlist),
        "--threads",
        "5",
        "--no-progress",
        "--no-color",
    ]
    assert captured["options"]["shell"] is False
    assert captured["options"]["env"] == {"PATH": "/usr/bin"}


def test_gobuster_rejects_domain_syntax_that_could_become_arguments(tmp_path: Path) -> None:
    wordlist = tmp_path / "dns.txt"
    wordlist.write_text("api\n", encoding="utf-8")

    with pytest.raises(ValueError, match="domain"):
        GobusterRunner(wordlist=wordlist).build_command("example.com --wildcard")


def test_subfinder_output_keeps_only_valid_children_of_authorized_domain() -> None:
    output = "api.example.com\nwww.example.com\nexample.com\nexample.com.evil.test\n"

    assert parse_subfinder_output(output, "example.com") == ("api.example.com", "www.example.com")


def test_subfinder_uses_fixed_passive_command_and_private_home(tmp_path: Path, monkeypatch) -> None:
    runner = SubfinderRunner("subfinder", home=tmp_path, rate_limit=12, timeout_seconds=120)
    captured: dict = {}
    monkeypatch.setattr("asm_guardian.discovery.shutil.which", lambda _binary: "/usr/local/bin/subfinder")

    def fake_run(command, **options):
        captured["command"] = command
        captured["options"] = options
        return subprocess.CompletedProcess(command, 0, stdout="api.example.com\n", stderr="")

    monkeypatch.setattr("asm_guardian.discovery.subprocess.run", fake_run)

    result = runner.run("example.com")

    assert result.hostnames == ("api.example.com",)
    assert captured["command"] == [
        "/usr/local/bin/subfinder",
        "-d",
        "example.com",
        "-silent",
        "-duc",
        "-rl",
        "12",
    ]
    assert captured["options"]["shell"] is False
    assert captured["options"]["env"] == {"PATH": "/usr/local/bin", "HOME": str(tmp_path)}
